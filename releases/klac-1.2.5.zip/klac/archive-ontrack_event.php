<?php
/**
 * Archive template for Events.
 *
 * Lists upcoming events sorted by date ascending (query ordered by _event_datetime
 * via pre_get_posts in functions-post-types.php).
 *
 * @package Ontrack
 */

get_header();
?>

	<main id="primary" class="site-main">

		<header class="page-header">
			<h1 class="page-title"><?php esc_html_e( 'Upcoming Events', 'ontrack' ); ?></h1>
		</header>

		<?php if ( have_posts() ) : ?>

			<div class="ontrack-event-list">

				<?php while ( have_posts() ) : the_post(); ?>

					<?php
					$event_dt   = get_post_meta( get_the_ID(), '_event_datetime', true );
					$location   = get_post_meta( get_the_ID(), '_event_location', true );
					$stream_url = get_post_meta( get_the_ID(), '_event_stream_url', true );

					$date_str = '';
					$time_str = '';
					if ( $event_dt ) {
						$ts       = strtotime( $event_dt );
						$date_str = date_i18n( 'l, j F Y', $ts );
						$time_str = date_i18n( 'g:i A', $ts );
					}
					?>

					<article id="post-<?php the_ID(); ?>" <?php post_class( 'ontrack-event-card' ); ?>>

						<?php if ( has_post_thumbnail() ) : ?>
							<a class="ontrack-event-card__thumbnail" href="<?php the_permalink(); ?>">
								<?php the_post_thumbnail( 'medium' ); ?>
							</a>
						<?php endif; ?>

						<div class="ontrack-event-card__body">
							<h2 class="ontrack-event-card__title">
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</h2>

							<div class="ontrack-event-card__meta">
								<?php if ( $date_str ) : ?>
									<span class="ontrack-event-card__date"><?php echo esc_html( $date_str ); ?></span>
									<?php if ( $time_str ) : ?>
										<span class="ontrack-event-card__sep">&middot;</span>
										<span class="ontrack-event-card__time"><?php echo esc_html( $time_str ); ?></span>
									<?php endif; ?>
								<?php endif; ?>
								<?php if ( $location ) : ?>
									<span class="ontrack-event-card__sep">&middot;</span>
									<span class="ontrack-event-card__location"><?php echo esc_html( $location ); ?></span>
								<?php endif; ?>
							</div>

							<?php if ( has_excerpt() ) : ?>
								<div class="ontrack-event-card__excerpt"><?php the_excerpt(); ?></div>
							<?php endif; ?>

							<a class="ontrack-event-card__cta button" href="<?php the_permalink(); ?>">
								<?php esc_html_e( 'View Details', 'ontrack' ); ?>
							</a>
						</div>

					</article>

				<?php endwhile; ?>

			</div><!-- .ontrack-event-list -->

			<?php the_posts_navigation(); ?>

		<?php else : ?>

			<p><?php esc_html_e( 'No upcoming events at this time.', 'ontrack' ); ?></p>

		<?php endif; ?>

	</main><!-- #main -->

<?php
get_sidebar();
get_footer();
