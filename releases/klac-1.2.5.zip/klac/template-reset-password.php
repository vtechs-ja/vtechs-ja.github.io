<?php
/**
 * Template Name: Reset Password Fallback
 *
 * Handles the Universal Link reset URL for browser and desktop users.
 * When opened in a browser (app not installed or desktop), this page
 * redirects to WordPress's native password reset form using the same key.
 *
 * Setup: create a WordPress page with slug "reset-password" and assign
 * this template. No page content is displayed — it redirects immediately.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.NonceVerification.Recommended
$key   = isset( $_GET['key'] )   ? sanitize_text_field( wp_unslash( $_GET['key'] ) )   : '';
$login = isset( $_GET['login'] ) ? sanitize_text_field( wp_unslash( $_GET['login'] ) ) : '';
// phpcs:enable

if ( $key && $login ) {
	$redirect = add_query_arg(
		array(
			'action' => 'rp',
			'key'    => rawurlencode( $key ),
			'login'  => rawurlencode( $login ),
		),
		wp_login_url()
	);
	wp_safe_redirect( $redirect, 302 );
	exit;
}

// Missing params — send to the lost-password page so the user can request a new link.
wp_safe_redirect( wp_lostpassword_url(), 302 );
exit;
