<?php
/**
 * Single template for an Event post.
 *
 * @package Ontrack
 */

get_header();
?>

	<main id="primary" class="site-main">

		<?php while ( have_posts() ) : the_post(); ?>

			<?php
			$event_dt   = get_post_meta( get_the_ID(), '_event_datetime', true );
			$location   = get_post_meta( get_the_ID(), '_event_location', true );
			$stream_url = get_post_meta( get_the_ID(), '_event_stream_url', true );

			$date_str = '';
			$time_str = '';
			if ( $event_dt ) {
				$ts       = strtotime( $event_dt );
				$date_str = date_i18n( 'l, j F Y', $ts );
				$time_str = date_i18n( 'g:i A', $ts );
			}
			?>

			<article id="post-<?php the_ID(); ?>" <?php post_class( 'ontrack-event-single' ); ?>>

				<?php if ( has_post_thumbnail() ) : ?>
					<div class="ontrack-event-single__banner">
						<?php the_post_thumbnail( 'large' ); ?>
					</div>
				<?php endif; ?>

				<header class="ontrack-event-single__header">
					<h1 class="ontrack-event-single__title"><?php the_title(); ?></h1>

					<div class="ontrack-event-single__meta">
						<?php if ( $date_str ) : ?>
							<div class="ontrack-event-single__meta-row">
								<span class="ontrack-event-single__meta-label"><?php esc_html_e( 'Date', 'ontrack' ); ?></span>
								<span class="ontrack-event-single__meta-value">
									<?php echo esc_html( $date_str ); ?>
									<?php if ( $time_str ) : ?>
										&middot; <?php echo esc_html( $time_str ); ?>
									<?php endif; ?>
								</span>
							</div>
						<?php endif; ?>

						<?php if ( $location ) : ?>
							<div class="ontrack-event-single__meta-row">
								<span class="ontrack-event-single__meta-label"><?php esc_html_e( 'Location', 'ontrack' ); ?></span>
								<span class="ontrack-event-single__meta-value"><?php echo esc_html( $location ); ?></span>
							</div>
						<?php endif; ?>
					</div>

					<?php if ( $stream_url ) : ?>
						<a class="ontrack-event-single__stream-btn button"
							href="<?php echo esc_url( $stream_url ); ?>"
							target="_blank" rel="noopener noreferrer">
							<?php esc_html_e( 'Watch Live', 'ontrack' ); ?>
						</a>
					<?php endif; ?>
				</header>

				<?php if ( get_the_content() ) : ?>
					<div class="ontrack-event-single__content entry-content">
						<?php the_content(); ?>
					</div>
				<?php endif; ?>

				<footer class="ontrack-event-single__footer">
					<a href="<?php echo esc_url( get_post_type_archive_link( 'ontrack_event' ) ); ?>">
						&larr; <?php esc_html_e( 'All Events', 'ontrack' ); ?>
					</a>
				</footer>

			</article>

		<?php endwhile; ?>

	</main><!-- #main -->

<?php
get_sidebar();
get_footer();
