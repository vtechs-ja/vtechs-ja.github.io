<?php
/**
 * Versioned upgrade steps.
 *
 * Each step runs once, in version order, on sites upgrading from an earlier
 * version. Fresh installs skip them (defaults already apply). Steps must be
 * idempotent: they can be re-run safely if an upgrade is interrupted.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Migration runner.
 */
class Ontrack_Migrations {

	/**
	 * Version => static method name.
	 *
	 * @return array<string, string>
	 */
	private static function steps() {
		return array(
			'0.14.0' => 'to_0_14_0',
			'0.15.0' => 'to_0_15_0',
		);
	}

	/**
	 * Run every step newer than $from, up to and including the current version.
	 *
	 * @param string $from Previously stored plugin version ('' on a fresh install).
	 */
	public static function run( $from ) {
		if ( '' === (string) $from ) {
			return;
		}
		$steps = self::steps();
		uksort( $steps, 'version_compare' );
		foreach ( $steps as $version => $method ) {
			if ( version_compare( (string) $from, $version, '<' ) && version_compare( $version, ONTRACK_VERSION, '<=' ) ) {
				call_user_func( array( __CLASS__, $method ) );
			}
		}
	}

	/**
	 * Persist an option default that changed, so existing sites keep their previous value.
	 *
	 * @param string $key   Option array key.
	 * @param mixed  $value Value the site was effectively using before the default changed.
	 */
	private static function pin_option( $key, $value ) {
		$saved = get_option( ontrack_options_key(), array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		if ( ! array_key_exists( $key, $saved ) ) {
			$saved[ $key ] = $value;
			update_option( ontrack_options_key(), $saved );
		}
	}

	/**
	 * 0.14.0: REST enforcement now defaults to on. Existing sites keep their old (off) behaviour.
	 */
	public static function to_0_14_0() {
		self::pin_option( 'rest_enforcement_enabled', false );
	}

	/**
	 * 0.15.0: the built-in community links were client-specific and are no longer a default.
	 * Sites that never saved their own list keep the links they were showing.
	 */
	public static function to_0_15_0() {
		self::pin_option(
			'community_links',
			array(
				array( 'label' => 'Canopy Radio',          'url' => 'https://canopylive.com/' ),
				array( 'label' => 'Congress MusicFactory', 'url' => 'https://new.congressmusicfactory.com/' ),
				array( 'label' => 'KLAC Live Stream',      'url' => 'https://www.klackc.org/live' ),
			)
		);
	}
}
