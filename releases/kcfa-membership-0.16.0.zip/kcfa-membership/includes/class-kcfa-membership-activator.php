<?php
/**
 * Activation and versioned setup.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Runs on plugin activation and when the plugin version bumps.
 */
class Ontrack_Activator {

	/**
	 * Register roles, create tables, seed options, ensure JWT secret, schedule cron.
	 * Sets a flag so rewrite rules are flushed on the next init (after CPTs are registered).
	 */
	public static function activate() {
		self::register_roles();
		ontrack_audio_metadata_create_table();
		self::ensure_default_options();
		Ontrack_JWT::ensure_secret();
		self::schedule_cron();
		update_option( 'ontrack_flush_rewrite_rules', 1, false );
	}

	/**
	 * Flush rewrite rules if the flag is set. Hooked to init at priority 99,
	 * after CPT registration (priority 10), so new slugs are included.
	 */
	public static function maybe_flush_rewrite_rules() {
		if ( get_option( 'ontrack_flush_rewrite_rules' ) ) {
			flush_rewrite_rules();
			delete_option( 'ontrack_flush_rewrite_rules' );
		}
	}

	/**
	 * Clear cron on deactivation.
	 * Roles are intentionally kept (removing them would strip every member's role); they are
	 * removed only by uninstall.php when explicitly requested. The JWT secret is also preserved.
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( Ontrack_Plugin::CRON_CLEANUP_HOOK );
	}

	/**
	 * Schedule daily refresh-token cleanup if not already scheduled.
	 */
	private static function schedule_cron() {
		if ( ! wp_next_scheduled( Ontrack_Plugin::CRON_CLEANUP_HOOK ) ) {
			wp_schedule_event( time(), 'daily', Ontrack_Plugin::CRON_CLEANUP_HOOK );
		}
	}

	/**
	 * Register each custom role (idempotent) and grant all klac_* caps to administrator.
	 */
	private static function register_roles() {
		// Labels apply when a role is first created; existing roles keep their saved label.
		$labels = apply_filters(
			'ontrack_role_labels',
			array(
				KCFA_ROLE_MEMBER           => __( 'Member', 'ontrack' ),
				KCFA_ROLE_LEADER           => __( 'Leader', 'ontrack' ),
				KCFA_ROLE_COMMUNITY_LEADER => __( 'Community Leader', 'ontrack' ),
				KCFA_ROLE_ADMIN            => __( 'Community Admin', 'ontrack' ),
			)
		);

		foreach ( ontrack_get_role_definitions() as $slug => $caps ) {
			$role = get_role( $slug );
			if ( ! $role ) {
				add_role( $slug, $labels[ $slug ] ?? $slug, $caps );
				continue;
			}
			// Existing role: top up any capabilities introduced since it was created.
			foreach ( $caps as $cap => $grant ) {
				if ( ! array_key_exists( $cap, $role->capabilities ) ) {
					$role->add_cap( $cap, $grant );
				}
			}
		}

		$administrator = get_role( 'administrator' );
		if ( $administrator ) {
			foreach ( ontrack_get_all_capabilities() as $cap => $grant ) {
				$administrator->add_cap( $cap, $grant );
			}
		}
	}

	/**
	 * Seed default options if missing.
	 */
	private static function ensure_default_options() {
		if ( false === get_option( ontrack_options_key(), false ) ) {
			add_option( ontrack_options_key(), ontrack_default_options(), '', false );
		}
	}
}
