<?php
/**
 * REST API authentication endpoints.
 *
 * Namespace: klac/v1
 * Routes:
 *   POST /auth/token          — email + password → token pair
 *   POST /auth/refresh        — refresh_token    → new token pair
 *   GET  /auth/me             — Bearer JWT       → member profile
 *   POST /auth/forgot-password — email           → WP reset email
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and handles /klac/v1/auth/* REST routes.
 */
class Ontrack_REST_Auth {


	/**
	 * Register all routes on rest_api_init.
	 */
	public function register_routes() {
		register_rest_route(
			ontrack_rest_namespace(),
			'/auth/token',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'handle_token' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'email'    => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_email',
					),
					'password' => array(
						'required' => true,
						'type'     => 'string',
					),
				),
			)
		);

		register_rest_route(
			ontrack_rest_namespace(),
			'/auth/refresh',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'handle_refresh' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'refresh_token' => array(
						'required' => true,
						'type'     => 'string',
					),
				),
			)
		);

		register_rest_route(
			ontrack_rest_namespace(),
			'/auth/me',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'handle_me' ),
				'permission_callback' => array( $this, 'require_authenticated' ),
			)
		);

		register_rest_route(
			ontrack_rest_namespace(),
			'/auth/reset-password',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'handle_reset_password' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'key'          => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'login'        => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'new_password' => array(
						'required' => true,
						'type'     => 'string',
					),
				),
			)
		);

		register_rest_route(
			ontrack_rest_namespace(),
			'/auth/forgot-password',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'handle_forgot_password' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'email' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_email',
					),
				),
			)
		);

		register_rest_route(
			ontrack_rest_namespace(),
			'/members/me',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'handle_members_me_get' ),
					'permission_callback' => array( $this, 'require_authenticated' ),
				),
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'handle_members_me_put' ),
					'permission_callback' => array( $this, 'require_authenticated' ),
					'args'                => array(
						'date_of_birth' => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'gender'        => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'city'          => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'country'       => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);

		register_rest_route(
			ontrack_rest_namespace(),
			'/groups',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'handle_groups' ),
				'permission_callback' => array( $this, 'require_authenticated' ),
			)
		);

		register_rest_route(
			ontrack_rest_namespace(),
			'/app-settings',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'handle_app_settings' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	// -------------------------------------------------------------------------
	// Handlers
	// -------------------------------------------------------------------------

	/**
	 * POST /auth/token — authenticate with email + password, return token pair.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_token( WP_REST_Request $request ) {
		$email    = $request->get_param( 'email' );
		$password = $request->get_param( 'password' );
		$ip       = self::get_client_ip();

		// Failed logins are counted per account and per IP (15 minute window); successes are not.
		if ( self::rate_limit_count( 'login_ip', $ip, 900, false ) >= 60 ||
			self::rate_limit_count( 'login_acct', (string) $email, 900, false ) >= 8 ) {
			return self::rate_limited_error();
		}

		if ( ! is_email( $email ) ) {
			self::rate_limit_count( 'login_ip', $ip, 900, true );
			return new WP_Error( 'invalid_credentials', __( 'Invalid email or password.', 'ontrack' ), array( 'status' => 401 ) );
		}

		// wp_authenticate accepts username or email.
		$user = wp_authenticate( $email, $password );
		if ( is_wp_error( $user ) ) {
			self::rate_limit_count( 'login_ip', $ip, 900, true );
			self::rate_limit_count( 'login_acct', (string) $email, 900, true );
			// Normalize to avoid user enumeration via different error messages.
			return new WP_Error( 'invalid_credentials', __( 'Invalid email or password.', 'ontrack' ), array( 'status' => 401 ) );
		}

		$tokens = Ontrack_JWT::generate_token_pair( $user );

		return new WP_REST_Response(
			array_merge( $tokens, array(
				'display_name' => $user->display_name,
				'is_member'    => ontrack_user_is_full_member( $user->ID ),
			) ),
			200
		);
	}

	/**
	 * POST /auth/refresh — rotate refresh token, return new token pair.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_refresh( WP_REST_Request $request ) {
		$refresh_token = $request->get_param( 'refresh_token' );

		// Generous per-IP cap (many users can share one IP behind NAT or a proxy).
		if ( self::rate_limit_count( 'refresh_ip', self::get_client_ip(), 900, true ) > 300 ) {
			return self::rate_limited_error();
		}

		$result = Ontrack_JWT::rotate_refresh_token( (string) $refresh_token );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * GET /auth/me — return authenticated user's membership profile.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function handle_me( WP_REST_Request $request ) {
		$user_id = get_current_user_id();
		$user    = get_userdata( $user_id );

		return new WP_REST_Response(
			array(
				'id'           => $user_id,
				'email'        => $user->user_email,
				'display_name' => $user->display_name,
				'is_member'    => ontrack_user_is_full_member( $user_id ),
				'group_ids'    => ontrack_get_user_assigned_group_ids( $user_id ),
			),
			200
		);
	}

	/**
	 * POST /auth/forgot-password — trigger WP password reset email.
	 * Always returns 200 to avoid user enumeration.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function handle_forgot_password( WP_REST_Request $request ) {
		$email = $request->get_param( 'email' );

		if ( self::rate_limit_count( 'forgot_ip', self::get_client_ip(), 3600, true ) > 30 ) {
			return self::rate_limited_error();
		}

		// Per-address cap: further requests return the same neutral 200 without sending,
		// so the endpoint can't be used to flood one inbox or to probe for accounts.
		if ( is_email( $email ) && self::rate_limit_count( 'forgot_acct', $email, 3600, true ) <= 3 ) {
			$user = get_user_by( 'email', $email );
			if ( $user ) {
				retrieve_password( $user->user_login );
			}
		}

		return new WP_REST_Response(
			array( 'message' => __( 'If an account exists for that email, a reset link has been sent.', 'ontrack' ) ),
			200
		);
	}

	/**
	 * POST /auth/reset-password — validate reset key and set new password.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_reset_password( WP_REST_Request $request ) {
		$key          = $request->get_param( 'key' );
		$login        = $request->get_param( 'login' );
		$new_password = $request->get_param( 'new_password' );

		if ( self::rate_limit_count( 'reset_ip', self::get_client_ip(), 3600, true ) > 60 ) {
			return self::rate_limited_error();
		}

		if ( strlen( $new_password ) < 8 ) {
			return new WP_Error(
				'password_too_short',
				__( 'Password must be at least 8 characters.', 'ontrack' ),
				array( 'status' => 400 )
			);
		}

		$user = check_password_reset_key( $key, $login );

		if ( is_wp_error( $user ) ) {
			return new WP_Error(
				'invalid_reset_key',
				__( 'This reset link has expired or is invalid. Please request a new one.', 'ontrack' ),
				array( 'status' => 400 )
			);
		}

		reset_password( $user, $new_password );

		return new WP_REST_Response(
			array( 'message' => __( 'Password reset successfully.', 'ontrack' ) ),
			200
		);
	}

	/**
	 * Appends a klacontrack:// deep link to the WP password reset email so mobile
	 * users can complete the reset without leaving the app.
	 * The original wp-login.php link is preserved for web/desktop users.
	 *
	 * @param string  $message    Email message text.
	 * @param string  $key        Reset key.
	 * @param string  $user_login User login name.
	 * @return string
	 */
	public static function filter_password_reset_message( $message, $key, $user_login ) {
		$universal_url = add_query_arg(
			array(
				'key'   => rawurlencode( $key ),
				'login' => rawurlencode( $user_login ),
			),
			home_url( '/reset-password' )
		);

		// Replace the wp-login.php reset URL with the Universal Link.
		// Angle brackets are optional — older WP wraps the URL in <...>,
		// newer WP (6.x) puts the URL on its own line without brackets.
		$replaced = preg_replace(
			'#<?https?://[^\s<>]*[?&]action=rp[^\s<>]*>?#',
			'<' . $universal_url . '>',
			$message
		);

		// preg_replace returns null on error; treat that as no match.
		if ( null !== $replaced && $replaced !== $message ) {
			return $replaced;
		}

		$message .= "\r\n" . __( 'To reset your password, visit:', 'ontrack' ) . "\r\n";
		$message .= '<' . $universal_url . ">\r\n";
		return $message;
	}

	/**
	 * GET /members/me — full member profile including demographics.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function handle_members_me_get( WP_REST_Request $request ) {
		$user_id = get_current_user_id();
		$user    = get_userdata( $user_id );

		// Resolve the user's primary klac_* role.
		$role        = '';
		$klac_roles  = array( 'klac_admin', 'klac_community_leader', 'klac_leader', 'klac_member' );
		foreach ( $klac_roles as $r ) {
			if ( in_array( $r, (array) $user->roles, true ) ) {
				$role = $r;
				break;
			}
		}

		return new WP_REST_Response(
			array(
				'id'           => $user_id,
				'email'        => $user->user_email,
				'display_name' => $user->display_name,
				'first_name'   => $user->first_name,
				'last_name'    => $user->last_name,
				'is_member'    => ontrack_user_is_full_member( $user_id ),
				'role'         => $role,
				'demographics' => array(
					'date_of_birth' => ontrack_get_user_date_of_birth( $user_id ),
					'gender'        => ontrack_get_user_gender( $user_id ),
					'city'          => ontrack_get_user_city( $user_id ),
					'country'       => ontrack_get_user_country( $user_id ),
				),
				'group_ids'              => ontrack_get_user_assigned_group_ids( $user_id ),
				'coordinator_group_ids'  => ontrack_get_coordinator_group_ids( $user_id ),
			),
			200
		);
	}

	/**
	 * PUT /members/me — update authenticated user's own demographics.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_members_me_put( WP_REST_Request $request ) {
		$user_id = get_current_user_id();

		if ( ! ontrack_current_user_can_edit_demographics_for_user( $user_id ) ) {
			return new WP_Error( 'rest_forbidden', __( 'You do not have permission to update this profile.', 'ontrack' ), array( 'status' => 403 ) );
		}

		$allowed = array( 'date_of_birth', 'gender', 'city', 'country' );
		$updated = array();

		foreach ( $allowed as $field ) {
			if ( ! $request->has_param( $field ) ) {
				continue;
			}
			$raw = $request->get_param( $field );
			switch ( $field ) {
				case 'date_of_birth':
					$value = ontrack_sanitize_date_of_birth( $raw );
					update_user_meta( $user_id, ontrack_meta_key_date_of_birth(), $value );
					break;
				case 'gender':
					$value = ontrack_sanitize_gender( $raw );
					update_user_meta( $user_id, ontrack_meta_key_gender(), $value );
					break;
				case 'city':
					$value = ontrack_sanitize_location_field( $raw );
					update_user_meta( $user_id, ontrack_meta_key_city(), $value );
					break;
				case 'country':
					$value = ontrack_sanitize_location_field( $raw );
					update_user_meta( $user_id, ontrack_meta_key_country(), $value );
					break;
				default:
					$value = $raw;
			}
			$updated[ $field ] = $value;
		}

		// Return the full updated profile.
		return $this->handle_members_me_get( $request );
	}

	/**
	 * GET /groups — list all published groups with current-user membership flag.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function handle_groups( WP_REST_Request $request ) {
		$user_id    = get_current_user_id();
		$user_group_ids = ontrack_get_user_assigned_group_ids( $user_id );

		$posts = get_posts( array(
			'post_type'      => ontrack_group_post_type(),
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'orderby'        => 'menu_order title',
			'order'          => 'ASC',
			'no_found_rows'  => true,
		) );

		$groups = array();
		foreach ( $posts as $post ) {
			$groups[] = array(
				'id'        => $post->ID,
				'title'     => $post->post_title,
				'parent_id' => (int) $post->post_parent,
				'is_member' => in_array( $post->ID, $user_group_ids, true ),
			);
		}

		return new WP_REST_Response( $groups, 200 );
	}

	/**
	 * GET /app-settings — public app configuration (no credentials).
	 * Exposes event schedule, feature flags, and any migrated app_settings values.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function handle_app_settings( WP_REST_Request $request ) {
		// Collect any migrated app_settings (stored as kcfa_setting_{group}_{key}).
		global $wpdb;
		$rows = $wpdb->get_results(
			"SELECT option_name, option_value FROM {$wpdb->options}
			 WHERE option_name LIKE 'kcfa\_setting\_%'",
			ARRAY_A
		);
		$migrated = array();
		foreach ( (array) $rows as $row ) {
			// Strip the kcfa_setting_ prefix and split into group/key.
			$key_parts = explode( '_', substr( $row['option_name'], strlen( 'kcfa_setting_' ) ), 2 );
			if ( 2 === count( $key_parts ) ) {
				$migrated[ $key_parts[0] ][ $key_parts[1] ] = $row['option_value'];
			}
		}

		$plugin_opts   = function_exists( 'ontrack_get_options' ) ? ontrack_get_options() : array();
		$animation_id  = ! empty( $plugin_opts['mobile_animation_attachment_id'] ) ? (int) $plugin_opts['mobile_animation_attachment_id'] : 0;
		$animation_url = $animation_id ? (string) wp_get_attachment_url( $animation_id ) : '';

		$community_links = array();
		if ( ! empty( $plugin_opts['community_links'] ) && is_array( $plugin_opts['community_links'] ) ) {
			foreach ( $plugin_opts['community_links'] as $link ) {
				if ( ! empty( $link['label'] ) && ! empty( $link['url'] ) ) {
					$community_links[] = array(
						'label' => (string) $link['label'],
						'url'   => (string) $link['url'],
					);
				}
			}
		}

		$settings = array(
			'download_event' => array(
				'day'    => 0, // 0 = Sunday; can be overridden by migrated setting
				'hour'   => 9,
				'minute' => 0,
			),
			'animation_url'   => $animation_url,
			'community_links' => $community_links,
			// Only the event schedule is read by clients; other stored settings stay private.
			'app'             => array( 'event' => array_intersect_key( isset( $migrated['event'] ) ? $migrated['event'] : array(), array_flip( array( 'day', 'hour', 'minute' ) ) ) ),
		);

		// Override with any explicitly stored event settings.
		if ( isset( $migrated['event']['day'] ) )    $settings['download_event']['day']    = (int) $migrated['event']['day'];
		if ( isset( $migrated['event']['hour'] ) )   $settings['download_event']['hour']   = (int) $migrated['event']['hour'];
		if ( isset( $migrated['event']['minute'] ) ) $settings['download_event']['minute'] = (int) $migrated['event']['minute'];

		return new WP_REST_Response( $settings, 200 );
	}

	// -------------------------------------------------------------------------
	// Permission callbacks
	// -------------------------------------------------------------------------

	/**
	 * Require a valid Bearer JWT (current user must be set).
	 *
	 * @return bool|WP_Error
	 */
	public function require_authenticated() {
		$user_id = get_current_user_id();
		if ( ! $user_id ) {
			return new WP_Error( 'rest_unauthorized', __( 'Authentication required.', 'ontrack' ), array( 'status' => 401 ) );
		}
		return true;
	}

	/**
	 * Static version of require_authenticated — usable as a static permission callback
	 * (e.g. from procedural REST route registrations that don't hold an instance).
	 *
	 * @return bool|WP_Error
	 */
	public static function require_authenticated_static() {
		$user_id = get_current_user_id();
		if ( ! $user_id ) {
			return new WP_Error( 'rest_unauthorized', __( 'Authentication required.', 'ontrack' ), array( 'status' => 401 ) );
		}
		return true;
	}

	/**
	 * Permission callback for collection playlist endpoints (/audio-collection/{id}/playlist,
	 * /video-collection/{id}/playlist). Checks the collection's access tier and group restriction
	 * against the current user. Returns true when REST enforcement is disabled.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool|WP_Error
	 */
	public static function permission_callback_for_collection( WP_REST_Request $request ) {
		if ( ! function_exists( 'ontrack_is_rest_enforcement_enabled' ) ||
			! ontrack_is_rest_enforcement_enabled() ) {
			return true;
		}

		$post_id = (int) $request->get_param( 'id' );
		$post    = get_post( $post_id );

		// Let the callback handle 404 — only gate posts we know are collections.
		if ( ! $post ||
			! in_array( $post->post_type, array( 'audio_collection', 'video_collection' ), true ) ||
			'publish' !== $post->post_status ) {
			return true;
		}

		return self::check_collection_access( $post_id );
	}

	/**
	 * Permission callback for /stream/{file_id}. Applies a per-IP rate limit unconditionally,
	 * then checks collection access when REST enforcement is enabled.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool|WP_Error
	 */
	public static function permission_callback_stream( WP_REST_Request $request ) {
		$rate_check = self::check_stream_rate_limit();
		if ( is_wp_error( $rate_check ) ) {
			return $rate_check;
		}

		// The file must come from a playlist: its URL carries the collection ID and
		// a signature binding the two. Unsigned or forged requests are refused
		// whether or not enforcement is on, so arbitrary Box files can't be fetched.
		$file_id       = (string) $request->get_param( 'file_id' );
		$collection_id = (int) $request->get_param( 'c' );
		$signature     = (string) $request->get_param( 's' );

		if ( $collection_id <= 0 || '' === $signature ||
			! hash_equals( ontrack_stream_signature( $file_id, $collection_id ), $signature ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Invalid stream link.', 'ontrack' ), array( 'status' => 403 ) );
		}

		$post = get_post( $collection_id );
		if ( ! $post || 'audio_collection' !== $post->post_type || 'publish' !== $post->post_status ) {
			return new WP_Error( 'rest_forbidden', __( 'Invalid stream link.', 'ontrack' ), array( 'status' => 403 ) );
		}

		if ( ! function_exists( 'ontrack_is_rest_enforcement_enabled' ) ||
			! ontrack_is_rest_enforcement_enabled() ) {
			return true;
		}

		return self::check_collection_access( $collection_id );
	}

	// -------------------------------------------------------------------------
	// Internal helpers
	// -------------------------------------------------------------------------

	/**
	 * Enforce access tier and group restrictions for a collection post.
	 *
	 * @param int $post_id Collection post ID.
	 * @return bool|WP_Error
	 */
	private static function check_collection_access( $post_id ) {
		// Editors and above can always access — consistent with front-end bypass in ontrack_user_can_view_collection().
		if ( is_user_logged_in() && current_user_can( 'edit_post', $post_id ) ) {
			return true;
		}

		$level = function_exists( 'ontrack_get_collection_access_level' )
			? ontrack_get_collection_access_level( $post_id )
			: 'full_member';

		if ( 'public' === $level ) {
			return true;
		}

		$user_id = get_current_user_id();
		if ( ! $user_id ) {
			return new WP_Error( 'rest_unauthorized', __( 'Authentication required.', 'ontrack' ), array( 'status' => 401 ) );
		}

		if ( 'visitor' === $level ) {
			return true;
		}

		// full_member tier.
		if ( ! function_exists( 'ontrack_user_is_full_member' ) ||
			! ontrack_user_is_full_member( $user_id ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Full membership required.', 'ontrack' ), array( 'status' => 403 ) );
		}

		// Group restriction — only relevant for full_member tier.
		if ( function_exists( 'ontrack_get_collection_allowed_group_ids' ) ) {
			$allowed_groups = ontrack_get_collection_allowed_group_ids( $post_id );
			if ( ! empty( $allowed_groups ) ) {
				$user_groups = function_exists( 'ontrack_get_user_effective_group_ids' )
					? ontrack_get_user_effective_group_ids( $user_id )
					: array();
				if ( ! array_intersect( $allowed_groups, $user_groups ) ) {
					return new WP_Error( 'rest_forbidden', __( 'You do not have access to this collection.', 'ontrack' ), array( 'status' => 403 ) );
				}
			}
		}

		return true;
	}

	/**
	 * Client IP for rate limiting, according to the "Client IP source" setting
	 * (direct, Cloudflare, or a reverse proxy's X-Forwarded-For). Falls back to the
	 * connection address when the chosen header is missing or not a valid IP.
	 * The `ontrack_trust_proxy_headers` filter can force the X-Forwarded-For mode from code.
	 *
	 * @return string
	 */
	private static function get_client_ip() {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';

		$opts   = function_exists( 'ontrack_get_options' ) ? ontrack_get_options() : array();
		$source = isset( $opts['client_ip_source'] ) ? $opts['client_ip_source'] : 'direct';
		if ( 'direct' === $source && apply_filters( 'ontrack_trust_proxy_headers', false ) ) {
			$source = 'forwarded';
		}

		$candidate = '';
		if ( 'cloudflare' === $source && ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
			$candidate = sanitize_text_field( wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) );
		} elseif ( 'forwarded' === $source && ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$parts     = explode( ',', sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) );
			$candidate = trim( $parts[0] );
		}

		return ( '' !== $candidate && filter_var( $candidate, FILTER_VALIDATE_IP ) ) ? $candidate : $ip;
	}

	/**
	 * Fixed-window counter. Returns the new hit count for the subject, or the
	 * current count without incrementing when $increment is false.
	 *
	 * @param string $bucket    Limiter name.
	 * @param string $subject   What is being limited (IP, email, ...).
	 * @param int    $window    Window length in seconds.
	 * @param bool   $increment Whether to count this call.
	 * @return int
	 */
	private static function rate_limit_count( $bucket, $subject, $window, $increment ) {
		$key  = 'ontrack_rl_' . $bucket . '_' . md5( strtolower( (string) $subject ) );
		$data = get_transient( $key );
		$now  = time();

		if ( false === $data || $now > (int) $data['reset_at'] ) {
			if ( ! $increment ) {
				return 0;
			}
			set_transient( $key, array( 'count' => 1, 'reset_at' => $now + $window ), $window );
			return 1;
		}

		if ( $increment ) {
			$data['count']++;
			set_transient( $key, $data, max( 1, (int) $data['reset_at'] - $now ) );
		}
		return (int) $data['count'];
	}

	/**
	 * @return WP_Error
	 */
	private static function rate_limited_error() {
		return new WP_Error( 'rest_rate_limited', __( 'Too many requests. Please try again later.', 'ontrack' ), array( 'status' => 429 ) );
	}

	/**
	 * Per-IP rate limiter for the stream endpoint — 60 requests per 60-second window.
	 *
	 * @return bool|WP_Error
	 */
	private static function check_stream_rate_limit() {
		return self::rate_limit_count( 'stream', self::get_client_ip(), 60, true ) > 60
			? self::rate_limited_error()
			: true;
	}

}
