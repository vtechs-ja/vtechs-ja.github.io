<?php
/**
 * User profile: coordinator group designation.
 *
 * Coordinator groups grant view-only access to a leader's assigned groups
 * without changing their role. Shown only to actors with klac_manage_groups.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders and saves the coordinator group checkboxes on user profile screens.
 */
class Ontrack_Coordinator_Admin {

	const NONCE_ACTION = 'ontrack_save_coordinator_groups';
	const NONCE_FIELD  = 'ontrack_coordinator_groups_nonce';

	/**
	 * Register hooks.
	 */
	public function register() {
		add_action( 'show_user_profile', array( $this, 'render_fields' ), 16 );
		add_action( 'edit_user_profile', array( $this, 'render_fields' ), 16 );
		add_action( 'personal_options_update', array( $this, 'save_profile' ) );
		add_action( 'edit_user_profile_update', array( $this, 'save_profile' ) );
	}

	/**
	 * Output coordinator groups checkbox list.
	 *
	 * @param WP_User $user User being viewed.
	 */
	public function render_fields( $user ) {
		if ( ! $user instanceof WP_User ) {
			return;
		}
		if ( ! current_user_can( KCFA_CAP_MANAGE_GROUPS ) ) {
			return;
		}

		$assigned = ontrack_get_coordinator_group_ids( $user->ID );
		$options  = ontrack_get_group_select_options();
		wp_nonce_field( self::NONCE_ACTION, self::NONCE_FIELD );
		?>
		<h2 id="ontrack-coordinator-groups-heading"><?php esc_html_e( 'Coordinator groups', 'ontrack' ); ?></h2>
		<p class="description" id="ontrack-coordinator-groups-desc">
			<?php esc_html_e( 'Groups this user coordinates. Coordinators can view the roster of assigned groups but cannot edit member profiles or group assignments. This is separate from group membership.', 'ontrack' ); ?>
		</p>
		<table class="form-table" role="presentation" aria-labelledby="ontrack-coordinator-groups-heading" aria-describedby="ontrack-coordinator-groups-desc">
			<tr>
				<th scope="row"><?php esc_html_e( 'Coordinator groups', 'ontrack' ); ?></th>
				<td>
					<?php if ( empty( $options ) ) : ?>
						<p><?php esc_html_e( 'No published groups yet. Create groups under Ontrack Management → Groups.', 'ontrack' ); ?></p>
					<?php else : ?>
						<fieldset id="ontrack_coordinator_group_ids" style="max-height: 16em; overflow-y: auto; min-width: 20em; max-width: 40em; padding: 0.5em 0.75em; border: 1px solid #8c8f94; border-radius: 4px; background: #fff;">
							<legend class="screen-reader-text"><?php esc_html_e( 'Coordinator groups', 'ontrack' ); ?></legend>
							<?php foreach ( $options as $gid => $label ) : ?>
								<label style="display: block; margin: 0.25em 0;">
									<input type="checkbox" name="ontrack_coordinator_group_ids[]" value="<?php echo esc_attr( (string) $gid ); ?>" <?php checked( in_array( (int) $gid, $assigned, true ) ); ?> />
									<?php echo esc_html( $label ); ?>
								</label>
							<?php endforeach; ?>
						</fieldset>
						<p class="description"><?php esc_html_e( 'Tick each group this user coordinates. Untick all to remove every coordinator assignment.', 'ontrack' ); ?></p>
					<?php endif; ?>
				</td>
			</tr>
		</table>
		<?php
	}

	/**
	 * Save coordinator group assignments.
	 *
	 * @param int $user_id User ID.
	 */
	public function save_profile( $user_id ) {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 ) {
			return;
		}
		if ( ! isset( $_POST[ self::NONCE_FIELD ] ) ||
			! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE_FIELD ] ) ), self::NONCE_ACTION ) ) {
			return;
		}
		if ( ! current_user_can( KCFA_CAP_MANAGE_GROUPS ) ) {
			return;
		}

		$raw = isset( $_POST['ontrack_coordinator_group_ids'] )
			? wp_unslash( $_POST['ontrack_coordinator_group_ids'] )
			: array();

		ontrack_set_coordinator_group_ids( $user_id, (array) $raw );
	}
}
