<?php
/**
 * Runs when the plugin is deleted from the Plugins screen.
 *
 * Always removes plugin settings, secrets, tokens, caches and the audio metadata table.
 * Membership data (roles, user profile/group data, collections, events, groups) is kept
 * unless `define( 'ONTRACK_REMOVE_ALL_DATA', true );` is set in wp-config.php.
 *
 * @package Ontrack
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// phpcs:disable WordPress.DB.DirectDatabaseQuery

// Settings, secrets and flags.
foreach ( array( 'ontrack_options', 'ontrack_integrations', 'ontrack_jwt_secret', 'ontrack_plugin_version', 'ontrack_flush_rewrite_rules' ) as $option ) {
	delete_option( $option );
}
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE 'kcfa\\_setting\\_%' OR option_name LIKE '\\_transient\\_ontrack\\_rl\\_%' OR option_name LIKE '\\_transient\\_timeout\\_ontrack\\_rl\\_%' OR option_name LIKE '\\_transient\\_kcfa\\_stream\\_rl\\_%' OR option_name LIKE '\\_transient\\_timeout\\_kcfa\\_stream\\_rl\\_%'" );

// Refresh tokens.
delete_metadata( 'user', 0, 'ontrack_refresh_token', '', true );
delete_metadata( 'user', 0, 'ontrack_refresh_token_expires', '', true );

// Scheduled cleanup and audio metadata table.
wp_clear_scheduled_hook( 'ontrack_cleanup_refresh_tokens' );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}kcfa_audio_metadata" );

if ( defined( 'ONTRACK_REMOVE_ALL_DATA' ) && ONTRACK_REMOVE_ALL_DATA ) {
	// Profile and group data on users.
	$wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'ontrack\\_%' OR meta_key LIKE 'kcfa\\_%'" );

	// Content created by the plugin.
	$post_ids = get_posts(
		array(
			'post_type'      => array( 'audio_collection', 'video_collection', 'ontrack_event', 'kcfa_group' ),
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
		)
	);
	foreach ( $post_ids as $post_id ) {
		wp_delete_post( $post_id, true );
	}

	// Roles and the capabilities granted to administrators.
	foreach ( array( 'klac_member', 'klac_leader', 'klac_community_leader', 'klac_admin' ) as $role ) {
		remove_role( $role );
	}
	$administrator = get_role( 'administrator' );
	if ( $administrator ) {
		foreach ( array_keys( $administrator->capabilities ) as $cap ) {
			if ( 0 === strpos( $cap, 'klac_' ) || false !== strpos( $cap, '_kcfa_group' ) ) {
				$administrator->remove_cap( $cap );
			}
		}
	}
}
