/**
 * Ontrack audio player: fetches playlist from REST and builds HTML5 player with playlist.
 *
 * @package Ontrack
 */

(function () {
	'use strict';

	var wrap = document.getElementById('ontrack-audio-player-wrap');
	if (!wrap) return;

	var collectionId = wrap.getAttribute('data-collection-id');
	if (!collectionId) return;

	var cfg = typeof ontrackAudioPlayer !== 'undefined' ? ontrackAudioPlayer : {};
	var restUrl = cfg.restUrl
		? cfg.restUrl
		: (window.wp && window.wp.apiRoot ? window.wp.apiRoot : '/wp-json') + '/klac/v1';
	var playlistUrl = restUrl + '/audio-collection/' + collectionId + '/playlist';

	var loadingEl = wrap.querySelector('.ontrack-audio-player-loading');
	var containerEl = wrap.querySelector('.ontrack-audio-player-container');
	var errorEl = wrap.querySelector('.ontrack-audio-player-error');
	var audioEl = wrap.querySelector('.ontrack-audio-element');
	var playlistOl = wrap.querySelector('.ontrack-audio-playlist');
	var nowPlayingSpan = wrap.querySelector('.ontrack-audio-now-playing');
	var playBtn = wrap.querySelector('.ontrack-audio-play');
	var prevBtn = wrap.querySelector('.ontrack-audio-prev');
	var nextBtn = wrap.querySelector('.ontrack-audio-next');
	var seekInput = wrap.querySelector('.ontrack-audio-seek');
	var timeCurrentSpan = wrap.querySelector('.ontrack-audio-time-current');
	var timeDurationSpan = wrap.querySelector('.ontrack-audio-time-duration');

	var STRINGS = {
		trackOf: 'Track {n} of {total}',
		moreTracks: 'More tracks'
	};
	var strings = cfg.i18n || {};

	function t(key, vars) {
		var s = strings[key] || STRINGS[key] || key;
		if (vars) {
			Object.keys(vars).forEach(function (k) {
				s = s.split('{' + k + '}').join(String(vars[k]));
			});
		}
		return s;
	}

	var headerEl = wrap.querySelector('.ontrack-audio-header');
	var controlsEl = wrap.querySelector('.ontrack-audio-controls');
	var progressWrapEl = wrap.querySelector('.ontrack-audio-progress-wrap');
	var oldLabelEl = wrap.querySelector('.ontrack-playlist-label');

	var tracks = [];
	var currentIndex = 0;
	var positionSpan, listWrap, scroller, moreBtn;

	function el(tag, className, text) {
		var n = document.createElement(tag);
		if (className) n.className = className;
		if (text) n.textContent = text;
		return n;
	}

	/**
	 * Group the title, controls and seek bar into one bar and put the track list
	 * in its own scroll area with scroll cues. Layout is handled by CSS.
	 */
	function buildChrome() {
		if (oldLabelEl && oldLabelEl.parentNode) oldLabelEl.parentNode.removeChild(oldLabelEl);

		var bar = el('div', 'ontrack-audio-bar');
		containerEl.insertBefore(bar, headerEl);
		bar.appendChild(headerEl);
		bar.appendChild(controlsEl);
		bar.appendChild(progressWrapEl);

		var titleBlock = el('div', 'ontrack-audio-titleblock');
		positionSpan = el('span', 'ontrack-audio-position');
		titleBlock.appendChild(positionSpan);
		titleBlock.appendChild(nowPlayingSpan);
		headerEl.appendChild(titleBlock);

		listWrap = el('div', 'ontrack-listwrap');
		scroller = el('div', 'ontrack-scroller');
		scroller.appendChild(playlistOl);
		listWrap.appendChild(scroller);
		listWrap.appendChild(el('div', 'ontrack-fade'));
		moreBtn = el('button', 'ontrack-more', t('moreTracks'));
		moreBtn.type = 'button';
		listWrap.appendChild(moreBtn);
		containerEl.appendChild(listWrap);

		moreBtn.addEventListener('click', function () {
			scroller.scrollBy({ top: scroller.clientHeight * 0.8, behavior: 'smooth' });
		});
		scroller.addEventListener('scroll', updateScrollCues);
		window.addEventListener('resize', updateScrollCues);
	}

	function updateScrollCues() {
		if (!scroller) return;
		var atEnd = scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 4;
		listWrap.classList.toggle('is-at-end', atEnd);
	}

	/** Scroll the list itself (never the page) so the current row sits mid-list. */
	function revealActive() {
		var row = playlistOl.querySelector('.is-active');
		if (!row || !scroller || containerEl.hasAttribute('hidden')) return;
		scroller.scrollTop = Math.max(0, row.offsetTop - (scroller.clientHeight - row.offsetHeight) / 2);
	}

	function setRowProgress(pct) {
		var bar = playlistOl.querySelector('.is-active .ontrack-audio-rowprog');
		if (bar) bar.style.width = pct + '%';
	}

	function showLoading(show) {
		loadingEl.hidden = !show;
		if (show) {
			containerEl.setAttribute('hidden', '');
			errorEl.hidden = true;
		}
	}

	function showError(message) {
		loadingEl.hidden = true;
		containerEl.setAttribute('hidden', '');
		errorEl.hidden = false;
		errorEl.textContent = message || 'Failed to load playlist.';
	}

	function showPlayer() {
		loadingEl.hidden = true;
		errorEl.hidden = true;
		containerEl.removeAttribute('hidden');
	}

	function formatTime(seconds) {
		if (!isFinite(seconds) || isNaN(seconds)) return '0:00';
		var m = Math.floor(seconds / 60);
		var s = Math.floor(seconds % 60);
		return m + ':' + (s < 10 ? '0' : '') + s;
	}

	function setPlayingState(isPlaying) {
		var iconPlay = playBtn.querySelector('.ontrack-icon-play');
		var iconPause = playBtn.querySelector('.ontrack-icon-pause');
		if (iconPlay) iconPlay.style.display = isPlaying ? 'none' : '';
		if (iconPause) iconPause.style.display = isPlaying ? '' : 'none';
		playBtn.setAttribute('aria-label', isPlaying ? 'Pause' : 'Play');
		wrap.classList.toggle('is-playing', isPlaying);
	}

	function setTrack(index) {
		if (index < 0 || index >= tracks.length) return;
		currentIndex = index;
		var track = tracks[index];
		audioEl.src = track.url;
		nowPlayingSpan.textContent = track.name;
		positionSpan.textContent = trackLabel(index);
		playlistOl.querySelectorAll('li').forEach(function (li, i) {
			var on = i === index;
			li.classList.toggle('is-active', on);
			var btn = li.firstChild;
			if (on) btn.setAttribute('aria-current', 'true'); else btn.removeAttribute('aria-current');
			var bar = li.querySelector('.ontrack-audio-rowprog');
			if (bar) bar.style.width = '0';
		});
		revealActive();
		updateScrollCues();
		audioEl.load();
		seekInput.value = 0;
		timeCurrentSpan.textContent = '0:00';
		timeDurationSpan.textContent = '0:00';
	}

	function trackLabel(index) {
		return t('trackOf', { n: index + 1, total: tracks.length });
	}

	function play() {
		if (tracks.length === 0) return;
		audioEl.play().catch(function () {});
	}

	function pause() {
		audioEl.pause();
	}

	function togglePlay() {
		if (audioEl.paused) play(); else pause();
	}

	function prev() {
		if (currentIndex > 0) {
			setTrack(currentIndex - 1);
			play();
		}
	}

	function next() {
		if (currentIndex < tracks.length - 1) {
			setTrack(currentIndex + 1);
			play();
		} else {
			pause();
			audioEl.currentTime = 0;
		}
	}

	function updateTime() {
		var current = audioEl.currentTime;
		var duration = audioEl.duration;
		if (!isFinite(duration)) duration = 0;
		timeCurrentSpan.textContent = formatTime(current);
		timeDurationSpan.textContent = formatTime(duration);
		var pct = duration > 0 ? (current / duration) * 100 : 0;
		seekInput.value = pct;
		setRowProgress(pct);
	}

	function seek() {
		var pct = parseFloat(seekInput.value, 10);
		var duration = audioEl.duration;
		if (isFinite(duration)) audioEl.currentTime = (pct / 100) * duration;
	}

	function buildPlaylistList() {
		playlistOl.innerHTML = '';
		tracks.forEach(function (track, i) {
			var li = document.createElement('li');
			li.className = 'ontrack-audio-playlist-item' + (i === 0 ? ' is-active' : '');
			var btn = document.createElement('button');
			btn.type = 'button';
			btn.className = 'ontrack-audio-playlist-link';
			var num = el('span', 'ontrack-audio-num');
			num.setAttribute('aria-hidden', 'true');
			num.appendChild(el('span', 'ontrack-audio-index', String(i + 1)));
			var eq = el('span', 'ontrack-audio-eq');
			eq.appendChild(document.createElement('i'));
			eq.appendChild(document.createElement('i'));
			eq.appendChild(document.createElement('i'));
			num.appendChild(eq);
			btn.appendChild(num);
			btn.appendChild(el('span', 'ontrack-audio-title', track.name));
			btn.appendChild(el('span', 'ontrack-audio-rowprog'));
			btn.addEventListener('click', function () {
				setTrack(i);
				play();
			});
			li.appendChild(btn);
			playlistOl.appendChild(li);
		});
	}

	// Events
	audioEl.addEventListener('play', function () { setPlayingState(true); });
	audioEl.addEventListener('pause', function () { setPlayingState(false); });
	audioEl.addEventListener('timeupdate', updateTime);
	audioEl.addEventListener('durationchange', updateTime);
	audioEl.addEventListener('ended', next);
	playBtn.addEventListener('click', togglePlay);
	prevBtn.addEventListener('click', prev);
	nextBtn.addEventListener('click', next);
	seekInput.addEventListener('input', seek);

	// Fetch playlist
	buildChrome();
	showLoading(true);
	fetch(playlistUrl, { method: 'GET', credentials: 'same-origin' })
		.then(function (res) { return res.json(); })
		.then(function (data) {
			if (data.error) {
				showError(data.error);
				return;
			}
			tracks = data.tracks || [];
			if (tracks.length === 0) {
				showError(data.error || 'No audio files in this collection.');
				return;
			}
			showPlayer();
			buildPlaylistList();
			setTrack(0);
		})
		.catch(function () {
			showError('Failed to load playlist.');
		});
})();
