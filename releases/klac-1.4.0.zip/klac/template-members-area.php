<?php
/**
 * Template Name: Members Area
 *
 * Welcome page for logged-in members. Shows personalised greeting, optional
 * looping animation video, optional Sunday-9am countdown, and cards linking
 * to all published audio and video collections.
 *
 * @package Ontrack
 */

ontrack_members_gate();

$current_user = wp_get_current_user();

$post_id        = get_the_ID();
$show_animation = (bool) get_post_meta( $post_id, '_ontrack_members_show_animation', true );
$animation_id   = (int) get_post_meta( $post_id, '_ontrack_members_animation_id', true );
$animation_url  = $animation_id ? wp_get_attachment_url( $animation_id ) : '';
$show_countdown = (bool) get_post_meta( $post_id, '_ontrack_members_show_countdown', true );

$audio_query_args = array(
	'post_type'      => 'audio_collection',
	'posts_per_page' => -1,
	'post_status'    => 'publish',
	'orderby'        => 'menu_order title',
	'order'          => 'ASC',
	'no_found_rows'  => true,
);

$video_query_args = array(
	'post_type'      => 'video_collection',
	'posts_per_page' => -1,
	'post_status'    => 'publish',
	'orderby'        => 'menu_order title',
	'order'          => 'ASC',
	'no_found_rows'  => true,
);

if ( function_exists( 'ontrack_is_catalogue_enforcement_enabled' ) && ontrack_is_catalogue_enforcement_enabled() ) {
	$_uid            = get_current_user_id();
	$_is_full_member = function_exists( 'ontrack_user_is_full_member' ) && ontrack_user_is_full_member( $_uid );

	if ( ! $_is_full_member ) {
		$_mq = function_exists( 'ontrack_get_catalogue_archive_meta_query' )
			? ontrack_get_catalogue_archive_meta_query( $_uid )
			: null;
		if ( $_mq ) {
			$audio_query_args['meta_query'] = $_mq;
			$video_query_args['meta_query'] = $_mq;
		}
	} else {
		if ( function_exists( 'ontrack_get_group_excluded_ids_for_user' ) ) {
			$_excl_audio = ontrack_get_group_excluded_ids_for_user( $_uid, 'audio_collection' );
			$_excl_video = ontrack_get_group_excluded_ids_for_user( $_uid, 'video_collection' );
			if ( ! empty( $_excl_audio ) ) {
				$audio_query_args['post__not_in'] = $_excl_audio;
			}
			if ( ! empty( $_excl_video ) ) {
				$video_query_args['post__not_in'] = $_excl_video;
			}
		}
	}
}

$audio_query = new WP_Query( $audio_query_args );
$video_query = new WP_Query( $video_query_args );

$events_query = new WP_Query( array(
	'post_type'      => 'ontrack_event',
	'post_status'    => 'publish',
	'posts_per_page' => 3,
	'no_found_rows'  => true,
	'meta_query'     => array(
		'event_date_clause' => array(
			'key'     => '_event_datetime',
			'value'   => current_time( 'Y-m-d H:i:s' ),
			'compare' => '>=',
			'type'    => 'DATETIME',
		),
	),
	'orderby' => array( 'event_date_clause' => 'ASC' ),
) );
?>

	<main id="primary" class="site-main">

		<div class="ontrack-members-area">

			<?php get_template_part( 'template-parts/members-subnav' ); ?>

			<?php if ( $show_animation && $animation_url ) : ?>
			<div class="ontrack-members-animation" aria-hidden="true">
				<video class="ontrack-members-animation__video" autoplay muted loop playsinline>
					<source src="<?php echo esc_url( $animation_url ); ?>" type="video/mp4" />
				</video>
			</div>
			<?php endif; ?>

			<div class="ontrack-members-welcome">

				<h1 class="ontrack-members-welcome__heading">
					<?php
					$first_name = $current_user->first_name ?: $current_user->display_name;
					/* translators: %s: member first name */
					echo esc_html( sprintf( __( 'Welcome, %s', 'ontrack' ), $first_name ) );
					?>
				</h1>

				<?php if ( $show_countdown ) : ?>
				<div class="ontrack-countdown" id="ontrack-countdown" role="timer" aria-live="off">
					<p class="ontrack-countdown__label"><?php esc_html_e( 'Next Sunday Download', 'ontrack' ); ?></p>
					<div class="ontrack-countdown__grid" id="ontrack-countdown-grid">
						<div class="ontrack-countdown__unit">
							<span class="ontrack-countdown__value" id="ontrack-countdown-days">--</span>
							<span class="ontrack-countdown__unit-label"><?php esc_html_e( 'Days', 'ontrack' ); ?></span>
						</div>
						<div class="ontrack-countdown__unit">
							<span class="ontrack-countdown__value" id="ontrack-countdown-hours">--</span>
							<span class="ontrack-countdown__unit-label"><?php esc_html_e( 'Hours', 'ontrack' ); ?></span>
						</div>
						<div class="ontrack-countdown__unit">
							<span class="ontrack-countdown__value" id="ontrack-countdown-minutes">--</span>
							<span class="ontrack-countdown__unit-label"><?php esc_html_e( 'Minutes', 'ontrack' ); ?></span>
						</div>
						<div class="ontrack-countdown__unit">
							<span class="ontrack-countdown__value" id="ontrack-countdown-seconds">--</span>
							<span class="ontrack-countdown__unit-label"><?php esc_html_e( 'Seconds', 'ontrack' ); ?></span>
						</div>
					</div>
					<p class="ontrack-countdown__inprogress" id="ontrack-countdown-inprogress" hidden>
						<?php esc_html_e( 'Sunday Download in Progress…', 'ontrack' ); ?>
					</p>
				</div>
				<?php endif; ?>

				<?php if ( get_the_content() ) : ?>
				<div class="ontrack-members-welcome__content entry-content">
					<?php the_content(); ?>
				</div>
				<?php endif; ?>

			</div><!-- .ontrack-members-welcome -->

			<?php if ( $events_query->have_posts() ) : ?>
			<section class="ontrack-members-section ontrack-members-upcoming">
				<div class="ontrack-members-section__header">
					<h2 class="ontrack-members-section__title"><?php esc_html_e( 'Upcoming', 'ontrack' ); ?></h2>
					<a class="ontrack-members-section__see-all" href="<?php echo esc_url( get_post_type_archive_link( 'ontrack_event' ) ); ?>">
						<?php esc_html_e( 'See all →', 'ontrack' ); ?>
					</a>
				</div>
				<div class="ontrack-event-list ontrack-event-list--compact">
					<?php while ( $events_query->have_posts() ) : $events_query->the_post(); ?>
						<?php
						$ev_dt       = get_post_meta( get_the_ID(), '_event_datetime', true );
						$ev_location = get_post_meta( get_the_ID(), '_event_location', true );
						$ev_date_str = $ev_dt ? date_i18n( 'D, j M', strtotime( $ev_dt ) ) : '';
						$ev_time_str = $ev_dt ? date_i18n( get_option( 'time_format' ), strtotime( $ev_dt ) ) : '';
						?>
						<a class="ontrack-event-row" href="<?php the_permalink(); ?>">
							<div class="ontrack-event-row__icon" aria-hidden="true">&#128197;</div>
							<div class="ontrack-event-row__content">
								<span class="ontrack-event-row__title"><?php the_title(); ?></span>
								<span class="ontrack-event-row__meta">
									<?php echo esc_html( $ev_date_str ); ?>
									<?php if ( $ev_time_str ) : ?>
										&middot; <?php echo esc_html( $ev_time_str ); ?>
									<?php endif; ?>
									<?php if ( $ev_location ) : ?>
										&middot; <?php echo esc_html( $ev_location ); ?>
									<?php endif; ?>
								</span>
							</div>
							<span class="ontrack-event-row__arrow" aria-hidden="true">&rsaquo;</span>
						</a>
					<?php endwhile; wp_reset_postdata(); ?>
				</div>
			</section>
			<?php endif; ?>

			<?php
			$ontrack_total_collections = (int) $audio_query->post_count + (int) $video_query->post_count;
			?>
			<?php if ( $ontrack_total_collections > 6 ) : ?>
			<div class="ontrack-library-filter" data-ontrack-library-filter hidden>
				<label for="ontrack-library-filter-input"><?php esc_html_e( 'Find a collection', 'ontrack' ); ?></label>
				<input type="search" id="ontrack-library-filter-input" autocomplete="off" placeholder="<?php esc_attr_e( 'Type to filter by title', 'ontrack' ); ?>" />
				<p class="ontrack-library-filter__status" role="status" aria-live="polite"></p>
			</div>
			<?php endif; ?>

			<?php if ( 0 === $ontrack_total_collections ) : ?>
			<p class="ontrack-members-empty">
				<?php esc_html_e( 'No collections are available to you yet. New audio and video will appear here as they are added.', 'ontrack' ); ?>
			</p>
			<?php endif; ?>

			<div class="ontrack-members-collections">

				<?php if ( $audio_query->have_posts() ) : ?>
				<section class="ontrack-members-section">
					<h2 class="ontrack-members-section__title"><?php esc_html_e( 'Audio Collections', 'ontrack' ); ?></h2>
					<div class="ontrack-collection-grid">
						<?php while ( $audio_query->have_posts() ) : $audio_query->the_post(); ?>
							<?php get_template_part( 'template-parts/card-collection', null, array( 'type' => 'audio', 'heading' => 'h3' ) ); ?>
						<?php endwhile; wp_reset_postdata(); ?>
					</div>
					<p class="ontrack-members-section__archive-link">
						<a href="<?php echo esc_url( get_post_type_archive_link( 'audio_collection' ) ); ?>">
							<?php esc_html_e( 'Browse all audio collections →', 'ontrack' ); ?>
						</a>
					</p>
				</section>
				<?php endif; ?>

				<?php if ( $video_query->have_posts() ) : ?>
				<section class="ontrack-members-section">
					<h2 class="ontrack-members-section__title"><?php esc_html_e( 'Video Collections', 'ontrack' ); ?></h2>
					<div class="ontrack-collection-grid">
						<?php while ( $video_query->have_posts() ) : $video_query->the_post(); ?>
							<?php get_template_part( 'template-parts/card-collection', null, array( 'type' => 'video', 'heading' => 'h3' ) ); ?>
						<?php endwhile; wp_reset_postdata(); ?>
					</div>
					<p class="ontrack-members-section__archive-link">
						<a href="<?php echo esc_url( get_post_type_archive_link( 'video_collection' ) ); ?>">
							<?php esc_html_e( 'Browse all video collections →', 'ontrack' ); ?>
						</a>
					</p>
				</section>
				<?php endif; ?>

			</div><!-- .ontrack-members-collections -->

		</div><!-- .ontrack-members-area -->

	</main><!-- #primary -->

<?php
get_sidebar();
get_footer();
