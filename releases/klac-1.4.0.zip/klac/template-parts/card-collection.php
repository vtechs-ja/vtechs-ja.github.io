<?php
/**
 * Collection card (audio or video), shared by the Members Area and archives.
 *
 * Args: 'type' => 'audio'|'video' (default audio), 'heading' => 'h2'|'h3' (default h3).
 *
 * @package Ontrack
 */

$ontrack_args    = wp_parse_args( isset( $args ) ? $args : array(), array( 'type' => 'audio', 'heading' => 'h3' ) );
$ontrack_is_vid  = 'video' === $ontrack_args['type'];
$ontrack_heading = in_array( $ontrack_args['heading'], array( 'h2', 'h3' ), true ) ? $ontrack_args['heading'] : 'h3';
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'ontrack-collection-card' ); ?>>
	<a class="ontrack-collection-card__thumbnail" href="<?php the_permalink(); ?>">
		<?php if ( has_post_thumbnail() ) : ?>
			<?php the_post_thumbnail( 'medium' ); ?>
		<?php else : ?>
			<div class="ontrack-collection-card__thumbnail-placeholder"></div>
		<?php endif; ?>
		<div class="ontrack-collection-card__overlay">
			<span class="ontrack-collection-card__badge"><?php echo $ontrack_is_vid ? esc_html__( 'Video', 'ontrack' ) : esc_html__( 'Audio', 'ontrack' ); ?></span>
			<<?php echo esc_attr( $ontrack_heading ); ?> class="ontrack-collection-card__title"><?php the_title(); ?></<?php echo esc_attr( $ontrack_heading ); ?>>
		</div>
	</a>
	<div class="ontrack-collection-card__body">
		<?php if ( has_excerpt() ) : ?>
			<div class="ontrack-collection-card__summary"><?php the_excerpt(); ?></div>
		<?php endif; ?>
		<a class="ontrack-collection-card__cta button" href="<?php the_permalink(); ?>">
			<?php echo $ontrack_is_vid ? esc_html__( 'Watch', 'ontrack' ) : esc_html__( 'Listen', 'ontrack' ); ?>
		</a>
	</div>
</article>
