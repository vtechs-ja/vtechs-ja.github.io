<?php
/**
 * Front page: closing call to action band above the footer.
 * Edited in Appearance > Customize > Home page & footer. Hidden when empty.
 *
 * @package Ontrack
 */

$heading = trim( (string) get_theme_mod( 'ontrack_cta_heading', '' ) );
$label   = trim( (string) get_theme_mod( 'ontrack_cta_label', '' ) );
$url     = trim( (string) get_theme_mod( 'ontrack_cta_url', '' ) );

if ( '' === $heading ) {
	return;
}
?>
<section class="ontrack-cta-band">
	<div class="ontrack-cta-band__inner">
		<h2 class="ontrack-cta-band__heading"><?php echo esc_html( $heading ); ?></h2>
		<?php if ( '' !== $label && '' !== $url ) : ?>
			<a class="ontrack-btn-accent" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $label ); ?></a>
		<?php endif; ?>
	</div>
</section>
