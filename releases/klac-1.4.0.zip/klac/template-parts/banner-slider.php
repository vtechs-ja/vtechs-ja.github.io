<?php
/**
 * Template part for displaying banner slider
 *
 * @package Ontrack
 */

$banners = ontrack_get_banners();

if ( empty( $banners ) || ! get_theme_mod( 'klac_banner_enable', true ) ) {
	return;
}

$banner_height = get_theme_mod( 'klac_banner_height', 500 );
$autoplay = get_theme_mod( 'klac_banner_autoplay', true );
$duration = get_theme_mod( 'klac_banner_duration', 5000 );
?>

<section class="banner-slider" role="region" aria-roledescription="carousel" aria-label="<?php esc_attr_e( 'Featured photos', 'ontrack' ); ?>" data-autoplay="<?php echo esc_attr( $autoplay ? 'true' : 'false' ); ?>" data-duration="<?php echo esc_attr( $duration ); ?>" style="height: <?php echo esc_attr( $banner_height ); ?>px;">
	<div class="banner-slides">
		<?php foreach ( $banners as $index => $banner ) : 
			$image = get_the_post_thumbnail_url( $banner->ID, 'full' );
			$link = get_post_meta( $banner->ID, '_klac_banner_link', true );
			$button_text = get_post_meta( $banner->ID, '_klac_banner_button_text', true );
			$overlay = get_post_meta( $banner->ID, '_klac_banner_overlay', true );
			$is_active = 0 === $index ? 'active' : '';
			$has_text  = ! empty( $banner->post_content ) || ( ! empty( $link ) && ! empty( $button_text ) );
		?>
			<div class="banner-slide <?php echo esc_attr( $is_active ); ?><?php echo $has_text ? ' has-text' : ''; ?>" role="group" aria-roledescription="slide" aria-label="<?php echo esc_attr( sprintf( /* translators: 1: slide number, 2: total slides. */ __( '%1$d of %2$d', 'ontrack' ), $index + 1, count( $banners ) ) ); ?>"<?php echo 0 === $index ? '' : ' aria-hidden="true"'; ?> style="background-image: url('<?php echo esc_url( $image ); ?>');">
				<?php if ( $overlay ) : ?>
					<div class="banner-overlay"></div>
				<?php endif; ?>
				<?php if ( ! empty( $banner->post_content ) || ( ! empty( $link ) && ! empty( $button_text ) ) ) : ?>
					<div class="banner-content">
						<div class="banner-text">
							<?php if ( ! empty( $banner->post_content ) ) : ?>
								<div class="banner-description">
									<?php echo wp_kses_post( wpautop( $banner->post_content ) ); ?>
								</div>
							<?php endif; ?>
							<?php if ( ! empty( $link ) && ! empty( $button_text ) ) : ?>
								<a href="<?php echo esc_url( $link ); ?>" class="banner-button"><?php echo esc_html( $button_text ); ?></a>
							<?php endif; ?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>
	</div>
	
	<?php if ( count( $banners ) > 1 ) : ?>
		<div class="banner-nav" role="group" aria-label="<?php esc_attr_e( 'Slideshow controls', 'ontrack' ); ?>">
			<button type="button" class="banner-prev" aria-label="<?php esc_attr_e( 'Previous photo', 'ontrack' ); ?>">
				<svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M15.4 6 14 4.6 6.6 12 14 19.4 15.4 18 9.4 12z"/></svg>
			</button>
			<button type="button" class="banner-pause" aria-label="<?php esc_attr_e( 'Pause slideshow', 'ontrack' ); ?>" data-label-pause="<?php esc_attr_e( 'Pause slideshow', 'ontrack' ); ?>" data-label-play="<?php esc_attr_e( 'Play slideshow', 'ontrack' ); ?>">
				<svg class="banner-icon-pause" width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M6 19h4V5H6zm8-14v14h4V5z"/></svg>
				<svg class="banner-icon-play" width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false" hidden><path d="M8 5v14l11-7z"/></svg>
			</button>
			<span class="banner-count" aria-hidden="true">1 / <?php echo esc_html( (string) count( $banners ) ); ?></span>
			<button type="button" class="banner-next" aria-label="<?php esc_attr_e( 'Next photo', 'ontrack' ); ?>">
				<svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M8.6 6 10 4.6 17.4 12 10 19.4 8.6 18l6-6z"/></svg>
			</button>
		</div>
	<?php endif; ?>
</section>

