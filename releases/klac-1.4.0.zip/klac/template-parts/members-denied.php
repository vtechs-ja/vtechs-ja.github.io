<?php
/**
 * "Members Only" screen shown to logged-in users without member access.
 *
 * @package Ontrack
 */

$ontrack_contact = ontrack_members_contact_email();
?>
<main id="primary" class="site-main">
	<div class="ontrack-members-area">
		<?php get_template_part( 'template-parts/members-subnav' ); ?>
		<div class="ontrack-access-denied">
			<h1 class="ontrack-access-denied__heading"><?php esc_html_e( 'Members Only', 'ontrack' ); ?></h1>
			<p><?php esc_html_e( 'Your account does not currently have member access.', 'ontrack' ); ?></p>
			<?php if ( $ontrack_contact ) : ?>
			<p>
				<?php
				printf(
					/* translators: %s: contact email address */
					esc_html__( 'If you believe you should have access, please contact %s.', 'ontrack' ),
					'<a href="mailto:' . esc_attr( $ontrack_contact ) . '">' . esc_html( $ontrack_contact ) . '</a>'
				);
				?>
			</p>
			<?php endif; ?>
			<p class="ontrack-access-denied__actions">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="button"><?php esc_html_e( 'Back to site', 'ontrack' ); ?></a>
				<a href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>" class="button"><?php esc_html_e( 'Log out or switch account', 'ontrack' ); ?></a>
			</p>
		</div>
	</div>
</main>
