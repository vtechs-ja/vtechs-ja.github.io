<?php
/**
 * Front page: Focus areas card grid.
 *
 * Queries immediate child pages of the front page ordered by menu_order and
 * renders them as a responsive 3-column card grid. To populate the grid:
 * create child pages under the home page in wp-admin, set a featured image
 * and excerpt on each, and drag them into order via Pages > All Pages.
 *
 * @package Ontrack
 */

$focus_pages = get_pages( [
	'parent'      => get_queried_object_id(),
	'sort_column' => 'menu_order',
	'number'      => 6,
] );

if ( empty( $focus_pages ) ) {
	return;
}
?>
<?php
$cards_heading    = trim( (string) get_theme_mod( 'ontrack_cards_heading', '' ) );
$cards_subheading = trim( (string) get_theme_mod( 'ontrack_cards_subheading', '' ) );
?>
<section class="home-focus-areas">
	<?php if ( '' !== $cards_heading ) : ?>
		<div class="home-focus-intro">
			<h2 class="home-focus-intro__heading"><?php echo esc_html( $cards_heading ); ?></h2>
			<?php if ( '' !== $cards_subheading ) : ?>
				<p class="home-focus-intro__sub"><?php echo esc_html( $cards_subheading ); ?></p>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<div class="home-focus-grid">
		<?php foreach ( $focus_pages as $focus_page ) : ?>
			<article class="home-focus-card">
				<?php if ( has_post_thumbnail( $focus_page->ID ) ) : ?>
					<div class="home-focus-card__image">
						<?php echo get_the_post_thumbnail( $focus_page->ID, 'medium_large', [ 'loading' => 'lazy' ] ); ?>
					</div>
				<?php endif; ?>
				<div class="home-focus-card__body">
					<h3 class="home-focus-card__title"><?php echo esc_html( $focus_page->post_title ); ?></h3>
					<?php
					$excerpt = $focus_page->post_excerpt
						? $focus_page->post_excerpt
						: wp_trim_words( strip_shortcodes( wp_strip_all_tags( $focus_page->post_content ) ), 25, '&hellip;' );
					?>
					<?php if ( $excerpt ) : ?>
						<p class="home-focus-card__excerpt"><?php echo esc_html( $excerpt ); ?></p>
					<?php endif; ?>
					<a class="home-focus-card__link" href="<?php echo esc_url( get_permalink( $focus_page->ID ) ); ?>">
						<?php esc_html_e( 'Read more', 'ontrack' ); ?> &rarr;
					</a>
				</div>
			</article>
		<?php endforeach; ?>
	</div>
</section>
