<?php
/**
 * Front page: visit bar under the banner (service time, address, directions).
 * Edited in Appearance > Customize > Home page & footer. Hidden when empty.
 *
 * @package Ontrack
 */

$visit      = ontrack_visit_details();
$directions = ontrack_directions_url();

if ( '' === $visit['time'] && '' === $visit['address'] ) {
	return;
}
?>
<section class="ontrack-visit" aria-label="<?php esc_attr_e( 'Visit us', 'ontrack' ); ?>">
	<div class="ontrack-visit__box">
		<?php if ( '' !== $visit['time'] ) : ?>
			<div class="ontrack-visit__cell">
				<span class="ontrack-visit__label"><?php esc_html_e( 'Service', 'ontrack' ); ?></span>
				<span class="ontrack-visit__value"><?php echo esc_html( $visit['time'] ); ?></span>
				<?php if ( '' !== $visit['time_note'] ) : ?>
					<span class="ontrack-visit__note"><?php echo esc_html( $visit['time_note'] ); ?></span>
				<?php endif; ?>
			</div>
		<?php endif; ?>
		<?php if ( '' !== $visit['address'] ) : ?>
			<div class="ontrack-visit__cell">
				<span class="ontrack-visit__label"><?php esc_html_e( 'Find us', 'ontrack' ); ?></span>
				<span class="ontrack-visit__value"><?php echo nl2br( esc_html( $visit['address'] ) ); ?></span>
				<?php if ( '' !== $visit['address_note'] ) : ?>
					<span class="ontrack-visit__note"><?php echo esc_html( $visit['address_note'] ); ?></span>
				<?php endif; ?>
			</div>
		<?php endif; ?>
		<?php if ( '' !== $directions ) : ?>
			<div class="ontrack-visit__cell ontrack-visit__cell--action">
				<a class="ontrack-btn-accent" href="<?php echo esc_url( $directions ); ?>" target="_blank" rel="noopener">
					<?php esc_html_e( 'Get directions', 'ontrack' ); ?>
					<span class="screen-reader-text"><?php esc_html_e( '(opens in a new tab)', 'ontrack' ); ?></span>
				</a>
			</div>
		<?php endif; ?>
	</div>
</section>
