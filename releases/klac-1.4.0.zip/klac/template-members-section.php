<?php
/**
 * Template Name: Members Section
 *
 * Used for child pages within the Members Area (e.g. Audio, Video).
 * Applies the same access checks as the Members Area template and renders
 * the shared sub-navigation above the page content.
 *
 * @package Ontrack
 */

ontrack_members_gate();
?>

	<main id="primary" class="site-main">

		<div class="ontrack-members-area">

			<?php get_template_part( 'template-parts/members-subnav' ); ?>

			<div class="ontrack-members-section-content">

				<?php while ( have_posts() ) : the_post(); ?>

					<header class="ontrack-members-section-content__header">
						<h1 class="ontrack-members-section-content__title"><?php the_title(); ?></h1>
					</header>

					<?php if ( get_the_content() ) : ?>
					<div class="entry-content">
						<?php the_content(); ?>
					</div>
					<?php endif; ?>

				<?php endwhile; ?>

			</div><!-- .ontrack-members-section-content -->

		</div><!-- .ontrack-members-area -->

	</main><!-- #primary -->

<?php
get_sidebar();
get_footer();
