<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Ontrack
 */

$visit      = ontrack_visit_details();
$directions = ontrack_directions_url();
$social     = ontrack_social_links();
$privacy    = function_exists( 'get_privacy_policy_url' ) ? get_privacy_policy_url() : '';
$tagline    = get_bloginfo( 'description' );
$has_visit  = '' !== $visit['time'] || '' !== $visit['address'];
$has_links  = has_nav_menu( 'footer-menu' ) || ! empty( $social ) || '' !== $privacy;
?>

	<footer id="colophon" class="site-footer">
		<div class="footer-container">
			<?php if ( $has_visit || $has_links ) : ?>
				<div class="footer-columns">
					<div class="footer-column footer-column--about">
						<p class="footer-name"><?php bloginfo( 'name' ); ?></p>
						<?php if ( '' !== $tagline ) : ?>
							<p><?php echo esc_html( $tagline ); ?></p>
						<?php endif; ?>
					</div>

					<?php if ( $has_visit ) : ?>
						<div class="footer-column">
							<h2 class="footer-heading"><?php esc_html_e( 'Visit', 'ontrack' ); ?></h2>
							<?php if ( '' !== $visit['time'] ) : ?>
								<p><?php echo esc_html( $visit['time'] ); ?></p>
							<?php endif; ?>
							<?php if ( '' !== $visit['address'] ) : ?>
								<p><?php echo nl2br( esc_html( $visit['address'] ) ); ?></p>
							<?php endif; ?>
							<?php if ( '' !== $directions ) : ?>
								<p><a href="<?php echo esc_url( $directions ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Get directions', 'ontrack' ); ?><span class="screen-reader-text"> <?php esc_html_e( '(opens in a new tab)', 'ontrack' ); ?></span></a></p>
							<?php endif; ?>
						</div>
					<?php endif; ?>

					<?php if ( $has_links ) : ?>
						<div class="footer-column">
							<h2 class="footer-heading"><?php esc_html_e( 'Connect', 'ontrack' ); ?></h2>
							<?php if ( has_nav_menu( 'footer-menu' ) ) : ?>
								<nav class="footer-navigation" aria-label="<?php esc_attr_e( 'Footer', 'ontrack' ); ?>">
									<?php
									wp_nav_menu(
										array(
											'theme_location' => 'footer-menu',
											'menu_id'        => 'footer-menu',
											'container'      => false,
											'depth'          => 1,
										)
									);
									?>
								</nav>
							<?php endif; ?>
							<?php if ( ! empty( $social ) || '' !== $privacy ) : ?>
								<ul class="footer-links">
									<?php foreach ( $social as $label => $url ) : ?>
										<li><a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $label ); ?><span class="screen-reader-text"> <?php esc_html_e( '(opens in a new tab)', 'ontrack' ); ?></span></a></li>
									<?php endforeach; ?>
									<?php if ( '' !== $privacy ) : ?>
										<li><a href="<?php echo esc_url( $privacy ); ?>"><?php esc_html_e( 'Privacy policy', 'ontrack' ); ?></a></li>
									<?php endif; ?>
								</ul>
							<?php endif; ?>
						</div>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<div class="site-info">
				<p class="copyright">
					&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'All rights reserved.', 'ontrack' ); ?>
				</p>
			</div><!-- .site-info -->
		</div><!-- .footer-container -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
