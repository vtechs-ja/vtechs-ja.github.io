<?php
/**
 * Members area helpers: access gate, branded login, login redirect, menu link, robots.
 *
 * @package Ontrack
 */

/**
 * Whether a user may use the members area.
 * Uses the membership plugin; without it nobody is admitted (fails closed).
 *
 * @param int $user_id User ID.
 * @return bool
 */
function ontrack_members_user_can_access( $user_id ) {
	if ( function_exists( 'ontrack_user_is_full_member' ) ) {
		return (bool) ontrack_user_is_full_member( $user_id );
	}
	return (bool) apply_filters( 'ontrack_members_fallback_access', false, $user_id );
}

/**
 * Gate a members template: send guests to login, show the denied screen to
 * non-members. Call before any output; returns only when access is granted.
 */
function ontrack_members_gate() {
	if ( ! is_user_logged_in() ) {
		auth_redirect();
	}

	if ( ontrack_members_user_can_access( get_current_user_id() ) ) {
		get_header();
		return;
	}

	get_header();
	get_template_part( 'template-parts/members-denied' );
	get_footer();
	exit;
}

/**
 * Contact address shown on the denied screen (Customizer, falling back to the admin email).
 *
 * @return string
 */
function ontrack_members_contact_email() {
	$email = sanitize_email( (string) get_theme_mod( 'ontrack_support_email', '' ) );
	return $email ? $email : (string) get_option( 'admin_email' );
}

/**
 * URL of the page using the Members Area template, or ''.
 *
 * @return string
 */
function ontrack_members_area_url() {
	static $url = null;
	if ( null === $url ) {
		$pages = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'meta_key'       => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => 'template-members-area.php', // phpcs:ignore WordPress.DB.SlowDBQuery
				'orderby'        => 'menu_order ID',
				'order'          => 'ASC',
				'no_found_rows'  => true,
			)
		);
		$url = $pages ? (string) get_permalink( $pages[0] ) : '';
	}
	return $url;
}

/**
 * Whether the current request is a members page (templates, collections, events).
 *
 * @return bool
 */
function ontrack_is_members_request() {
	return is_page_template( array( 'template-members-area.php', 'template-members-section.php' ) )
		|| is_singular( array( 'audio_collection', 'video_collection', 'ontrack_event' ) )
		|| is_post_type_archive( array( 'audio_collection', 'video_collection', 'ontrack_event' ) );
}

/**
 * Keep members pages out of search engines.
 *
 * @param array $robots Robots directives.
 * @return array
 */
function ontrack_members_robots( $robots ) {
	if ( ontrack_is_members_request() ) {
		$robots['noindex']  = true;
		$robots['nofollow'] = true;
		unset( $robots['max-image-preview'] );
	}
	return $robots;
}
add_filter( 'wp_robots', 'ontrack_members_robots' );

/**
 * Send members who log in without a specific destination to the Members Area
 * instead of the WordPress dashboard.
 *
 * @param string           $redirect_to Destination.
 * @param string           $requested   Requested destination ('' when none).
 * @param WP_User|WP_Error $user        Authenticated user.
 * @return string
 */
function ontrack_members_login_redirect( $redirect_to, $requested, $user ) {
	if ( $user instanceof WP_User && '' === (string) $requested && ! user_can( $user, 'edit_posts' ) ) {
		$members = ontrack_members_area_url();
		if ( $members ) {
			return $members;
		}
	}
	return $redirect_to;
}
add_filter( 'login_redirect', 'ontrack_members_login_redirect', 10, 3 );

/**
 * Brand the WordPress login screen: site logo, theme accent colour, site link.
 */
function ontrack_login_styles() {
	$accent   = sanitize_hex_color( (string) get_theme_mod( 'klac_primary_color', '#4169e1' ) );
	$accent   = $accent ? $accent : '#4169e1';
	$logo_id  = (int) get_theme_mod( 'custom_logo' );
	$logo_url = $logo_id ? wp_get_attachment_image_url( $logo_id, 'medium' ) : '';
	?>
	<style>
		body.login { background: #f6f7f9; }
		.login h1 a {
			<?php if ( $logo_url ) : ?>
			background-image: url('<?php echo esc_url( $logo_url ); ?>');
			background-size: contain;
			width: 240px;
			height: 90px;
			<?php else : ?>
			background-image: none;
			font-size: 1.6rem;
			font-weight: 600;
			text-indent: 0;
			width: auto;
			height: auto;
			color: <?php echo esc_attr( $accent ); ?>;
			<?php endif; ?>
		}
		.login form { border-radius: 8px; border: 1px solid #dcdfe4; box-shadow: 0 2px 8px rgba(0,0,0,.05); }
		.login .button-primary { background: <?php echo esc_attr( $accent ); ?>; border-color: <?php echo esc_attr( $accent ); ?>; }
		.login .button-primary:hover, .login .button-primary:focus { filter: brightness(.9); }
		.login #nav a, .login #backtoblog a { color: <?php echo esc_attr( $accent ); ?>; }
		.login input:focus, .login .button:focus { outline: 2px solid <?php echo esc_attr( $accent ); ?>; outline-offset: 1px; }
	</style>
	<?php
}
add_action( 'login_enqueue_scripts', 'ontrack_login_styles' );

add_filter( 'login_headerurl', 'home_url' );
add_filter(
	'login_headertext',
	function () {
		return get_bloginfo( 'name' );
	}
);

/**
 * Optional login / log-out link at the end of the primary menu.
 *
 * @param string   $items Menu HTML.
 * @param stdClass $args  Menu args.
 * @return string
 */
function ontrack_menu_login_link( $items, $args ) {
	if ( 'menu-1' !== $args->theme_location || ! get_theme_mod( 'ontrack_menu_login_link', false ) ) {
		return $items;
	}
	if ( is_user_logged_in() ) {
		$link = '<a href="' . esc_url( wp_logout_url( home_url( '/' ) ) ) . '">' . esc_html__( 'Log out', 'ontrack' ) . '</a>';
	} else {
		$target = ontrack_members_area_url();
		$link   = '<a href="' . esc_url( wp_login_url( $target ? $target : home_url( '/' ) ) ) . '">' . esc_html__( 'Member login', 'ontrack' ) . '</a>';
	}
	return $items . '<li class="menu-item menu-item-ontrack-login">' . $link . '</li>';
}
add_filter( 'wp_nav_menu_items', 'ontrack_menu_login_link', 10, 2 );

/**
 * Customizer: members area settings.
 *
 * @param WP_Customize_Manager $wp_customize Customizer.
 */
function ontrack_members_customize_register( $wp_customize ) {
	$wp_customize->add_section(
		'ontrack_members',
		array(
			'title'    => __( 'Members Area', 'ontrack' ),
			'priority' => 60,
		)
	);

	$wp_customize->add_setting(
		'ontrack_support_email',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_email',
		)
	);
	$wp_customize->add_control(
		'ontrack_support_email',
		array(
			'label'       => __( 'Support email', 'ontrack' ),
			'description' => __( 'Shown to people who are signed in but are not members. Leave empty to use the site admin email.', 'ontrack' ),
			'section'     => 'ontrack_members',
			'type'        => 'email',
		)
	);

	$wp_customize->add_setting(
		'ontrack_menu_login_link',
		array(
			'default'           => false,
			'sanitize_callback' => 'rest_sanitize_boolean',
		)
	);
	$wp_customize->add_control(
		'ontrack_menu_login_link',
		array(
			'label'       => __( 'Add a login / log out link to the primary menu', 'ontrack' ),
			'description' => __( 'Leave off if your menu already has a Members Area or login item.', 'ontrack' ),
			'section'     => 'ontrack_members',
			'type'        => 'checkbox',
		)
	);
}
add_action( 'customize_register', 'ontrack_members_customize_register' );
