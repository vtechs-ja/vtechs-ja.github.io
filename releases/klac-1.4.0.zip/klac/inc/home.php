<?php
/**
 * Home page and footer content: visit details, section headings, closing band
 * and social links. Everything here is editable in Appearance > Customize.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the "Home page & footer" Customizer section.
 *
 * @param WP_Customize_Manager $wp_customize Customizer.
 */
function ontrack_home_customize_register( $wp_customize ) {
	$wp_customize->add_section(
		'ontrack_home',
		array(
			'title'       => __( 'Home page & footer', 'ontrack' ),
			'description' => __( 'Text and links for the visit bar under the banner, the cards section, the closing call to action and the footer. Anything left empty is hidden.', 'ontrack' ),
			'priority'    => 55,
		)
	);

	$fields = array(
		'ontrack_visit_time'      => array(
			'label'       => __( 'Service time', 'ontrack' ),
			'description' => __( 'For example: Sundays at 9:00 am', 'ontrack' ),
			'type'        => 'text',
			'sanitize'    => 'sanitize_text_field',
		),
		'ontrack_visit_time_note' => array(
			'label'    => __( 'Service time note', 'ontrack' ),
			'description' => __( 'Optional second line, such as: Doors open 8:30 am', 'ontrack' ),
			'type'     => 'text',
			'sanitize' => 'sanitize_text_field',
		),
		'ontrack_visit_address'   => array(
			'label'       => __( 'Address', 'ontrack' ),
			'description' => __( 'Used for the visit bar, the footer and the Get directions link.', 'ontrack' ),
			'type'        => 'textarea',
			'sanitize'    => 'sanitize_textarea_field',
		),
		'ontrack_visit_address_note' => array(
			'label'       => __( 'Address note', 'ontrack' ),
			'description' => __( 'Optional second line, such as: Free parking on site', 'ontrack' ),
			'type'        => 'text',
			'sanitize'    => 'sanitize_text_field',
		),
		'ontrack_visit_maps_url'  => array(
			'label'       => __( 'Map link (optional)', 'ontrack' ),
			'description' => __( 'Paste a Google Maps link to use instead of one built from the address.', 'ontrack' ),
			'type'        => 'url',
			'sanitize'    => 'esc_url_raw',
		),
		'ontrack_cards_heading'   => array(
			'label'    => __( 'Cards section heading', 'ontrack' ),
			'type'     => 'text',
			'sanitize' => 'sanitize_text_field',
		),
		'ontrack_cards_subheading' => array(
			'label'    => __( 'Cards section sub-heading', 'ontrack' ),
			'type'     => 'text',
			'sanitize' => 'sanitize_text_field',
		),
		'ontrack_cta_heading'     => array(
			'label'       => __( 'Closing call to action: heading', 'ontrack' ),
			'description' => __( 'Shown in a dark band above the footer. Leave empty to hide the band.', 'ontrack' ),
			'type'        => 'text',
			'sanitize'    => 'sanitize_text_field',
		),
		'ontrack_cta_label'       => array(
			'label'    => __( 'Closing call to action: button label', 'ontrack' ),
			'type'     => 'text',
			'sanitize' => 'sanitize_text_field',
		),
		'ontrack_cta_url'         => array(
			'label'    => __( 'Closing call to action: button link', 'ontrack' ),
			'type'     => 'url',
			'sanitize' => 'esc_url_raw',
		),
		'ontrack_social_facebook' => array(
			'label'    => __( 'Facebook link', 'ontrack' ),
			'type'     => 'url',
			'sanitize' => 'esc_url_raw',
		),
		'ontrack_social_instagram' => array(
			'label'    => __( 'Instagram link', 'ontrack' ),
			'type'     => 'url',
			'sanitize' => 'esc_url_raw',
		),
		'ontrack_social_youtube'  => array(
			'label'    => __( 'YouTube link', 'ontrack' ),
			'type'     => 'url',
			'sanitize' => 'esc_url_raw',
		),
	);

	foreach ( $fields as $id => $field ) {
		$wp_customize->add_setting(
			$id,
			array(
				'default'           => '',
				'sanitize_callback' => $field['sanitize'],
			)
		);
		$control = array(
			'label'   => $field['label'],
			'section' => 'ontrack_home',
			'type'    => $field['type'],
		);
		if ( ! empty( $field['description'] ) ) {
			$control['description'] = $field['description'];
		}
		$wp_customize->add_control( $id, $control );
	}
}
add_action( 'customize_register', 'ontrack_home_customize_register' );

/**
 * Visit details, trimmed. Missing values are empty strings.
 *
 * @return array<string,string>
 */
function ontrack_visit_details() {
	return array(
		'time'         => trim( (string) get_theme_mod( 'ontrack_visit_time', '' ) ),
		'time_note'    => trim( (string) get_theme_mod( 'ontrack_visit_time_note', '' ) ),
		'address'      => trim( (string) get_theme_mod( 'ontrack_visit_address', '' ) ),
		'address_note' => trim( (string) get_theme_mod( 'ontrack_visit_address_note', '' ) ),
	);
}

/**
 * Link for "Get directions": the pasted map link, else a Google Maps search for
 * the address. Empty when neither is set.
 *
 * @return string
 */
function ontrack_directions_url() {
	$custom = trim( (string) get_theme_mod( 'ontrack_visit_maps_url', '' ) );
	if ( '' !== $custom ) {
		return esc_url_raw( $custom );
	}
	$address = trim( (string) get_theme_mod( 'ontrack_visit_address', '' ) );
	if ( '' === $address ) {
		return '';
	}
	return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( preg_replace( '/\s*[\r\n]+\s*/', ', ', $address ) );
}

/**
 * Social links that have been filled in: label => URL.
 *
 * @return array<string,string>
 */
function ontrack_social_links() {
	$map   = array(
		'ontrack_social_facebook'  => __( 'Facebook', 'ontrack' ),
		'ontrack_social_instagram' => __( 'Instagram', 'ontrack' ),
		'ontrack_social_youtube'   => __( 'YouTube', 'ontrack' ),
	);
	$links = array();
	foreach ( $map as $key => $label ) {
		$url = trim( (string) get_theme_mod( $key, '' ) );
		if ( '' !== $url ) {
			$links[ $label ] = $url;
		}
	}
	return $links;
}

/**
 * Readable text colour (navy or white) for a given background colour.
 *
 * @param string $hex Background, as #rgb or #rrggbb.
 * @return string Hex colour.
 */
function ontrack_readable_ink( $hex ) {
	$hex = ltrim( (string) $hex, '#' );
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	if ( 6 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
		return '#1b2438';
	}
	$lin = array();
	foreach ( array( 0, 2, 4 ) as $i ) {
		$c     = hexdec( substr( $hex, $i, 2 ) ) / 255;
		$lin[] = $c <= 0.03928 ? $c / 12.92 : pow( ( $c + 0.055 ) / 1.055, 2.4 );
	}
	$lum = 0.2126 * $lin[0] + 0.7152 * $lin[1] + 0.0722 * $lin[2];
	// Navy on the colour versus white on the colour: pick the higher contrast.
	$navy_contrast  = ( $lum + 0.05 ) / ( 0.0177 + 0.05 );
	$white_contrast = 1.05 / ( $lum + 0.05 );
	return $navy_contrast >= $white_contrast ? '#1b2438' : '#ffffff';
}

/**
 * Give the Members Area menu item a class so the theme can style it as a button.
 *
 * @param string[] $classes Menu item classes.
 * @param WP_Post  $item    Menu item.
 * @return string[]
 */
function ontrack_members_menu_item_class( $classes, $item ) {
	if ( ! function_exists( 'ontrack_members_area_url' ) || empty( $item->url ) ) {
		return $classes;
	}
	$members_url = ontrack_members_area_url();
	if ( $members_url && untrailingslashit( $item->url ) === untrailingslashit( $members_url ) ) {
		$classes[] = 'menu-item-members';
	}
	return $classes;
}
add_filter( 'nav_menu_css_class', 'ontrack_members_menu_item_class', 10, 2 );
