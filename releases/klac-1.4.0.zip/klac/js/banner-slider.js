/**
 * Banner slider: crossfading slides with previous / next / pause controls.
 * Autoplay is off for visitors who prefer reduced motion and stops once the
 * visitor pauses it, uses a control, or moves keyboard focus into the slider.
 */
(function () {
	'use strict';

	var slider = document.querySelector('.banner-slider');
	if (!slider) {
		return;
	}

	var slides = slider.querySelectorAll('.banner-slide');
	var prevButton = slider.querySelector('.banner-prev');
	var nextButton = slider.querySelector('.banner-next');
	var pauseButton = slider.querySelector('.banner-pause');
	var countEl = slider.querySelector('.banner-count');
	var duration = parseInt(slider.getAttribute('data-duration'), 10) || 5000;
	var wantsAutoplay = slider.getAttribute('data-autoplay') === 'true';
	var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	var current = 0;
	var timer = null;
	var userPaused = !wantsAutoplay || reduceMotion;
	var hoverPaused = false;

	function show(index) {
		current = (index + slides.length) % slides.length;
		slides.forEach(function (slide, i) {
			var on = i === current;
			slide.classList.toggle('active', on);
			if (on) {
				slide.removeAttribute('aria-hidden');
			} else {
				slide.setAttribute('aria-hidden', 'true');
			}
		});
		if (countEl) {
			countEl.textContent = (current + 1) + ' / ' + slides.length;
		}
	}

	function stop() {
		clearInterval(timer);
		timer = null;
	}

	function start() {
		stop();
		if (!userPaused && !hoverPaused && slides.length > 1) {
			timer = setInterval(function () { show(current + 1); }, duration);
		}
	}

	function updatePauseButton() {
		if (!pauseButton) {
			return;
		}
		var iconPause = pauseButton.querySelector('.banner-icon-pause');
		var iconPlay = pauseButton.querySelector('.banner-icon-play');
		if (iconPause) { iconPause.hidden = userPaused; }
		if (iconPlay) { iconPlay.hidden = !userPaused; }
		pauseButton.setAttribute('aria-label', pauseButton.getAttribute(userPaused ? 'data-label-play' : 'data-label-pause'));
	}

	if (prevButton) {
		prevButton.addEventListener('click', function () { show(current - 1); start(); });
	}
	if (nextButton) {
		nextButton.addEventListener('click', function () { show(current + 1); start(); });
	}
	if (pauseButton) {
		pauseButton.addEventListener('click', function () {
			userPaused = !userPaused;
			if (!userPaused) {
				// An explicit Play overrides the pause-on-focus / pause-on-hover rule.
				hoverPaused = false;
			}
			updatePauseButton();
			start();
		});
	}

	slider.addEventListener('mouseenter', function () { hoverPaused = true; stop(); });
	slider.addEventListener('mouseleave', function () { hoverPaused = false; start(); });
	slider.addEventListener('focusin', function () { hoverPaused = true; stop(); });
	slider.addEventListener('focusout', function () { hoverPaused = false; start(); });

	// Arrow keys only act while focus is inside the slider.
	slider.addEventListener('keydown', function (e) {
		if (e.key === 'ArrowLeft') {
			show(current - 1);
			start();
		} else if (e.key === 'ArrowRight') {
			show(current + 1);
			start();
		}
	});

	updatePauseButton();
	start();
})();
