/**
 * Members Area: filter collection cards by title as the member types.
 * Progressive enhancement — the filter box is hidden until this script runs.
 */
( function () {
	var box = document.querySelector( '[data-ontrack-library-filter]' );
	if ( ! box ) {
		return;
	}
	var input = box.querySelector( 'input' );
	var status = box.querySelector( '.ontrack-library-filter__status' );
	var cards = Array.prototype.slice.call( document.querySelectorAll( '.ontrack-members-collections .ontrack-collection-card' ) );
	var sections = Array.prototype.slice.call( document.querySelectorAll( '.ontrack-members-collections .ontrack-members-section' ) );

	box.hidden = false;

	function titleOf( card ) {
		var t = card.querySelector( '.ontrack-collection-card__title' );
		return ( t ? t.textContent : '' ).toLowerCase();
	}

	input.addEventListener( 'input', function () {
		var q = input.value.trim().toLowerCase();
		var shown = 0;
		cards.forEach( function ( card ) {
			var match = ! q || titleOf( card ).indexOf( q ) !== -1;
			card.hidden = ! match;
			if ( match ) {
				shown++;
			}
		} );
		sections.forEach( function ( section ) {
			var any = section.querySelector( '.ontrack-collection-card:not([hidden])' );
			section.hidden = ! any;
		} );
		status.textContent = q ? ( shown ? shown + ' found' : 'No collections match “' + input.value.trim() + '”.' ) : '';
	} );
}() );
