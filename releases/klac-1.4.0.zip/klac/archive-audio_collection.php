<?php
/**
 * Archive template for Audio Collections.
 *
 * Displays a card grid — title, thumbnail, description, and a link to the
 * single collection page where the player loads. Does not embed the player
 * here to avoid loading every playlist simultaneously.
 *
 * @package Ontrack
 */

get_header();
?>

	<main id="primary" class="site-main">

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<?php the_archive_title( '<h1 class="page-title">', '</h1>' ); ?>
			</header>

			<div class="ontrack-collection-grid">

				<?php while ( have_posts() ) : the_post(); ?>

					<?php get_template_part( 'template-parts/card-collection', null, array( 'type' => 'audio', 'heading' => 'h2' ) ); ?>

				<?php endwhile; ?>

			</div><!-- .ontrack-collection-grid -->

			<?php the_posts_navigation(); ?>

		<?php else : ?>

			<header class="page-header">
				<h1 class="page-title"><?php post_type_archive_title(); ?></h1>
			</header>
			<p class="ontrack-members-empty">
				<?php esc_html_e( 'No collections are available to you yet. New items will appear here as they are added.', 'ontrack' ); ?>
			</p>

		<?php endif; ?>

	</main><!-- #main -->

<?php
get_sidebar();
get_footer();
