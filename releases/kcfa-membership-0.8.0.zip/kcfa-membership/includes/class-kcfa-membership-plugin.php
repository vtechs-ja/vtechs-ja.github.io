<?php
/**
 * Core plugin loader.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main plugin class. Add hooks in register_hooks().
 */
class Ontrack_Plugin {

	/**
	 * Option name storing the last installed plugin version (for migration steps).
	 *
	 * @var string
	 */
	const VERSION_OPTION = 'ontrack_plugin_version';

	/** @var string WP cron hook for refresh token cleanup. */
	const CRON_CLEANUP_HOOK = 'ontrack_cleanup_refresh_tokens';

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Stores a JWT error to surface via rest_authentication_errors.
	 *
	 * @var WP_Error|null
	 */
	private static $jwt_auth_error = null;

	/**
	 * Get singleton instance.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->register_hooks();
	}

	/**
	 * Register WordPress hooks. Expand as features are implemented.
	 */
	private function register_hooks() {
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- core action.
		add_action( 'plugins_loaded', array( $this, 'load_textdomain' ), 5 );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- core action.
		add_action( 'plugins_loaded', array( $this, 'maybe_upgrade' ), 10 );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- core action.
		add_action( 'plugins_loaded', array( $this, 'init_admin' ), 20 );

		// JWT Bearer token validation — runs on every request, passes through when no Bearer header.
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- core filter.
		add_filter( 'determine_current_user', array( $this, 'filter_determine_current_user' ), 20 );
		// Surface JWT errors as clean 401 responses in REST contexts.
		add_filter( 'rest_authentication_errors', array( $this, 'filter_rest_authentication_errors' ) );

		// REST API: auth endpoints (not admin-only).
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- core action.
		add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );

		// Cron: refresh token cleanup.
		add_action( self::CRON_CLEANUP_HOOK, array( $this, 'cleanup_expired_refresh_tokens' ) );

		// Admin-post: regenerate JWT signing secret.
		add_action( 'admin_post_ontrack_regenerate_jwt_secret', array( $this, 'handle_regenerate_jwt_secret' ) );

		$group_post_type = new Ontrack_Group_Post_Type();
		$group_post_type->register();
	}

	/**
	 * Run activation routines when the plugin version changes (e.g. new capabilities).
	 */
	public function maybe_upgrade() {
		$stored = get_option( self::VERSION_OPTION, '' );
		if ( version_compare( (string) $stored, ONTRACK_VERSION, '<' ) ) {
			Ontrack_Activator::activate();
			update_option( self::VERSION_OPTION, ONTRACK_VERSION, false );
		}
	}

	/**
	 * Admin-only components.
	 */
	public function init_admin() {
		if ( ! is_admin() ) {
			return;
		}
		$settings = new Ontrack_Settings_Admin();
		$settings->register();
		$user_admin = new Ontrack_User_Admin();
		$user_admin->register();
		$demographics = new Ontrack_Demographics_Admin();
		$demographics->register();
		$group_meta = new Ontrack_Group_Admin_Meta();
		$group_meta->register();
		$user_groups = new Ontrack_User_Groups_Admin();
		$user_groups->register();
		$mismatch_admin = new Ontrack_Mismatch_Admin();
		$mismatch_admin->register();
		$management_menu = new Ontrack_Management_Menu();
		$management_menu->register();
		$coordinator_admin = new Ontrack_Coordinator_Admin();
		$coordinator_admin->register();
		$members_admin = new Ontrack_Members_Admin();
		$members_admin->register();
	}

	/**
	 * Handle JWT secret regeneration form submission.
	 */
	public function handle_regenerate_jwt_secret() {
		if ( ! current_user_can( KCFA_CAP_MANAGE_SETTINGS ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'ontrack' ) );
		}
		check_admin_referer( 'ontrack_regenerate_jwt_secret' );

		Ontrack_JWT::regenerate_secret();

		wp_safe_redirect( add_query_arg(
			array(
				'page'    => 'ontrack',
				'message' => 'jwt_regenerated',
			),
			admin_url( 'options-general.php' )
		) );
		exit;
	}

	/**
	 * Register REST API routes.
	 */
	public function register_rest_routes() {
		$rest_auth = new Ontrack_REST_Auth();
		$rest_auth->register_routes();

		$rest_mobile = new Ontrack_REST_Mobile();
		$rest_mobile->register_routes();
	}

	/**
	 * Validate a Bearer JWT and set the current user.
	 * Stores errors so rest_authentication_errors can return clean 401s.
	 *
	 * @param int|false $user_id User ID from a prior filter, or false.
	 * @return int|false
	 */
	public function filter_determine_current_user( $user_id ) {
		$auth_header = '';
		if ( ! empty( $_SERVER['HTTP_AUTHORIZATION'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized below via substr check.
			$auth_header = wp_unslash( $_SERVER['HTTP_AUTHORIZATION'] );
		} elseif ( ! empty( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$auth_header = wp_unslash( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] );
		}

		if ( ! $auth_header || 0 !== strpos( $auth_header, 'Bearer ' ) ) {
			return $user_id; // No Bearer token — leave other auth mechanisms alone.
		}

		$token   = substr( $auth_header, 7 );
		$payload = Ontrack_JWT::decode( $token );

		if ( is_wp_error( $payload ) ) {
			self::$jwt_auth_error = $payload;
			return 0;
		}

		$sub = isset( $payload['sub'] ) ? (int) $payload['sub'] : 0;
		if ( $sub <= 0 || ! get_userdata( $sub ) ) {
			self::$jwt_auth_error = new WP_Error(
				'jwt_invalid',
				__( 'User not found.', 'ontrack' ),
				array( 'status' => 401 )
			);
			return 0;
		}

		return $sub;
	}

	/**
	 * Surface any stored JWT error as a REST authentication error.
	 *
	 * @param WP_Error|null|true $result Existing auth result.
	 * @return WP_Error|null|true
	 */
	public function filter_rest_authentication_errors( $result ) {
		if ( null !== $result ) {
			return $result; // Another filter already handled auth.
		}
		return self::$jwt_auth_error; // null if no error; WP_Error triggers 401.
	}

	/**
	 * Delete expired refresh token meta for all users (runs daily via WP-Cron).
	 */
	public function cleanup_expired_refresh_tokens() {
		$query = new WP_User_Query( array(
			'fields'     => 'ID',
			'number'     => -1,
			'meta_query' => array(
				array(
					'key'     => Ontrack_JWT::META_REFRESH_TOKEN_EXPIRES,
					'value'   => time(),
					'compare' => '<',
					'type'    => 'NUMERIC',
				),
			),
		) );
		foreach ( (array) $query->get_results() as $uid ) {
			Ontrack_JWT::revoke_refresh_token( (int) $uid );
		}
	}

	/**
	 * Load plugin text domain.
	 */
	public function load_textdomain() {
		load_plugin_textdomain(
			'ontrack',
			false,
			dirname( plugin_basename( ONTRACK_FILE ) ) . '/languages'
		);
	}
}
