<?php
/**
 * Ontrack integration settings (Box, Bunny.net, Vimeo).
 *
 * Registers options and renders the Settings page under Ontrack.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ONTRACK_SETTINGS_GROUP', 'ontrack_integrations' );
define( 'ONTRACK_SETTINGS_PAGE', 'ontrack-settings' );

/**
 * Register integration settings and sections.
 */
function ontrack_register_settings() {
	$option_name = 'ontrack_integrations';
	$option_group = ONTRACK_SETTINGS_GROUP;

	register_setting(
		$option_group,
		$option_name,
		array(
			'type'              => 'array',
			'sanitize_callback' => 'ontrack_sanitize_integrations',
		)
	);

	// Box.com (audio).
	add_settings_section(
		'ontrack_settings_box',
		__( 'Box.com (Audio)', 'ontrack' ),
		'ontrack_section_box',
		ONTRACK_SETTINGS_PAGE,
		array( 'option_name' => $option_name )
	);

	add_settings_field(
		'box_client_id',
		__( 'Client ID', 'ontrack' ),
		'ontrack_field_text',
		ONTRACK_SETTINGS_PAGE,
		'ontrack_settings_box',
		array(
			'option_name' => $option_name,
			'key'         => 'box_client_id',
			'type'        => 'text',
			'description' => __( 'Box app Client ID.', 'ontrack' ),
		)
	);

	add_settings_field(
		'box_client_secret',
		__( 'Client Secret', 'ontrack' ),
		'ontrack_field_text',
		ONTRACK_SETTINGS_PAGE,
		'ontrack_settings_box',
		array(
			'option_name' => $option_name,
			'key'         => 'box_client_secret',
			'type'        => 'password',
			'description' => __( 'Box app Client Secret.', 'ontrack' ),
		)
	);

	add_settings_field(
		'box_enterprise_id',
		__( 'Enterprise ID', 'ontrack' ),
		'ontrack_field_text',
		ONTRACK_SETTINGS_PAGE,
		'ontrack_settings_box',
		array(
			'option_name' => $option_name,
			'key'         => 'box_enterprise_id',
			'type'        => 'text',
			'description' => __( 'Your Box Enterprise ID. Found in Box Admin Console → Account &amp; Billing.', 'ontrack' ),
		)
	);

	add_settings_field(
		'box_jwt_kid',
		__( 'JWT Key ID', 'ontrack' ),
		'ontrack_field_text',
		ONTRACK_SETTINGS_PAGE,
		'ontrack_settings_box',
		array(
			'option_name' => $option_name,
			'key'         => 'box_jwt_kid',
			'type'        => 'text',
			'description' => __( 'The key ID (kid) from your Box app\'s public key list.', 'ontrack' ),
		)
	);

	add_settings_field(
		'box_jwt_passphrase',
		__( 'JWT Passphrase', 'ontrack' ),
		'ontrack_field_text',
		ONTRACK_SETTINGS_PAGE,
		'ontrack_settings_box',
		array(
			'option_name' => $option_name,
			'key'         => 'box_jwt_passphrase',
			'type'        => 'password',
			'description' => __( 'Passphrase used to encrypt the private key.', 'ontrack' ),
		)
	);

	add_settings_field(
		'box_jwt_private_key',
		__( 'JWT Private Key', 'ontrack' ),
		'ontrack_field_textarea',
		ONTRACK_SETTINGS_PAGE,
		'ontrack_settings_box',
		array(
			'option_name' => $option_name,
			'key'         => 'box_jwt_private_key',
			'description' => __( 'Paste the full PEM private key, including the -----BEGIN/END----- lines.', 'ontrack' ),
		)
	);

	add_settings_field(
		'box_test_connection',
		__( 'Test connection', 'ontrack' ),
		'ontrack_field_box_test',
		ONTRACK_SETTINGS_PAGE,
		'ontrack_settings_box'
	);

	// Bunny.net (video).
	add_settings_section(
		'ontrack_settings_bunny',
		__( 'Bunny.net (Video)', 'ontrack' ),
		'ontrack_section_bunny',
		ONTRACK_SETTINGS_PAGE,
		array( 'option_name' => $option_name )
	);

	add_settings_field(
		'bunny_api_key',
		__( 'API Key', 'ontrack' ),
		'ontrack_field_text',
		ONTRACK_SETTINGS_PAGE,
		'ontrack_settings_bunny',
		array(
			'option_name' => $option_name,
			'key'         => 'bunny_api_key',
			'type'        => 'password',
			'description' => __( 'Bunny.net Stream or API key.', 'ontrack' ),
		)
	);

	add_settings_field(
		'bunny_library_id',
		__( 'Stream Library ID', 'ontrack' ),
		'ontrack_field_text',
		ONTRACK_SETTINGS_PAGE,
		'ontrack_settings_bunny',
		array(
			'option_name' => $option_name,
			'key'         => 'bunny_library_id',
			'type'        => 'text',
			'description' => __( 'Video Library ID (optional default).', 'ontrack' ),
		)
	);

	add_settings_field(
		'bunny_cdn_hostname',
		__( 'CDN Pull Zone Hostname', 'ontrack' ),
		'ontrack_field_text',
		ONTRACK_SETTINGS_PAGE,
		'ontrack_settings_bunny',
		array(
			'option_name' => $option_name,
			'key'         => 'bunny_cdn_hostname',
			'type'        => 'text',
			'description' => __( 'Pull zone hostname for thumbnails — e.g. vz-abc123.b-cdn.net (no https://).', 'ontrack' ),
		)
	);

	add_settings_field(
		'bunny_test_connection',
		__( 'Test connection', 'ontrack' ),
		'ontrack_field_bunny_test',
		ONTRACK_SETTINGS_PAGE,
		'ontrack_settings_bunny'
	);

	// Vimeo (video).
	add_settings_section(
		'ontrack_settings_vimeo',
		__( 'Vimeo (Video)', 'ontrack' ),
		'ontrack_section_vimeo',
		ONTRACK_SETTINGS_PAGE,
		array( 'option_name' => $option_name )
	);

	add_settings_field(
		'vimeo_access_token',
		__( 'Access Token', 'ontrack' ),
		'ontrack_field_text',
		ONTRACK_SETTINGS_PAGE,
		'ontrack_settings_vimeo',
		array(
			'option_name' => $option_name,
			'key'         => 'vimeo_access_token',
			'type'        => 'password',
			'description' => __( 'Vimeo API access token.', 'ontrack' ),
		)
	);
}
add_action( 'admin_init', 'ontrack_register_settings' );

/**
 * Sanitize integrations option array.
 *
 * @param array $input Raw POSTed values.
 * @return array Sanitized values.
 */
function ontrack_sanitize_integrations( $input ) {
	if ( ! is_array( $input ) ) {
		return array();
	}
	$out = array();
	$text_keys = array(
		'box_client_id',
		'box_client_secret',
		'box_enterprise_id',
		'box_jwt_kid',
		'box_jwt_passphrase',
		'bunny_api_key',
		'bunny_library_id',
		'bunny_cdn_hostname',
		'vimeo_access_token',
	);
	foreach ( $text_keys as $key ) {
		if ( isset( $input[ $key ] ) && is_string( $input[ $key ] ) ) {
			$out[ $key ] = sanitize_text_field( $input[ $key ] );
		}
	}
	// Private key is multiline — preserve newlines, strip tags only.
	if ( isset( $input['box_jwt_private_key'] ) && is_string( $input['box_jwt_private_key'] ) ) {
		$out['box_jwt_private_key'] = sanitize_textarea_field( $input['box_jwt_private_key'] );
	}
	return $out;
}

/**
 * Section description for Box.com.
 */
function ontrack_section_box() {
	echo '<p>' . esc_html__( 'Configure Box.com for audio folder integration. Access tokens are generated automatically via JWT and cached for 55 minutes.', 'ontrack' ) . '</p>';
}

/**
 * Section description for Bunny.net.
 */
function ontrack_section_bunny() {
	echo '<p>' . esc_html__( 'Configure Bunny.net Stream for video collections.', 'ontrack' ) . '</p>';
}

/**
 * Section description for Vimeo.
 */
function ontrack_section_vimeo() {
	echo '<p>' . esc_html__( 'Configure Vimeo for video collections.', 'ontrack' ) . '</p>';
}

/**
 * Render a text/password field for integration settings.
 *
 * @param array $args Keys: option_name, key, type, description.
 */
function ontrack_field_text( $args ) {
	$option_name = $args['option_name'];
	$key         = $args['key'];
	$type        = isset( $args['type'] ) ? $args['type'] : 'text';
	$description = isset( $args['description'] ) ? $args['description'] : '';
	$opts        = get_option( $option_name, array() );
	$value       = isset( $opts[ $key ] ) ? $opts[ $key ] : '';
	$name        = $option_name . '[' . esc_attr( $key ) . ']';
	$id          = 'ontrack_setting_' . str_replace( array( '[', ']' ), array( '_', '' ), $key );
	?>
	<input type="<?php echo esc_attr( $type ); ?>"
		id="<?php echo esc_attr( $id ); ?>"
		name="<?php echo esc_attr( $name ); ?>"
		value="<?php echo esc_attr( $value ); ?>"
		class="regular-text"
		autocomplete="off" />
	<?php if ( $description ) : ?>
		<p class="description"><?php echo esc_html( $description ); ?></p>
	<?php endif;
}

/**
 * Render a textarea field for integration settings (used for multiline values like PEM keys).
 *
 * @param array $args Keys: option_name, key, description.
 */
function ontrack_field_textarea( $args ) {
	$option_name = $args['option_name'];
	$key         = $args['key'];
	$description = isset( $args['description'] ) ? $args['description'] : '';
	$opts        = get_option( $option_name, array() );
	$value       = isset( $opts[ $key ] ) ? $opts[ $key ] : '';
	$name        = $option_name . '[' . esc_attr( $key ) . ']';
	$id          = 'ontrack_setting_' . $key;
	?>
	<textarea
		id="<?php echo esc_attr( $id ); ?>"
		name="<?php echo esc_attr( $name ); ?>"
		rows="8"
		class="large-text code"
		autocomplete="off"
		spellcheck="false"><?php echo esc_textarea( $value ); ?></textarea>
	<?php if ( $description ) : ?>
		<p class="description"><?php echo esc_html( $description ); ?></p>
	<?php endif;
}

/**
 * Render the Box test connection button and result area.
 */
function ontrack_field_box_test() {
	?>
	<button type="button" id="ontrack-test-box-btn" class="button"
		data-nonce="<?php echo esc_attr( wp_create_nonce( 'ontrack_test_box_connection' ) ); ?>">
		<?php esc_html_e( 'Test connection', 'ontrack' ); ?>
	</button>
	<span id="ontrack-test-box-result" style="margin-left:10px; font-style:italic"></span>
	<p class="description"><?php esc_html_e( 'Saves are not required first — this tests the values currently saved in the database. Save your changes before testing if you have updated any fields.', 'ontrack' ); ?></p>
	<?php
}

/**
 * Render the Bunny.net test connection button and result area.
 */
function ontrack_field_bunny_test() {
	?>
	<button type="button" id="ontrack-test-bunny-btn" class="button"
		data-nonce="<?php echo esc_attr( wp_create_nonce( 'ontrack_test_bunny_connection' ) ); ?>">
		<?php esc_html_e( 'Test connection', 'ontrack' ); ?>
	</button>
	<span id="ontrack-test-bunny-result" style="margin-left:10px; font-style:italic"></span>
	<p class="description"><?php esc_html_e( 'Tests the saved API key and Library ID against the Bunny Stream API. Save your changes before testing if you have updated any fields.', 'ontrack' ); ?></p>
	<?php
}

/**
 * AJAX: test the Bunny.net connection using the saved credentials.
 *
 * Calls GET /library/{id} to confirm the API key and library ID are valid.
 */
function ontrack_ajax_test_bunny_connection() {
	check_ajax_referer( 'ontrack_test_bunny_connection', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Unauthorized.', 'ontrack' ) );
	}

	$opts       = get_option( 'ontrack_integrations', array() );
	$api_key    = isset( $opts['bunny_api_key'] )    ? trim( $opts['bunny_api_key'] )    : '';
	$library_id = isset( $opts['bunny_library_id'] ) ? absint( $opts['bunny_library_id'] ) : 0;

	if ( ! $api_key ) {
		wp_send_json_error( __( 'API key is not set.', 'ontrack' ) );
	}
	if ( ! $library_id ) {
		wp_send_json_error( __( 'Stream Library ID is not set.', 'ontrack' ) );
	}

	$response = wp_remote_get(
		'https://video.bunnycdn.com/library/' . $library_id,
		array(
			'headers' => array(
				'AccessKey' => $api_key,
				'Accept'    => 'application/json',
			),
			'timeout' => 10,
		)
	);

	$code = wp_remote_retrieve_response_code( $response );
	$body = json_decode( wp_remote_retrieve_body( $response ), true );

	if ( $code !== 200 ) {
		$detail = isset( $body['Message'] ) ? $body['Message'] : wp_remote_retrieve_body( $response );
		wp_send_json_error(
			sprintf( __( 'API call failed (%d): %s', 'ontrack' ), $code, $detail )
		);
	}

	$name = isset( $body['Name'] ) ? $body['Name'] : __( 'Library', 'ontrack' );
	wp_send_json_success(
		sprintf( __( 'Connected. Library: %s', 'ontrack' ), $name )
	);
}
add_action( 'wp_ajax_ontrack_test_bunny_connection', 'ontrack_ajax_test_bunny_connection' );

/**
 * AJAX: test the Box connection using the saved credentials.
 *
 * Forces a fresh token exchange (ignores cached transient) then calls
 * GET /2.0/users/me to confirm the token is accepted by Box.
 */
function ontrack_ajax_test_box_connection() {
	check_ajax_referer( 'ontrack_test_box_connection', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Unauthorized.', 'ontrack' ) );
	}

	// Force a fresh exchange so we're validating the saved credentials, not a stale cache.
	delete_transient( 'ontrack_box_access_token' );

	$token = ontrack_box_get_access_token();
	if ( is_wp_error( $token ) ) {
		wp_send_json_error( $token->get_error_message() );
	}

	// Verify the token is accepted by Box with a lightweight call.
	$response = wp_remote_get(
		'https://api.box.com/2.0/users/me',
		array(
			'headers' => array( 'Authorization' => 'Bearer ' . $token ),
			'timeout' => 10,
		)
	);

	$code = wp_remote_retrieve_response_code( $response );
	$body = json_decode( wp_remote_retrieve_body( $response ), true );

	if ( $code !== 200 ) {
		$detail = isset( $body['message'] ) ? $body['message'] : wp_remote_retrieve_body( $response );
		wp_send_json_error(
			sprintf( __( 'Token generated but API call failed (%d): %s', 'ontrack' ), $code, $detail )
		);
	}

	$name = isset( $body['name'] ) ? $body['name'] : __( 'Service Account', 'ontrack' );
	wp_send_json_success(
		sprintf( __( 'Connected. Authenticated as: %s', 'ontrack' ), $name )
	);
}
add_action( 'wp_ajax_ontrack_test_box_connection', 'ontrack_ajax_test_box_connection' );

/**
 * Render the Ontrack Settings page (form).
 */
function ontrack_settings_page_render() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$option_group = ONTRACK_SETTINGS_GROUP;
	$page        = ONTRACK_SETTINGS_PAGE;
	?>
	<div class="wrap">
		<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
		<form action="options.php" method="post">
			<?php
			settings_fields( $option_group );
			do_settings_sections( $page );
			submit_button( __( 'Save Settings', 'ontrack' ) );
			?>
		</form>
	</div>
	<script>
	(function () {
		var testingLabel = <?php echo wp_json_encode( __( 'Testing…', 'ontrack' ) ); ?>;
		var errorLabel   = <?php echo wp_json_encode( __( 'Request failed. Check browser console.', 'ontrack' ) ); ?>;

		function wireTestButton( btnId, resultId, action ) {
			var btn    = document.getElementById( btnId );
			var result = document.getElementById( resultId );
			if ( ! btn || ! result ) return;

			btn.addEventListener( 'click', function () {
				btn.disabled       = true;
				result.style.color = '#646970';
				result.textContent = testingLabel;

				fetch( ajaxurl, {
					method:  'POST',
					headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
					body:    new URLSearchParams( { action: action, nonce: btn.dataset.nonce } ),
				} )
				.then( function ( r ) { return r.json(); } )
				.then( function ( res ) {
					btn.disabled       = false;
					result.style.color = res.success ? '#2e7d32' : '#c62828';
					result.textContent = res.data;
				} )
				.catch( function () {
					btn.disabled       = false;
					result.style.color = '#c62828';
					result.textContent = errorLabel;
				} );
			} );
		}

		wireTestButton( 'ontrack-test-box-btn',   'ontrack-test-box-result',   'ontrack_test_box_connection' );
		wireTestButton( 'ontrack-test-bunny-btn', 'ontrack-test-bunny-result', 'ontrack_test_bunny_connection' );
	} )();
	</script>
	<?php
}
