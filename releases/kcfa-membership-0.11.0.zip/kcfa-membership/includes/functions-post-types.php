<?php
/**
 * Ontrack custom post types: Audio Collections and Video Collections.
 *
 * Both are shown under the Ontrack admin menu (registered by the klac theme).
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register Ontrack custom post types.
 */
function ontrack_register_post_types() {
	$ontrack_menu_slug = 'ontrack';

	// Audio Collections (e.g. Box.com folders).
	register_post_type(
		'audio_collection',
		array(
			'labels'             => array(
				'name'               => _x( 'Audio Collections', 'post type general name', 'ontrack' ),
				'singular_name'      => _x( 'Audio Collection', 'post type singular name', 'ontrack' ),
				'menu_name'          => __( 'Audio Collections', 'ontrack' ),
				'add_new'            => __( 'Add New', 'ontrack' ),
				'add_new_item'       => __( 'Add New Audio Collection', 'ontrack' ),
				'edit_item'          => __( 'Edit Audio Collection', 'ontrack' ),
				'new_item'           => __( 'New Audio Collection', 'ontrack' ),
				'view_item'          => __( 'View Audio Collection', 'ontrack' ),
				'search_items'       => __( 'Search Audio Collections', 'ontrack' ),
				'not_found'          => __( 'No audio collections found.', 'ontrack' ),
				'not_found_in_trash' => __( 'No audio collections found in Trash.', 'ontrack' ),
			),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => $ontrack_menu_slug,
			'menu_position'      => 10,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'audio-collections' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'supports'           => array( 'title', 'editor', 'thumbnail' ),
		)
	);

	// Video Collections (e.g. Bunny.net, Vimeo).
	register_post_type(
		'video_collection',
		array(
			'labels'             => array(
				'name'               => _x( 'Video Collections', 'post type general name', 'ontrack' ),
				'singular_name'      => _x( 'Video Collection', 'post type singular name', 'ontrack' ),
				'menu_name'          => __( 'Video Collections', 'ontrack' ),
				'add_new'            => __( 'Add New', 'ontrack' ),
				'add_new_item'       => __( 'Add New Video Collection', 'ontrack' ),
				'edit_item'          => __( 'Edit Video Collection', 'ontrack' ),
				'new_item'           => __( 'New Video Collection', 'ontrack' ),
				'view_item'          => __( 'View Video Collection', 'ontrack' ),
				'search_items'       => __( 'Search Video Collections', 'ontrack' ),
				'not_found'          => __( 'No video collections found.', 'ontrack' ),
				'not_found_in_trash' => __( 'No video collections found in Trash.', 'ontrack' ),
			),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => $ontrack_menu_slug,
			'menu_position'      => 11,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'video-collections' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'supports'           => array( 'title', 'editor', 'thumbnail' ),
		)
	);

	// Events.
	register_post_type(
		'ontrack_event',
		array(
			'labels'             => array(
				'name'               => _x( 'Events', 'post type general name', 'ontrack' ),
				'singular_name'      => _x( 'Event', 'post type singular name', 'ontrack' ),
				'menu_name'          => __( 'Events', 'ontrack' ),
				'add_new'            => __( 'Add New', 'ontrack' ),
				'add_new_item'       => __( 'Add New Event', 'ontrack' ),
				'edit_item'          => __( 'Edit Event', 'ontrack' ),
				'new_item'           => __( 'New Event', 'ontrack' ),
				'view_item'          => __( 'View Event', 'ontrack' ),
				'search_items'       => __( 'Search Events', 'ontrack' ),
				'not_found'          => __( 'No events found.', 'ontrack' ),
				'not_found_in_trash' => __( 'No events found in Trash.', 'ontrack' ),
			),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => $ontrack_menu_slug,
			'menu_position'      => 12,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'events' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'supports'           => array( 'title', 'editor', 'thumbnail' ),
			'show_in_rest'       => false,
		)
	);
}
add_action( 'init', 'ontrack_register_post_types' );

/**
 * Sort the ontrack_event archive by event date ascending; only show upcoming events.
 *
 * @param WP_Query $query The query object.
 */
function ontrack_event_archive_query( WP_Query $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}
	if ( ! $query->is_post_type_archive( 'ontrack_event' ) ) {
		return;
	}
	$query->set( 'meta_key', '_event_datetime' );
	$query->set( 'orderby', 'meta_value' );
	$query->set( 'order', 'ASC' );
	$query->set(
		'meta_query',
		array(
			array(
				'key'     => '_event_datetime',
				'value'   => current_time( 'Y-m-d H:i:s' ),
				'compare' => '>=',
				'type'    => 'DATETIME',
			),
		)
	);
}
add_action( 'pre_get_posts', 'ontrack_event_archive_query' );
