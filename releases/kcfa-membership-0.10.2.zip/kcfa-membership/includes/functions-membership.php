<?php
/**
 * Public helpers and membership meta helpers.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option name for plugin settings (array).
 *
 * @return string
 */
function ontrack_options_key() {
	return 'ontrack_options';
}

/**
 * Default plugin options.
 *
 * @return array<string, mixed>
 */
function ontrack_default_options() {
	return array(
		'min_role_manage'                => 'administrator',
		'catalogue_enforcement_enabled'  => false,
		'rest_enforcement_enabled'       => false,
		'sunday_event_time'              => '10:30',
		'mobile_animation_attachment_id' => 0,
		'community_links'                => array(
			array( 'label' => 'Canopy Radio',         'url' => 'https://canopylive.com/' ),
			array( 'label' => 'Congress MusicFactory', 'url' => 'https://new.congressmusicfactory.com/' ),
			array( 'label' => 'KLAC Live Stream',     'url' => 'https://www.klackc.org/live' ),
		),
	);
}

/**
 * Whether REST API endpoint access enforcement is enabled.
 *
 * @return bool
 */
function ontrack_is_rest_enforcement_enabled() {
	$opts = ontrack_get_options();
	return ! empty( $opts['rest_enforcement_enabled'] );
}

/**
 * Get plugin options merged with defaults.
 *
 * @return array<string, mixed>
 */
function ontrack_get_options() {
	$stored = get_option( ontrack_options_key(), array() );
	if ( ! is_array( $stored ) ) {
		$stored = array();
	}
	return array_merge( ontrack_default_options(), $stored );
}

/**
 * Ordered default roles from most to least privileged (WordPress defaults).
 * Custom roles are appended after this list by ontrack_get_ordered_role_slugs().
 *
 * @return string[]
 */
function ontrack_get_role_hierarchy() {
	$default = array( 'administrator', 'editor', 'author', 'contributor', 'subscriber' );
	return apply_filters( 'ontrack_role_hierarchy', $default );
}

/**
 * All role slugs in privilege order (known hierarchy first, then remaining roles).
 *
 * @return string[]
 */
function ontrack_get_ordered_role_slugs() {
	$known  = ontrack_get_role_hierarchy();
	$wp     = wp_roles();
	$all    = array_keys( $wp->roles );
	$tail   = array_diff( $all, $known );
	$merged = array_merge( $known, $tail );
	return apply_filters( 'ontrack_ordered_role_slugs', $merged );
}

/**
 * Privilege rank for a role (lower = more privileged).
 *
 * @param string $role_slug Role slug.
 * @return int
 */
function ontrack_role_rank( $role_slug ) {
	$role_slug = (string) $role_slug;
	$order     = ontrack_get_ordered_role_slugs();
	$index     = array_search( $role_slug, $order, true );
	if ( false === $index ) {
		return count( $order );
	}
	return (int) $index;
}

/**
 * Configured minimum role required to change the full-member flag (that role and more privileged roles).
 *
 * @return string Role slug.
 */
function ontrack_get_min_role_manage() {
	$opts = ontrack_get_options();
	$role = isset( $opts['min_role_manage'] ) ? sanitize_key( $opts['min_role_manage'] ) : 'administrator';
	if ( ! get_role( $role ) ) {
		return 'administrator';
	}
	return $role;
}

/**
 * Best (most privileged) rank among the user's roles.
 *
 * @param int $user_id User ID.
 * @return int|null Null if user invalid.
 */
function ontrack_user_best_role_rank( $user_id ) {
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return null;
	}
	$user = get_userdata( $user_id );
	if ( ! $user || empty( $user->roles ) ) {
		return null;
	}
	$best = null;
	foreach ( (array) $user->roles as $slug ) {
		$r = ontrack_role_rank( $slug );
		if ( null === $best || $r < $best ) {
			$best = $r;
		}
	}
	return $best;
}

/**
 * Whether the user's role privilege is at least the configured minimum (can manage member flag UI).
 *
 * @param int $user_id User ID.
 * @return bool
 */
function ontrack_user_meets_min_role_to_manage_member_flag( $user_id ) {
	_deprecated_function( __FUNCTION__, '0.7.0', 'ontrack_actor_can_edit_user()' );
	$min_slug = ontrack_get_min_role_manage();
	$min_rank = ontrack_role_rank( $min_slug );
	$best     = ontrack_user_best_role_rank( $user_id );
	if ( null === $best ) {
		return false;
	}
	return $best <= $min_rank;
}

/**
 * Whether the actor may change the full-member flag for the target profile (self or others).
 * Requires minimum configured role and `edit_user` on the target.
 *
 * @param int $target_user_id Profile user ID.
 * @return bool
 */
function ontrack_current_user_can_manage_member_flag_for_user( $target_user_id ) {
	$target_user_id = (int) $target_user_id;
	$current_id     = get_current_user_id();
	if ( $target_user_id <= 0 || $current_id <= 0 ) {
		return false;
	}
	if ( ! ontrack_user_meets_min_role_to_manage_member_flag( $current_id ) ) {
		return false;
	}
	if ( ! current_user_can( 'edit_user', $target_user_id ) ) {
		return false;
	}
	return true;
}

/**
 * Legacy helper: whether the current user can manage membership flags (any user they can edit_user).
 *
 * @param int $target_user_id User ID whose profile is being edited.
 * @return bool
 */
function ontrack_current_user_can_manage_membership( $target_user_id = 0 ) {
	if ( $target_user_id > 0 ) {
		return ontrack_current_user_can_manage_member_flag_for_user( (int) $target_user_id );
	}
	return ontrack_user_meets_min_role_to_manage_member_flag( get_current_user_id() );
}

/**
 * User meta key for full-member flag (boolean semantics).
 *
 * @return string
 */
function ontrack_meta_key_is_member() {
	return 'ontrack_is_member';
}

/**
 * Whether the current request is from a guest (not logged in).
 *
 * @return bool
 */
function ontrack_is_guest() {
	return ! is_user_logged_in();
}

/**
 * Normalize stored meta to a strict boolean (missing/empty/false → false).
 *
 * @param mixed $raw Raw meta value from get_user_meta.
 * @return bool
 */
function ontrack_normalize_is_member_meta( $raw ) {
	if ( '' === $raw || false === $raw || null === $raw ) {
		return false;
	}
	if ( true === $raw || 1 === $raw || '1' === $raw ) {
		return true;
	}
	if ( false === $raw || 0 === $raw || '0' === $raw ) {
		return false;
	}
	if ( is_string( $raw ) ) {
		$lower = strtolower( trim( $raw ) );
		if ( in_array( $lower, array( 'yes', 'true', 'on' ), true ) ) {
			return true;
		}
	}
	return (bool) $raw;
}

/**
 * Whether the user is a full member (`kcfa_is_member` true).
 *
 * @param int|null $user_id User ID, or null for current user.
 * @return bool
 */
function ontrack_user_is_full_member( $user_id = null ) {
	if ( null === $user_id ) {
		$user_id = get_current_user_id();
	}
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return false;
	}
	$raw = get_user_meta( $user_id, ontrack_meta_key_is_member(), true );
	return ontrack_normalize_is_member_meta( $raw );
}

/**
 * Whether the user is logged in and not a full member (visitor baseline).
 *
 * @param int|null $user_id User ID, or null for current user.
 * @return bool
 */
function ontrack_user_is_logged_in_visitor( $user_id = null ) {
	if ( null === $user_id ) {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		$user_id = get_current_user_id();
	} else {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 ) {
			return false;
		}
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return false;
		}
	}
	return ! ontrack_user_is_full_member( $user_id );
}
