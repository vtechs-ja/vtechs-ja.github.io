<?php
/**
 * Settings screen under Settings.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the plugin options page.
 */
class Ontrack_Settings_Admin {

	/**
	 * Settings group slug.
	 *
	 * @var string
	 */
	const SETTINGS_GROUP = 'ontrack_settings';

	/**
	 * Bootstrap hooks.
	 */
	public function register() {
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_menu', array( $this, 'add_options_page' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_settings_assets' ) );
	}

	/**
	 * Enqueue wp.media on the plugin settings page (needed for animation picker).
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_settings_assets( $hook ) {
		if ( 'settings_page_kcfa-membership' !== $hook ) {
			return;
		}
		wp_enqueue_media();
		wp_add_inline_script(
			'media-editor',
			"(function(){
				var btn    = document.getElementById('ontrack-mobile-animation-pick');
				var rmBtn  = document.getElementById('ontrack-mobile-animation-remove');
				var idInput= document.getElementById('ontrack_mobile_animation_id');
				var title  = document.getElementById('ontrack-mobile-animation-title');
				if(!btn) return;
				var frame;
				btn.addEventListener('click', function(){
					if(!frame){
						frame = wp.media({ title: '" . esc_js( __( 'Choose Animation Video', 'ontrack' ) ) . "', library:{ type:'video' }, multiple:false, button:{ text:'" . esc_js( __( 'Use this video', 'ontrack' ) ) . "' } });
						frame.on('select', function(){
							var a = frame.state().get('selection').first().toJSON();
							idInput.value = a.id;
							title.textContent = a.title || a.filename;
							rmBtn.style.display = '';
						});
					}
					frame.open();
				});
				if(rmBtn) rmBtn.addEventListener('click', function(){
					idInput.value = '';
					title.textContent = '';
					rmBtn.style.display = 'none';
				});
			})();"
		);
	}

	/**
	 * Output a success notice after JWT secret regeneration.
	 */
	private function maybe_render_jwt_regenerated_notice() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only display.
		if ( isset( $_GET['message'] ) && 'jwt_regenerated' === $_GET['message'] ) {
			echo '<div class="notice notice-success is-dismissible"><p>';
			esc_html_e( 'Mobile signing key regenerated. All existing mobile sessions have been invalidated.', 'ontrack' );
			echo '</p></div>';
		}
	}

	/**
	 * Register option and fields.
	 */
	public function register_settings() {
		register_setting(
			self::SETTINGS_GROUP,
			ontrack_options_key(),
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $this, 'sanitize_options' ),
				'default'           => ontrack_default_options(),
			)
		);

		add_settings_section(
			'ontrack_main',
			__( 'Membership management', 'ontrack' ),
			array( $this, 'render_section_main' ),
			self::SETTINGS_GROUP
		);

		add_settings_field(
			'min_role_manage',
			__( 'Minimum role for member flag and groups', 'ontrack' ),
			array( $this, 'render_field_min_role' ),
			self::SETTINGS_GROUP,
			'ontrack_main'
		);

		add_settings_section(
			'ontrack_app',
			__( 'Mobile app', 'ontrack' ),
			array( $this, 'render_section_app' ),
			self::SETTINGS_GROUP
		);

		add_settings_field(
			'sunday_event_time',
			__( 'Sunday event time', 'ontrack' ),
			array( $this, 'render_field_sunday_event_time' ),
			self::SETTINGS_GROUP,
			'ontrack_app'
		);

		add_settings_section(
			'ontrack_mobile_app',
			__( 'Mobile app', 'ontrack' ),
			array( $this, 'render_section_mobile_app' ),
			self::SETTINGS_GROUP
		);

		add_settings_field(
			'mobile_animation',
			__( 'Home screen animation', 'ontrack' ),
			array( $this, 'render_field_mobile_animation' ),
			self::SETTINGS_GROUP,
			'ontrack_mobile_app'
		);

		add_settings_field(
			'community_links',
			__( 'Community links', 'ontrack' ),
			array( $this, 'render_field_community_links' ),
			self::SETTINGS_GROUP,
			'ontrack_mobile_app'
		);

		add_settings_section(
			'ontrack_catalogue',
			__( 'Catalogue access', 'ontrack' ),
			array( $this, 'render_section_catalogue' ),
			self::SETTINGS_GROUP
		);

		add_settings_field(
			'catalogue_enforcement_enabled',
			__( 'Enforce collection access levels', 'ontrack' ),
			array( $this, 'render_field_catalogue_enforcement' ),
			self::SETTINGS_GROUP,
			'ontrack_catalogue'
		);

		add_settings_field(
			'rest_enforcement_enabled',
			__( 'Enforce access on REST API endpoints', 'ontrack' ),
			array( $this, 'render_field_rest_enforcement' ),
			self::SETTINGS_GROUP,
			'ontrack_catalogue'
		);
	}

	/**
	 * Sanitize options array.
	 *
	 * @param mixed $input Raw input.
	 * @return array<string, mixed>
	 */
	public function sanitize_options( $input ) {
		$existing = get_option( ontrack_options_key(), array() );
		if ( ! is_array( $existing ) ) {
			$existing = array();
		}
		$out = array_merge( ontrack_default_options(), $existing );

		if ( isset( $input['min_role_manage'] ) ) {
			$slug = sanitize_key( $input['min_role_manage'] );
			if ( $slug && get_role( $slug ) ) {
				$out['min_role_manage'] = $slug;
			}
		}

		if ( array_key_exists( 'catalogue_enforcement_enabled', $input ) ) {
			$out['catalogue_enforcement_enabled'] = ( '1' === (string) $input['catalogue_enforcement_enabled'] );
		}

		if ( array_key_exists( 'rest_enforcement_enabled', $input ) ) {
			$out['rest_enforcement_enabled'] = ( '1' === (string) $input['rest_enforcement_enabled'] );
		}

		if ( isset( $input['mobile_animation_attachment_id'] ) ) {
			$out['mobile_animation_attachment_id'] = absint( $input['mobile_animation_attachment_id'] );
		}

		if ( isset( $input['community_links_json'] ) && is_string( $input['community_links_json'] ) ) {
			$decoded = json_decode( stripslashes( $input['community_links_json'] ), true );
			if ( is_array( $decoded ) ) {
				$links = array();
				foreach ( $decoded as $item ) {
					if ( ! is_array( $item ) ) {
						continue;
					}
					$label = isset( $item['label'] ) ? sanitize_text_field( $item['label'] ) : '';
					$url   = isset( $item['url'] ) ? esc_url_raw( $item['url'] ) : '';
					if ( $label && $url ) {
						$links[] = array( 'label' => $label, 'url' => $url );
					}
				}
				$out['community_links'] = $links;
			}
		}

		if ( isset( $input['sunday_event_time'] ) ) {
			$time = sanitize_text_field( $input['sunday_event_time'] );
			// Accept HH:MM (24-hour) format only.
			if ( preg_match( '/^\d{1,2}:\d{2}$/', $time ) ) {
				$out['sunday_event_time'] = $time;
			}
		}

		return $out;
	}

	/**
	 * Mobile auth section: key status + regenerate button.
	 */
	public function render_section_mobile_auth() {
		$using_constant = Ontrack_JWT::using_constant();
		$fingerprint    = Ontrack_JWT::get_secret_fingerprint();

		echo '<p>';
		if ( $using_constant ) {
			echo '<span style="color:#2e7d32;">&#x2714; </span>';
			esc_html_e( 'Using the KCFA_JWT_SECRET constant defined in wp-config.php.', 'ontrack' );
			echo ' ';
			esc_html_e( 'The constant overrides the auto-generated key. Regeneration is disabled while the constant is in use.', 'ontrack' );
		} else {
			echo '<span style="color:#2e7d32;">&#x2714; </span>';
			printf(
				/* translators: %s: 8-character key fingerprint */
				esc_html__( 'Using auto-generated signing key (fingerprint: %s).', 'ontrack' ),
				'<code>' . esc_html( $fingerprint ) . '</code>'
			);
		}
		echo '</p>';

		if ( ! $using_constant ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			echo '<input type="hidden" name="action" value="ontrack_regenerate_jwt_secret" />';
			wp_nonce_field( 'ontrack_regenerate_jwt_secret' );
			echo '<p class="description">';
			esc_html_e( 'Regenerating the key immediately invalidates all active mobile sessions. Users will need to log in again.', 'ontrack' );
			echo '</p>';
			submit_button( __( 'Regenerate signing key', 'ontrack' ), 'secondary', 'ontrack_do_regenerate', false );
			echo '</form>';
		}

		echo '<p class="description">';
		echo wp_kses_post( __( 'To use a custom secret instead of the auto-generated one, add <code>define( \'KCFA_JWT_SECRET\', \'your-long-random-string\' );</code> to wp-config.php.', 'ontrack' ) );
		echo '</p>';
	}

	/**
	 * Section blurb.
	 */
	public function render_section_main() {
		echo '<p>';
		esc_html_e( 'Only users with the selected role or a more privileged role may change the “full member” flag on profiles (including their own), create or edit KCFA groups, and assign users to groups. Less privileged users never see those controls, even on their own profile.', 'ontrack' );
		echo '</p>';
	}

	/**
	 * App settings section blurb.
	 */
	public function render_section_app() {
		echo '<p>';
		esc_html_e( 'Settings consumed by the mobile app via the REST API.', 'ontrack' );
		echo '</p>';
	}

	/**
	 * Time input: Sunday event start time for mobile countdown widget.
	 */
	public function render_field_sunday_event_time() {
		$opts  = ontrack_get_options();
		$value = isset( $opts['sunday_event_time'] ) ? $opts['sunday_event_time'] : '10:30';
		$name  = ontrack_options_key() . '[sunday_event_time]';
		printf(
			'<input type="time" name="%1$s" id="ontrack_sunday_event_time" value="%2$s" />',
			esc_attr( $name ),
			esc_attr( $value )
		);
		echo '<p class="description">';
		esc_html_e( '24-hour time (HH:MM). The mobile app uses this for the Sunday countdown widget.', 'ontrack' );
		echo '</p>';
	}

	/**
	 * Catalogue section blurb.
	 */
	public function render_section_catalogue() {
		echo '<p>';
		esc_html_e( 'When enforcement is on, the theme hides Audio and Video collections that the viewer is not allowed to see (per-collection setting). The klac theme includes hooks that call the membership plugin.', 'ontrack' );
		echo '</p>';
	}

	/**
	 * Checkbox: enforce catalogue access on the front end.
	 */
	public function render_field_catalogue_enforcement() {
		$opts    = ontrack_get_options();
		$enabled = ! empty( $opts['catalogue_enforcement_enabled'] );
		$name    = ontrack_options_key() . '[catalogue_enforcement_enabled]';
		printf(
			'<input type="hidden" name="%1$s" value="0" />',
			esc_attr( $name )
		);
		printf(
			'<label><input type="checkbox" name="%1$s" id="ontrack_catalogue_enforcement_enabled" value="1" %2$s /> %3$s</label>',
			esc_attr( $name ),
			checked( $enabled, true, false ),
			esc_html__( 'Restrict Audio Collection and Video Collection URLs by access level', 'ontrack' )
		);
		echo '<p class="description">';
		esc_html_e( 'When unchecked, all published collections remain visible to everyone (default until you are ready). Collections without a saved access level are treated as full-member-only once enforcement is on.', 'ontrack' );
		echo '</p>';
	}

	/**
	 * Checkbox: enforce catalogue access on the REST API.
	 */
	public function render_field_rest_enforcement() {
		$opts    = ontrack_get_options();
		$enabled = ! empty( $opts['rest_enforcement_enabled'] );
		$name    = ontrack_options_key() . '[rest_enforcement_enabled]';
		printf(
			'<input type="hidden" name="%1$s" value="0" />',
			esc_attr( $name )
		);
		printf(
			'<label><input type="checkbox" name="%1$s" id="ontrack_rest_enforcement_enabled" value="1" %2$s /> %3$s</label>',
			esc_attr( $name ),
			checked( $enabled, true, false ),
			esc_html__( 'Gate playlist and stream REST endpoints by access level', 'ontrack' )
		);
		echo '<p class="description">';
		esc_html_e( 'When checked, the mobile app must send a valid JWT to reach full-member collections, and receives 401/403 otherwise. Enable only after the mobile app supports the new auth flow. The /stream endpoint is always rate-limited regardless of this setting.', 'ontrack' );
		echo '</p>';
	}

	/**
	 * Dropdown of roles ordered by plugin hierarchy.
	 */
	public function render_field_min_role() {
		$opts       = ontrack_get_options();
		$current    = isset( $opts['min_role_manage'] ) ? $opts['min_role_manage'] : 'administrator';
		$roles      = $this->get_roles_ordered();
		$field_name = ontrack_options_key() . '[min_role_manage]';
		echo '<select name="' . esc_attr( $field_name ) . '" id="ontrack_min_role_manage">';
		foreach ( $roles as $slug => $label ) {
			printf(
				'<option value="%s"%s>%s</option>',
				esc_attr( $slug ),
				selected( $current, $slug, false ),
				esc_html( $label )
			);
		}
		echo '</select>';
		echo '<p class="description">';
		esc_html_e( '”And above” follows the role order used by this plugin (Administrator is highest in default WordPress roles). Custom roles appear after the built-in ones unless changed via the ontrack_ordered_role_slugs filter. Group management uses the same threshold via map_meta_cap.', 'ontrack' );
		echo '</p>';
	}

	/**
	 * Role display names in hierarchy order, then any remaining roles.
	 *
	 * @return array<string, string> slug => label
	 */
	private function get_roles_ordered() {
		$wp_roles   = wp_roles();
		$ordered    = ontrack_get_ordered_role_slugs();
		$choices    = array();
		$dupe_guard = array();
		foreach ( $ordered as $slug ) {
			if ( isset( $wp_roles->roles[ $slug ] ) && ! isset( $dupe_guard[ $slug ] ) ) {
				$choices[ $slug ]            = translate_user_role( $wp_roles->roles[ $slug ]['name'] );
				$dupe_guard[ $slug ] = true;
			}
		}
		foreach ( $wp_roles->roles as $slug => $data ) {
			if ( ! isset( $dupe_guard[ $slug ] ) ) {
				$choices[ $slug ]            = translate_user_role( $data['name'] );
				$dupe_guard[ $slug ] = true;
			}
		}
		return $choices;
	}

	/**
	 * Mobile App section blurb.
	 */
	public function render_section_mobile_app() {
		echo '<p>';
		esc_html_e( 'Content displayed on the mobile app home screen. Changes take effect immediately — no app update required.', 'ontrack' );
		echo '</p>';
	}

	/**
	 * Media library picker for the home screen looping animation video.
	 */
	public function render_field_mobile_animation() {
		$opts          = ontrack_get_options();
		$attachment_id = (int) ( $opts['mobile_animation_attachment_id'] ?? 0 );
		$title         = $attachment_id ? get_the_title( $attachment_id ) : '';
		$name          = ontrack_options_key() . '[mobile_animation_attachment_id]';
		?>
		<input type="hidden"
			name="<?php echo esc_attr( $name ); ?>"
			id="ontrack_mobile_animation_id"
			value="<?php echo $attachment_id ?: ''; ?>" />
		<button type="button" class="button" id="ontrack-mobile-animation-pick">
			<?php esc_html_e( 'Choose video', 'ontrack' ); ?>
		</button>
		<?php if ( $attachment_id ) : ?>
			<button type="button" class="button" id="ontrack-mobile-animation-remove" style="margin-left:4px;">
				<?php esc_html_e( 'Remove', 'ontrack' ); ?>
			</button>
		<?php else : ?>
			<button type="button" class="button" id="ontrack-mobile-animation-remove" style="margin-left:4px; display:none;">
				<?php esc_html_e( 'Remove', 'ontrack' ); ?>
			</button>
		<?php endif; ?>
		<span id="ontrack-mobile-animation-title" style="margin-left:8px; font-style:italic;">
			<?php echo esc_html( $title ); ?>
		</span>
		<p class="description">
			<?php esc_html_e( 'MP4 video from the Media Library. Plays as a looping background on the mobile home screen.', 'ontrack' ); ?>
		</p>
		<?php
	}

	/**
	 * Repeatable rows editor for community links shown on the mobile home screen.
	 */
	public function render_field_community_links() {
		$opts  = ontrack_get_options();
		$links = ! empty( $opts['community_links'] ) ? $opts['community_links'] : array();
		$name  = ontrack_options_key() . '[community_links_json]';
		?>
		<input type="hidden" name="<?php echo esc_attr( $name ); ?>" id="ontrack-community-links-json"
			value="<?php echo esc_attr( wp_json_encode( $links ) ); ?>" />
		<table id="ontrack-community-links-table" style="border-collapse:collapse; margin-bottom:0.5em;">
			<thead>
				<tr>
					<th style="text-align:left; padding:0 8px 4px 0; font-weight:600;"><?php esc_html_e( 'Label', 'ontrack' ); ?></th>
					<th style="text-align:left; padding:0 8px 4px 0; font-weight:600;"><?php esc_html_e( 'URL', 'ontrack' ); ?></th>
					<th></th>
				</tr>
			</thead>
			<tbody id="ontrack-community-links-rows"></tbody>
		</table>
		<button type="button" class="button" id="ontrack-add-community-link">
			<?php esc_html_e( '+ Add link', 'ontrack' ); ?>
		</button>
		<p class="description" style="margin-top:0.5em;">
			<?php esc_html_e( 'External links shown on the mobile home screen. Drag to reorder (changes save on form submit).', 'ontrack' ); ?>
		</p>
		<script>
		( function () {
			var tbody    = document.getElementById( 'ontrack-community-links-rows' );
			var jsonInput = document.getElementById( 'ontrack-community-links-json' );
			var addBtn   = document.getElementById( 'ontrack-add-community-link' );
			if ( ! tbody || ! jsonInput || ! addBtn ) return;

			function serialize() {
				var rows  = tbody.querySelectorAll( 'tr' );
				var links = [];
				rows.forEach( function ( row ) {
					var label = row.querySelector( '.ontrack-link-label' ).value.trim();
					var url   = row.querySelector( '.ontrack-link-url' ).value.trim();
					if ( label && url ) links.push( { label: label, url: url } );
				} );
				jsonInput.value = JSON.stringify( links );
			}

			function makeRow( label, url ) {
				var tr = document.createElement( 'tr' );
				tr.innerHTML =
					'<td style="padding:2px 8px 2px 0;"><input type="text" class="ontrack-link-label regular-text" value="' + esc( label ) + '" placeholder="Label" /></td>' +
					'<td style="padding:2px 8px 2px 0;"><input type="url"  class="ontrack-link-url  regular-text" value="' + esc( url )   + '" placeholder="https://" /></td>' +
					'<td><button type="button" class="button-link ontrack-remove-link" style="color:#c62828;"><?php echo esc_js( __( 'Remove', 'ontrack' ) ); ?></button></td>';
				tr.querySelector( '.ontrack-remove-link' ).addEventListener( 'click', function () {
					tr.parentNode.removeChild( tr );
					serialize();
				} );
				tr.querySelectorAll( 'input' ).forEach( function ( input ) {
					input.addEventListener( 'input', serialize );
				} );
				return tr;
			}

			function esc( s ) {
				return ( s || '' ).replace( /&/g, '&amp;' ).replace( /"/g, '&quot;' );
			}

			// Populate from saved JSON.
			var saved = [];
			try { saved = JSON.parse( jsonInput.value ) || []; } catch (e) {}
			saved.forEach( function ( item ) {
				tbody.appendChild( makeRow( item.label, item.url ) );
			} );

			addBtn.addEventListener( 'click', function () {
				tbody.appendChild( makeRow( '', '' ) );
				serialize();
			} );
		} )();
		</script>
		<?php
	}

	/**
	 * Add Settings submenu.
	 */
	public function add_options_page() {
		add_options_page(
			__( 'KCFA Membership', 'ontrack' ),
			__( 'KCFA Membership', 'ontrack' ),
			'manage_options',
			'ontrack',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Output settings page.
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'ontrack' ) );
		}
		$this->maybe_render_jwt_regenerated_notice();
		?>
		<div class="wrap">
			<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
			<p><?php esc_html_e( 'Full member state is managed per user (profile screen). Catalogue URL and REST API enforcement are configured below.', 'ontrack' ); ?></p>
			<p>
				<?php
				echo wp_kses_post(
					sprintf(
						/* translators: %s: user meta key */
						__( 'Full member state is stored in user meta key <code>%s</code>. Missing or empty meta is treated as not a full member.', 'ontrack' ),
						esc_html( ontrack_meta_key_is_member() )
					)
				);
				?>
			</p>
			<form action="<?php echo esc_url( admin_url( 'options.php' ) ); ?>" method="post">
				<?php
				settings_fields( self::SETTINGS_GROUP );
				do_settings_sections( self::SETTINGS_GROUP );
				submit_button();
				?>
			</form>

			<hr />
			<h2><?php esc_html_e( 'Mobile authentication', 'ontrack' ); ?></h2>
			<?php $this->render_section_mobile_auth(); ?>
		</div>
		<?php
	}
}
