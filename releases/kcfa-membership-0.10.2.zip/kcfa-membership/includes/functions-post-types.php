<?php
/**
 * Ontrack custom post types: Audio Collections and Video Collections.
 *
 * Both are shown under the Ontrack admin menu (registered by the klac theme).
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register Ontrack custom post types.
 */
function ontrack_register_post_types() {
	$ontrack_menu_slug = 'ontrack';

	// Audio Collections (e.g. Box.com folders).
	register_post_type(
		'audio_collection',
		array(
			'labels'             => array(
				'name'               => _x( 'Audio Collections', 'post type general name', 'ontrack' ),
				'singular_name'      => _x( 'Audio Collection', 'post type singular name', 'ontrack' ),
				'menu_name'          => __( 'Audio Collections', 'ontrack' ),
				'add_new'            => __( 'Add New', 'ontrack' ),
				'add_new_item'       => __( 'Add New Audio Collection', 'ontrack' ),
				'edit_item'          => __( 'Edit Audio Collection', 'ontrack' ),
				'new_item'           => __( 'New Audio Collection', 'ontrack' ),
				'view_item'          => __( 'View Audio Collection', 'ontrack' ),
				'search_items'       => __( 'Search Audio Collections', 'ontrack' ),
				'not_found'          => __( 'No audio collections found.', 'ontrack' ),
				'not_found_in_trash' => __( 'No audio collections found in Trash.', 'ontrack' ),
			),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => $ontrack_menu_slug,
			'menu_position'      => 10,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'audio-collections' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'supports'           => array( 'title', 'editor', 'thumbnail' ),
		)
	);

	// Video Collections (e.g. Bunny.net, Vimeo).
	register_post_type(
		'video_collection',
		array(
			'labels'             => array(
				'name'               => _x( 'Video Collections', 'post type general name', 'ontrack' ),
				'singular_name'      => _x( 'Video Collection', 'post type singular name', 'ontrack' ),
				'menu_name'          => __( 'Video Collections', 'ontrack' ),
				'add_new'            => __( 'Add New', 'ontrack' ),
				'add_new_item'       => __( 'Add New Video Collection', 'ontrack' ),
				'edit_item'          => __( 'Edit Video Collection', 'ontrack' ),
				'new_item'           => __( 'New Video Collection', 'ontrack' ),
				'view_item'          => __( 'View Video Collection', 'ontrack' ),
				'search_items'       => __( 'Search Video Collections', 'ontrack' ),
				'not_found'          => __( 'No video collections found.', 'ontrack' ),
				'not_found_in_trash' => __( 'No video collections found in Trash.', 'ontrack' ),
			),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => $ontrack_menu_slug,
			'menu_position'      => 11,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'video-collections' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'supports'           => array( 'title', 'editor', 'thumbnail' ),
		)
	);
}
add_action( 'init', 'ontrack_register_post_types' );
