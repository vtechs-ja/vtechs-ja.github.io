<?php
/**
 * REST API endpoints for Ontrack media: audio/video playlists, stream proxy, audio metadata.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register REST routes for media endpoints.
 */
function ontrack_register_rest_routes() {
	$namespace = 'klac/v1';

	$collection_permission = class_exists( 'Ontrack_REST_Auth' )
		? array( 'Ontrack_REST_Auth', 'permission_callback_for_collection' )
		: '__return_true';

	$stream_permission = class_exists( 'Ontrack_REST_Auth' )
		? array( 'Ontrack_REST_Auth', 'permission_callback_stream' )
		: '__return_true';

	$authenticated = class_exists( 'Ontrack_REST_Auth' )
		? array( 'Ontrack_REST_Auth', 'require_authenticated_static' )
		: '__return_true';

	register_rest_route(
		$namespace,
		'/audio-collection/(?P<id>\d+)/playlist',
		array(
			'methods'             => 'GET',
			'callback'            => 'ontrack_playlist_callback',
			'permission_callback' => $collection_permission,
			'args'                => array(
				'id' => array(
					'required'          => true,
					'type'              => 'integer',
					'sanitize_callback' => 'absint',
				),
			),
		)
	);

	register_rest_route(
		$namespace,
		'/video-collection/(?P<id>\d+)/playlist',
		array(
			'methods'             => 'GET',
			'callback'            => 'ontrack_video_playlist_callback',
			'permission_callback' => $collection_permission,
			'args'                => array(
				'id' => array(
					'required'          => true,
					'type'              => 'integer',
					'sanitize_callback' => 'absint',
				),
			),
		)
	);

	register_rest_route(
		$namespace,
		'/stream/(?P<file_id>[a-zA-Z0-9]+)',
		array(
			'methods'             => 'GET',
			'callback'            => 'ontrack_stream_callback',
			'permission_callback' => $stream_permission,
			'args'                => array(
				'file_id' => array(
					'required'          => true,
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
				),
			),
		)
	);

	register_rest_route(
		$namespace,
		'/audio-metadata',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => 'ontrack_audio_metadata_callback',
			'permission_callback' => $authenticated,
		)
	);
}
add_action( 'rest_api_init', 'ontrack_register_rest_routes' );

/**
 * REST callback: return playlist for an audio collection.
 *
 * @param WP_REST_Request $request Request.
 * @return WP_REST_Response|WP_Error
 */
function ontrack_playlist_callback( $request ) {
	$post_id = $request->get_param( 'id' );
	$post    = get_post( $post_id );
	if ( ! $post || $post->post_type !== 'audio_collection' || $post->post_status !== 'publish' ) {
		return new WP_Error( 'not_found', __( 'Audio collection not found.', 'ontrack' ), array( 'status' => 404 ) );
	}

	$folder_id = get_post_meta( $post_id, '_ontrack_box_folder_id', true );
	if ( empty( $folder_id ) ) {
		return new WP_REST_Response( array( 'tracks' => array(), 'error' => __( 'No Box folder configured.', 'ontrack' ) ), 200 );
	}

	$token = ontrack_box_get_access_token();
	if ( is_wp_error( $token ) ) {
		return new WP_Error( 'config', $token->get_error_message(), array( 'status' => 503 ) );
	}

	$audio = ontrack_box_list_audio_in_folder( $folder_id, $token );
	if ( is_wp_error( $audio ) ) {
		return new WP_REST_Response(
			array(
				'tracks' => array(),
				'error'  => $audio->get_error_message(),
			),
			200
		);
	}

	if ( 'desc' === get_post_meta( $post_id, '_ontrack_sort_order', true ) ) {
		$audio = array_reverse( $audio );
	}

	$metadata = function_exists( 'ontrack_audio_metadata_get_for_collection' )
		? ontrack_audio_metadata_get_for_collection( $post_id )
		: array();

	$rest_url = rest_url( 'klac/v1/stream/' );
	$tracks   = array();
	foreach ( $audio as $item ) {
		$meta     = isset( $metadata[ $item['id'] ] ) ? $metadata[ $item['id'] ] : array();
		$tracks[] = array(
			'file_id'  => $item['id'],
			'name'     => ! empty( $meta['display_name'] ) ? $meta['display_name'] : $item['name'],
			'url'      => $rest_url . $item['id'],
			'featured' => ! empty( $meta['featured'] ),
		);
	}

	return new WP_REST_Response( array( 'tracks' => $tracks ), 200 );
}

/**
 * REST callback: return playlist for a video collection (Bunny or Vimeo).
 *
 * @param WP_REST_Request $request Request.
 * @return WP_REST_Response|WP_Error
 */
function ontrack_video_playlist_callback( $request ) {
	$post_id  = $request->get_param( 'id' );
	$post     = get_post( $post_id );
	if ( ! $post || 'video_collection' !== $post->post_type || 'publish' !== $post->post_status ) {
		return new WP_Error( 'not_found', __( 'Video collection not found.', 'ontrack' ), array( 'status' => 404 ) );
	}

	$provider = get_post_meta( $post_id, '_ontrack_video_provider', true );
	if ( ! in_array( $provider, array( 'bunny', 'vimeo' ), true ) ) {
		$provider = 'bunny';
	}

	$opts = get_option( 'ontrack_integrations', array() );

	if ( 'bunny' === $provider ) {
		$library_id = isset( $opts['bunny_library_id'] ) ? absint( $opts['bunny_library_id'] ) : 0;
		$api_key    = isset( $opts['bunny_api_key'] ) ? $opts['bunny_api_key'] : '';
		$collection = get_post_meta( $post_id, '_ontrack_bunny_collection_id', true );
		if ( ! $library_id || ! $collection ) {
			return new WP_REST_Response(
				array(
					'provider' => 'bunny',
					'tracks'   => array(),
					'error'    => __( 'Bunny library ID (Settings) or collection GUID (this post) is missing.', 'ontrack' ),
				),
				200
			);
		}
		if ( empty( $api_key ) ) {
			return new WP_Error( 'config', __( 'Bunny Stream API key not configured.', 'ontrack' ), array( 'status' => 503 ) );
		}
		$videos = ontrack_bunny_list_videos_in_collection( $library_id, $collection, $api_key );
		if ( is_wp_error( $videos ) ) {
			return new WP_REST_Response(
				array(
					'provider' => 'bunny',
					'tracks'   => array(),
					'error'    => $videos->get_error_message(),
				),
				200
			);
		}
		if ( 'desc' === get_post_meta( $post_id, '_ontrack_sort_order', true ) ) {
			$videos = array_reverse( $videos );
		}
		$tracks     = array();
		$embed_base = 'https://player.mediadelivery.net/embed/' . (string) $library_id . '/';
		$cdn_host   = isset( $opts['bunny_cdn_hostname'] ) ? trim( $opts['bunny_cdn_hostname'] ) : '';
		foreach ( $videos as $v ) {
			$thumbnail_url = '';
			if ( $cdn_host ) {
				$thumbnail_url = 'https://' . $cdn_host . '/' . $v['guid'] . '/' . $v['thumbnail_filename'];
			}
			$tracks[] = array(
				'video_id'      => $v['guid'],
				'title'         => $v['title'],
				'embed_url'     => $embed_base . $v['guid'],
				'thumbnail_url' => $thumbnail_url,
			);
		}
		return new WP_REST_Response( array( 'provider' => 'bunny', 'tracks' => $tracks ), 200 );
	}

	$showcase_id = get_post_meta( $post_id, '_ontrack_vimeo_showcase_id', true );
	$token       = isset( $opts['vimeo_access_token'] ) ? $opts['vimeo_access_token'] : '';
	if ( empty( $showcase_id ) ) {
		return new WP_REST_Response(
			array(
				'provider' => 'vimeo',
				'tracks'   => array(),
				'error'    => __( 'Vimeo showcase ID is missing for this post.', 'ontrack' ),
			),
			200
		);
	}
	if ( empty( $token ) ) {
		return new WP_Error( 'config', __( 'Vimeo access token not configured.', 'ontrack' ), array( 'status' => 503 ) );
	}
	$videos = ontrack_vimeo_list_showcase_videos( $showcase_id, $token );
	if ( is_wp_error( $videos ) ) {
		return new WP_REST_Response(
			array(
				'provider' => 'vimeo',
				'tracks'   => array(),
				'error'    => $videos->get_error_message(),
			),
			200
		);
	}
	if ( 'desc' === get_post_meta( $post_id, '_ontrack_sort_order', true ) ) {
		$videos = array_reverse( $videos );
	}
	$tracks = array();
	foreach ( $videos as $v ) {
		$tracks[] = array(
			'video_id'      => $v['video_id'],
			'title'         => $v['name'],
			'embed_url'     => $v['embed_url'],
			'thumbnail_url' => isset( $v['thumbnail'] ) ? $v['thumbnail'] : '',
		);
	}
	return new WP_REST_Response( array( 'provider' => 'vimeo', 'tracks' => $tracks ), 200 );
}

/**
 * REST callback: redirect to a pre-signed Box download URL.
 *
 * Box download URLs are temporary pre-signed tokens (expire ~15 min) that do not
 * expose the API key. Redirecting instead of proxying lets the client (expo-av)
 * make range requests directly against Box CDN for seeking support.
 *
 * @param WP_REST_Request $request Request.
 * @return void Redirects or exits on error.
 */
function ontrack_stream_callback( $request ) {
	$file_id = $request->get_param( 'file_id' );
	$token   = ontrack_box_get_access_token();
	if ( is_wp_error( $token ) ) {
		wp_die( esc_html( $token->get_error_message() ), '', array( 'response' => 503 ) );
	}

	$download_url = ontrack_box_get_download_url( $file_id, $token );
	if ( is_wp_error( $download_url ) ) {
		wp_die( esc_html( $download_url->get_error_message() ), '', array( 'response' => 502 ) );
	}

	// 302 so client re-validates on each play; pre-signed URL is safe to expose.
	wp_redirect( $download_url, 302 );
	exit;
}

/**
 * REST callback: GET /audio-metadata — all featured audio rows across all collections.
 * Used by mobile for auto-download seed on first launch.
 *
 * @param WP_REST_Request $request Request.
 * @return WP_REST_Response
 */
function ontrack_audio_metadata_callback( $request ) {
	$rows = function_exists( 'ontrack_audio_metadata_get_featured' )
		? ontrack_audio_metadata_get_featured()
		: array();

	return new WP_REST_Response( $rows, 200 );
}
