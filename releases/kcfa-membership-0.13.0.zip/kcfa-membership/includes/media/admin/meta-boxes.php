<?php
/**
 * Ontrack meta boxes for Audio and Video collections.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add meta box for Audio Collection: Box folder ID.
 */
function ontrack_add_audio_collection_meta_boxes() {
	add_meta_box(
		'ontrack_audio_collection_box',
		__( 'Box.com Folder', 'ontrack' ),
		'ontrack_audio_collection_box_callback',
		'audio_collection',
		'normal',
		'default',
		array()
	);
}
add_action( 'add_meta_boxes', 'ontrack_add_audio_collection_meta_boxes' );

/**
 * Render Box folder ID meta box.
 *
 * @param WP_Post $post Current post.
 */
function ontrack_audio_collection_box_callback( $post ) {
	wp_nonce_field( 'ontrack_audio_collection_save', 'ontrack_audio_collection_nonce' );
	$folder_id     = get_post_meta( $post->ID, '_ontrack_box_folder_id', true );
	$sort_order    = get_post_meta( $post->ID, '_ontrack_sort_order', true );
	$sort_order    = 'desc' === $sort_order ? 'desc' : 'asc';
	?>
	<p>
		<label for="ontrack_box_folder_id"><?php esc_html_e( 'Box Folder ID', 'ontrack' ); ?></label><br />
		<input type="text" id="ontrack_box_folder_id" name="ontrack_box_folder_id" value="<?php echo esc_attr( $folder_id ); ?>" class="regular-text" />
	</p>
	<p class="description">
		<?php esc_html_e( 'The Box folder ID that contains the audio files. Find it in the Box folder URL (e.g. …/folder/123456789).', 'ontrack' ); ?>
	</p>
	<p>
		<label for="ontrack_sort_order"><strong><?php esc_html_e( 'Track order', 'ontrack' ); ?></strong></label><br />
		<select id="ontrack_sort_order" name="ontrack_sort_order">
			<option value="asc" <?php selected( $sort_order, 'asc' ); ?>><?php esc_html_e( 'A → Z', 'ontrack' ); ?></option>
			<option value="desc" <?php selected( $sort_order, 'desc' ); ?>><?php esc_html_e( 'Z → A', 'ontrack' ); ?></option>
		</select>
	</p>
	<p class="description">
		<?php esc_html_e( 'Order tracks are shown to members, by file name.', 'ontrack' ); ?>
	</p>
	<?php
}

/**
 * Save Audio Collection meta.
 *
 * @param int $post_id Post ID.
 */
function ontrack_save_audio_collection_meta( $post_id ) {
	if ( ! isset( $_POST['ontrack_audio_collection_nonce'] ) ||
		! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ontrack_audio_collection_nonce'] ) ), 'ontrack_audio_collection_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	if ( ! current_user_can( 'klac_manage_media' ) ) {
		return;
	}
	if ( get_post_type( $post_id ) !== 'audio_collection' ) {
		return;
	}
	$folder_id = isset( $_POST['ontrack_box_folder_id'] ) ? sanitize_text_field( wp_unslash( $_POST['ontrack_box_folder_id'] ) ) : '';
	update_post_meta( $post_id, '_ontrack_box_folder_id', $folder_id );

	$sort_order = isset( $_POST['ontrack_sort_order'] ) && 'desc' === $_POST['ontrack_sort_order'] ? 'desc' : 'asc';
	update_post_meta( $post_id, '_ontrack_sort_order', $sort_order );
}
add_action( 'save_post_audio_collection', 'ontrack_save_audio_collection_meta' );

/**
 * Add meta box for Audio Collection: audio file metadata (display names + featured flags).
 * Requires the kcfa-membership plugin to be active for metadata functions.
 */
function ontrack_add_audio_files_meta_box() {
	add_meta_box(
		'ontrack_audio_files',
		__( 'Audio files', 'ontrack' ),
		'ontrack_audio_files_meta_box_callback',
		'audio_collection',
		'normal',
		'low'
	);
}
add_action( 'add_meta_boxes', 'ontrack_add_audio_files_meta_box' );

/**
 * Render Audio Files meta box.
 *
 * @param WP_Post $post Current post.
 */
function ontrack_audio_files_meta_box_callback( $post ) {
	if ( ! function_exists( 'ontrack_audio_metadata_get_for_collection' ) ) {
		echo '<p class="description">' . esc_html__( 'Ontrack plugin audio metadata functions are missing.', 'ontrack' ) . '</p>';
		return;
	}

	$folder_id = get_post_meta( $post->ID, '_ontrack_box_folder_id', true );
	if ( empty( $folder_id ) ) {
		echo '<p class="description">' . esc_html__( 'Set a Box Folder ID above and save the post before syncing audio files.', 'ontrack' ) . '</p>';
		return;
	}

	if ( ! current_user_can( 'klac_manage_media' ) ) {
		echo '<p class="description">' . esc_html__( 'You do not have permission to manage audio file metadata.', 'ontrack' ) . '</p>';
		return;
	}

	wp_nonce_field( 'ontrack_audio_files_save_' . $post->ID, 'ontrack_audio_files_nonce' );

	$metadata = ontrack_audio_metadata_get_for_collection( $post->ID );
	?>
	<p>
		<button type="button" id="ontrack-sync-audio-btn" class="button button-secondary" data-post-id="<?php echo esc_attr( (string) $post->ID ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'ontrack_sync_audio_files' ) ); ?>">
			<?php esc_html_e( 'Sync files from Box', 'ontrack' ); ?>
		</button>
		<span id="ontrack-sync-audio-status" style="margin-left:1em; color:#646970;"></span>
	</p>
	<p class="description"><?php esc_html_e( 'Fetches the current file list from Box, adds new files, and removes files no longer in the folder. Existing display names are preserved. Save the post after syncing to apply any display name or featured changes.', 'ontrack' ); ?></p>

	<div id="ontrack-audio-files-table-wrap">
		<?php ontrack_render_audio_files_table( $metadata ); ?>
	</div>

	<script>
	(function(){
		var btn    = document.getElementById('ontrack-sync-audio-btn');
		var status = document.getElementById('ontrack-sync-audio-status');
		var wrap   = document.getElementById('ontrack-audio-files-table-wrap');
		if (!btn) return;
		btn.addEventListener('click', function(){
			btn.disabled = true;
			status.textContent = <?php echo wp_json_encode( __( 'Syncing…', 'ontrack' ) ); ?>;
			var data = new FormData();
			data.append('action', 'ontrack_sync_audio_files');
			data.append('post_id', btn.dataset.postId);
			data.append('nonce', btn.dataset.nonce);
			fetch(ajaxurl, { method: 'POST', body: data })
				.then(function(r){ return r.json(); })
				.then(function(res){
					btn.disabled = false;
					if (res.success) {
						status.style.color = '#2e7d32';
						status.textContent = res.data.message;
						if (wrap && res.data.html) { wrap.innerHTML = res.data.html; }
					} else {
						status.style.color = '#c62828';
						status.textContent = res.data || <?php echo wp_json_encode( __( 'Sync failed.', 'ontrack' ) ); ?>;
					}
				})
				.catch(function(){
					btn.disabled = false;
					status.style.color = '#c62828';
					status.textContent = <?php echo wp_json_encode( __( 'Network error.', 'ontrack' ) ); ?>;
				});
		});
	})();
	</script>
	<?php
}

/**
 * Render the audio files table (shared between initial render and AJAX response).
 *
 * @param array $metadata Keyed by box_file_id from ontrack_audio_metadata_get_for_collection().
 */
function ontrack_render_audio_files_table( array $metadata ) {
	if ( empty( $metadata ) ) {
		echo '<p class="description">' . esc_html__( 'No audio files synced yet. Click "Sync files from Box" to populate.', 'ontrack' ) . '</p>';
		return;
	}
	?>
	<table class="widefat striped" style="margin-top:1em;">
		<thead>
			<tr>
				<th scope="col" style="width:2em;"><?php esc_html_e( 'Featured', 'ontrack' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Box file ID', 'ontrack' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Display name', 'ontrack' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $metadata as $row ) : ?>
				<?php $fid = esc_attr( $row['box_file_id'] ); ?>
				<tr>
					<td style="text-align:center;">
						<input type="checkbox"
							name="ontrack_audio_featured[<?php echo $fid; ?>]"
							value="1"
							<?php checked( ! empty( $row['featured'] ) ); ?>
						/>
					</td>
					<td><code><?php echo esc_html( $row['box_file_id'] ); ?></code></td>
					<td>
						<input type="text"
							name="ontrack_audio_display_name[<?php echo $fid; ?>]"
							value="<?php echo esc_attr( (string) $row['display_name'] ); ?>"
							class="regular-text"
							placeholder="<?php esc_attr_e( 'Use Box filename', 'ontrack' ); ?>"
						/>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php
}

/**
 * Save audio file display names and featured flags on post save.
 *
 * @param int $post_id Post ID.
 */
function ontrack_save_audio_files_meta( $post_id ) {
	if ( ! isset( $_POST['ontrack_audio_files_nonce'] ) ||
		! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ontrack_audio_files_nonce'] ) ), 'ontrack_audio_files_save_' . $post_id ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'klac_manage_media' ) ) {
		return;
	}
	if ( ! function_exists( 'ontrack_audio_metadata_upsert' ) || ! function_exists( 'ontrack_audio_metadata_get_for_collection' ) ) {
		return;
	}

	$existing = ontrack_audio_metadata_get_for_collection( $post_id );
	if ( empty( $existing ) ) {
		return;
	}

	// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized per-field below.
	$display_names = isset( $_POST['ontrack_audio_display_name'] ) ? wp_unslash( $_POST['ontrack_audio_display_name'] ) : array();
	$featured_map  = isset( $_POST['ontrack_audio_featured'] ) ? wp_unslash( $_POST['ontrack_audio_featured'] ) : array();

	foreach ( $existing as $file_id => $row ) {
		$display_name = isset( $display_names[ $file_id ] )
			? sanitize_text_field( $display_names[ $file_id ] )
			: $row['display_name'];
		$featured = ! empty( $featured_map[ $file_id ] );
		ontrack_audio_metadata_upsert( $file_id, $post_id, $display_name ?: null, $featured );
	}
}
add_action( 'save_post_audio_collection', 'ontrack_save_audio_files_meta' );

/**
 * AJAX: sync Box folder contents into the audio metadata table.
 */
function ontrack_ajax_sync_audio_files() {
	check_ajax_referer( 'ontrack_sync_audio_files', 'nonce' );

	if ( ! current_user_can( 'klac_manage_media' ) ) {
		wp_send_json_error( __( 'Permission denied.', 'ontrack' ) );
	}
	if ( ! function_exists( 'ontrack_audio_metadata_upsert' ) ||
		 ! function_exists( 'ontrack_audio_metadata_delete_stale' ) ||
		 ! function_exists( 'ontrack_audio_metadata_get_for_collection' ) ) {
		wp_send_json_error( __( 'Ontrack plugin is required.', 'ontrack' ) );
	}

	$post_id = isset( $_POST['post_id'] ) ? (int) $_POST['post_id'] : 0;
	if ( $post_id <= 0 || get_post_type( $post_id ) !== 'audio_collection' ) {
		wp_send_json_error( __( 'Invalid collection.', 'ontrack' ) );
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		wp_send_json_error( __( 'Permission denied.', 'ontrack' ) );
	}

	$folder_id = get_post_meta( $post_id, '_ontrack_box_folder_id', true );
	if ( empty( $folder_id ) ) {
		wp_send_json_error( __( 'No Box folder configured for this collection.', 'ontrack' ) );
	}

	$token = ontrack_box_get_access_token();
	if ( is_wp_error( $token ) ) {
		wp_send_json_error( $token->get_error_message() );
	}

	$audio = ontrack_box_list_audio_in_folder( $folder_id, $token );
	if ( is_wp_error( $audio ) ) {
		wp_send_json_error( $audio->get_error_message() );
	}

	// Upsert all current files (preserves existing display names).
	$current_ids = array();
	foreach ( $audio as $item ) {
		$existing     = ontrack_audio_metadata_get_for_collection( $post_id );
		$display_name = isset( $existing[ $item['id'] ] ) ? $existing[ $item['id'] ]['display_name'] : null;
		$featured     = isset( $existing[ $item['id'] ] ) ? $existing[ $item['id'] ]['featured'] : false;
		ontrack_audio_metadata_upsert( $item['id'], $post_id, $display_name, $featured );
		$current_ids[] = $item['id'];
	}

	$deleted = ontrack_audio_metadata_delete_stale( $post_id, $current_ids );
	$updated = ontrack_audio_metadata_get_for_collection( $post_id );

	ob_start();
	ontrack_render_audio_files_table( $updated );
	$html = ob_get_clean();

	$count = count( $updated );
	wp_send_json_success( array(
		'html'    => $html,
		'message' => sprintf(
			/* translators: 1: synced file count, 2: deleted row count */
			_n( 'Synced %1$d file (%2$d removed).', 'Synced %1$d files (%2$d removed).', $count, 'ontrack' ),
			$count,
			$deleted
		),
	) );
}
add_action( 'wp_ajax_ontrack_sync_audio_files', 'ontrack_ajax_sync_audio_files' );

/**
 * Add meta box for Video Collection: provider (Bunny / Vimeo) and IDs.
 */
function ontrack_add_video_collection_meta_boxes() {
	add_meta_box(
		'ontrack_video_collection_box',
		__( 'Video source', 'ontrack' ),
		'ontrack_video_collection_box_callback',
		'video_collection',
		'normal',
		'default',
		array()
	);
}
add_action( 'add_meta_boxes', 'ontrack_add_video_collection_meta_boxes' );

/**
 * Render Video Collection meta box.
 *
 * @param WP_Post $post Current post.
 */
function ontrack_video_collection_box_callback( $post ) {
	wp_nonce_field( 'ontrack_video_collection_save', 'ontrack_video_collection_nonce' );
	$provider          = get_post_meta( $post->ID, '_ontrack_video_provider', true );
	$bunny_collection  = get_post_meta( $post->ID, '_ontrack_bunny_collection_id', true );
	$vimeo_showcase    = get_post_meta( $post->ID, '_ontrack_vimeo_showcase_id', true );
	$sort_order        = get_post_meta( $post->ID, '_ontrack_sort_order', true );
	$sort_order        = 'desc' === $sort_order ? 'desc' : 'asc';

	if ( ! in_array( $provider, array( 'bunny', 'vimeo' ), true ) ) {
		$provider = 'bunny';
	}
	?>
	<p>
		<label for="ontrack_video_provider"><strong><?php esc_html_e( 'Provider', 'ontrack' ); ?></strong></label><br />
		<select id="ontrack_video_provider" name="ontrack_video_provider" class="widefat">
			<option value="bunny" <?php selected( $provider, 'bunny' ); ?>><?php esc_html_e( 'Bunny.net Stream', 'ontrack' ); ?></option>
			<option value="vimeo" <?php selected( $provider, 'vimeo' ); ?>><?php esc_html_e( 'Vimeo (showcase)', 'ontrack' ); ?></option>
		</select>
	</p>
	<p class="description">
		<?php esc_html_e( 'Choose where this collection pulls its videos from.', 'ontrack' ); ?>
	</p>
	<div class="ontrack-video-meta-bunny" style="margin-top:1em;">
		<p>
			<label for="ontrack_bunny_collection_id"><strong><?php esc_html_e( 'Bunny Stream collection ID (GUID)', 'ontrack' ); ?></strong></label><br />
			<input type="text" id="ontrack_bunny_collection_id" name="ontrack_bunny_collection_id" value="<?php echo esc_attr( $bunny_collection ); ?>" class="regular-text" />
		</p>
		<p class="description">
			<?php esc_html_e( 'The collection GUID from Bunny Stream (Video Library → Collections). Videos must be in this collection. Library ID and API key are set under Ontrack → Settings.', 'ontrack' ); ?>
		</p>
	</div>
	<div class="ontrack-video-meta-vimeo" style="margin-top:1em;">
		<p>
			<label for="ontrack_vimeo_showcase_id"><strong><?php esc_html_e( 'Vimeo showcase ID', 'ontrack' ); ?></strong></label><br />
			<input type="text" id="ontrack_vimeo_showcase_id" name="ontrack_vimeo_showcase_id" value="<?php echo esc_attr( $vimeo_showcase ); ?>" class="regular-text" />
		</p>
		<p class="description">
			<?php esc_html_e( 'The numeric showcase ID (Vimeo API uses "albums"). Find it in the showcase settings URL or via the Vimeo API. Access token is set under Ontrack → Settings.', 'ontrack' ); ?>
		</p>
	</div>
	<p style="margin-top:1em;">
		<label for="ontrack_sort_order"><strong><?php esc_html_e( 'Video order', 'ontrack' ); ?></strong></label><br />
		<select id="ontrack_sort_order" name="ontrack_sort_order">
			<option value="asc" <?php selected( $sort_order, 'asc' ); ?>><?php esc_html_e( 'A → Z', 'ontrack' ); ?></option>
			<option value="desc" <?php selected( $sort_order, 'desc' ); ?>><?php esc_html_e( 'Z → A', 'ontrack' ); ?></option>
		</select>
	</p>
	<p class="description">
		<?php esc_html_e( 'Order videos are shown to members, by title.', 'ontrack' ); ?>
	</p>
	<script>
	(function(){
		var sel = document.getElementById('ontrack_video_provider');
		var b = document.querySelector('.ontrack-video-meta-bunny');
		var v = document.querySelector('.ontrack-video-meta-vimeo');
		function toggle(){
			if (!b || !v || !sel) return;
			b.style.display = sel.value === 'bunny' ? 'block' : 'none';
			v.style.display = sel.value === 'vimeo' ? 'block' : 'none';
		}
		sel.addEventListener('change', toggle);
		toggle();
	})();
	</script>
	<?php
}

/**
 * Save Video Collection meta.
 *
 * @param int $post_id Post ID.
 */
function ontrack_save_video_collection_meta( $post_id ) {
	if ( ! isset( $_POST['ontrack_video_collection_nonce'] ) ||
		! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ontrack_video_collection_nonce'] ) ), 'ontrack_video_collection_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	if ( ! current_user_can( 'klac_manage_media' ) ) {
		return;
	}
	if ( get_post_type( $post_id ) !== 'video_collection' ) {
		return;
	}
	$provider = isset( $_POST['ontrack_video_provider'] ) ? sanitize_text_field( wp_unslash( $_POST['ontrack_video_provider'] ) ) : 'bunny';
	if ( ! in_array( $provider, array( 'bunny', 'vimeo' ), true ) ) {
		$provider = 'bunny';
	}
	update_post_meta( $post_id, '_ontrack_video_provider', $provider );

	$bunny_collection = isset( $_POST['ontrack_bunny_collection_id'] ) ? sanitize_text_field( wp_unslash( $_POST['ontrack_bunny_collection_id'] ) ) : '';
	$vimeo_showcase   = isset( $_POST['ontrack_vimeo_showcase_id'] ) ? sanitize_text_field( wp_unslash( $_POST['ontrack_vimeo_showcase_id'] ) ) : '';
	update_post_meta( $post_id, '_ontrack_bunny_collection_id', $bunny_collection );
	update_post_meta( $post_id, '_ontrack_vimeo_showcase_id', $vimeo_showcase );

	$sort_order = isset( $_POST['ontrack_sort_order'] ) && 'desc' === $_POST['ontrack_sort_order'] ? 'desc' : 'asc';
	update_post_meta( $post_id, '_ontrack_sort_order', $sort_order );
}
add_action( 'save_post_video_collection', 'ontrack_save_video_collection_meta' );

/**
 * Enqueue the WP media library on page edit screens (for the animation picker).
 *
 * @param string $hook Current admin page hook.
 */
function ontrack_members_area_admin_enqueue( $hook ) {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		return;
	}
	$screen = get_current_screen();
	if ( $screen && 'page' === $screen->post_type ) {
		wp_enqueue_media();
	}
}
add_action( 'admin_enqueue_scripts', 'ontrack_members_area_admin_enqueue' );

/**
 * Meta box for Members Area page template options (animation + countdown).
 */
function ontrack_add_members_area_meta_box() {
	add_meta_box(
		'ontrack_members_area_options',
		__( 'Members Area Options', 'ontrack' ),
		'ontrack_members_area_meta_box_callback',
		'page',
		'normal',
		'default'
	);
}
add_action( 'add_meta_boxes_page', 'ontrack_add_members_area_meta_box' );

/**
 * Render Members Area meta box.
 *
 * @param WP_Post $post Current post.
 */
function ontrack_members_area_meta_box_callback( $post ) {
	wp_nonce_field( 'ontrack_members_area_save', 'ontrack_members_area_nonce' );

	$show_animation   = (bool) get_post_meta( $post->ID, '_ontrack_members_show_animation', true );
	$animation_id     = (int) get_post_meta( $post->ID, '_ontrack_members_animation_id', true );
	$animation_title  = $animation_id ? get_the_title( $animation_id ) : '';

	$show_countdown   = (bool) get_post_meta( $post->ID, '_ontrack_members_show_countdown', true );
	$countdown_mode   = get_post_meta( $post->ID, '_ontrack_members_countdown_mode', true ) ?: 'weekly';
	$countdown_day    = (int) get_post_meta( $post->ID, '_ontrack_members_countdown_day', true );
	$countdown_time   = get_post_meta( $post->ID, '_ontrack_members_countdown_time', true ) ?: '09:00';
	$countdown_rest   = get_post_meta( $post->ID, '_ontrack_members_countdown_rest', true );
	$countdown_rest   = '' !== $countdown_rest ? (int) $countdown_rest : 3;
	$countdown_date   = get_post_meta( $post->ID, '_ontrack_members_countdown_date', true );

	$days = array(
		0 => __( 'Sunday', 'ontrack' ),
		1 => __( 'Monday', 'ontrack' ),
		2 => __( 'Tuesday', 'ontrack' ),
		3 => __( 'Wednesday', 'ontrack' ),
		4 => __( 'Thursday', 'ontrack' ),
		5 => __( 'Friday', 'ontrack' ),
		6 => __( 'Saturday', 'ontrack' ),
	);
	?>
	<p class="description"><?php esc_html_e( 'These settings apply when this page uses the "Members Area" template.', 'ontrack' ); ?></p>
	<table class="form-table" role="presentation">

		<tr>
			<th scope="row"><?php esc_html_e( 'Animation', 'ontrack' ); ?></th>
			<td>
				<label>
					<input type="checkbox" name="ontrack_members_show_animation" value="1" <?php checked( $show_animation ); ?> />
					<?php esc_html_e( 'Show looping animation video', 'ontrack' ); ?>
				</label>
			</td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'Animation video', 'ontrack' ); ?></th>
			<td>
				<input type="hidden" id="ontrack-members-animation-id" name="ontrack_members_animation_id"
					value="<?php echo esc_attr( (string) $animation_id ); ?>" />
				<button type="button" id="ontrack-members-animation-select" class="button">
					<?php esc_html_e( 'Select from Media Library', 'ontrack' ); ?>
				</button>
				<button type="button" id="ontrack-members-animation-remove" class="button"
					<?php echo $animation_id ? '' : 'style="display:none"'; ?>>
					<?php esc_html_e( 'Remove', 'ontrack' ); ?>
				</button>
				<span id="ontrack-members-animation-title" style="margin-left:.5em;color:#646970;">
					<?php echo esc_html( $animation_title ); ?>
				</span>
				<p class="description"><?php esc_html_e( 'Pick an MP4 or WebM file. Plays muted, looping, and automatically.', 'ontrack' ); ?></p>
				<script>
				(function () {
					var idInput   = document.getElementById( 'ontrack-members-animation-id' );
					var titleEl   = document.getElementById( 'ontrack-members-animation-title' );
					var selectBtn = document.getElementById( 'ontrack-members-animation-select' );
					var removeBtn = document.getElementById( 'ontrack-members-animation-remove' );
					if ( ! selectBtn || typeof wp === 'undefined' || ! wp.media ) return;
					var frame;
					selectBtn.addEventListener( 'click', function () {
						if ( frame ) { frame.open(); return; }
						frame = wp.media( {
							title:    <?php echo wp_json_encode( __( 'Select animation video', 'ontrack' ) ); ?>,
							button:   { text: <?php echo wp_json_encode( __( 'Use this video', 'ontrack' ) ); ?> },
							library:  { type: 'video' },
							multiple: false,
						} );
						frame.on( 'select', function () {
							var attachment = frame.state().get( 'selection' ).first().toJSON();
							idInput.value       = attachment.id;
							titleEl.textContent = attachment.title || attachment.filename;
							removeBtn.style.display = '';
						} );
						frame.open();
					} );
					removeBtn.addEventListener( 'click', function () {
						idInput.value       = '';
						titleEl.textContent = '';
						removeBtn.style.display = 'none';
					} );
				} )();
				</script>
			</td>
		</tr>

		<tr>
			<th scope="row"><?php esc_html_e( 'Countdown', 'ontrack' ); ?></th>
			<td>
				<label>
					<input type="checkbox" name="ontrack_members_show_countdown" value="1" <?php checked( $show_countdown ); ?> />
					<?php esc_html_e( 'Show countdown timer', 'ontrack' ); ?>
				</label>
			</td>
		</tr>
		<tr>
			<th scope="row"><label for="ontrack-countdown-mode"><?php esc_html_e( 'Countdown mode', 'ontrack' ); ?></label></th>
			<td>
				<select id="ontrack-countdown-mode" name="ontrack_members_countdown_mode">
					<option value="weekly" <?php selected( $countdown_mode, 'weekly' ); ?>><?php esc_html_e( 'Weekly (recurring)', 'ontrack' ); ?></option>
					<option value="once"   <?php selected( $countdown_mode, 'once' ); ?>><?php esc_html_e( 'One-time date', 'ontrack' ); ?></option>
				</select>
			</td>
		</tr>
		<tr class="ontrack-countdown-weekly-row" <?php echo 'once' === $countdown_mode ? 'style="display:none"' : ''; ?>>
			<th scope="row"><label for="ontrack-countdown-day"><?php esc_html_e( 'Day of week', 'ontrack' ); ?></label></th>
			<td>
				<select id="ontrack-countdown-day" name="ontrack_members_countdown_day">
					<?php foreach ( $days as $num => $label ) : ?>
						<option value="<?php echo esc_attr( (string) $num ); ?>" <?php selected( $countdown_day, $num ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</td>
		</tr>
		<tr class="ontrack-countdown-weekly-row" <?php echo 'once' === $countdown_mode ? 'style="display:none"' : ''; ?>>
			<th scope="row"><label for="ontrack-countdown-time"><?php esc_html_e( 'Time', 'ontrack' ); ?></label></th>
			<td>
				<input type="time" id="ontrack-countdown-time" name="ontrack_members_countdown_time"
					value="<?php echo esc_attr( $countdown_time ); ?>" />
				<p class="description"><?php esc_html_e( 'Uses the server timezone.', 'ontrack' ); ?></p>
			</td>
		</tr>
		<tr class="ontrack-countdown-once-row" <?php echo 'weekly' === $countdown_mode ? 'style="display:none"' : ''; ?>>
			<th scope="row"><label for="ontrack-countdown-date"><?php esc_html_e( 'Target date &amp; time', 'ontrack' ); ?></label></th>
			<td>
				<input type="datetime-local" id="ontrack-countdown-date" name="ontrack_members_countdown_date"
					value="<?php echo esc_attr( $countdown_date ); ?>" />
			</td>
		</tr>
		<tr>
			<th scope="row"><label for="ontrack-countdown-rest"><?php esc_html_e( '"In progress" window (hours)', 'ontrack' ); ?></label></th>
			<td>
				<input type="number" id="ontrack-countdown-rest" name="ontrack_members_countdown_rest"
					value="<?php echo esc_attr( (string) $countdown_rest ); ?>" min="0" max="24" style="width:5em;" />
				<p class="description"><?php esc_html_e( 'How many hours after the target to show "in progress" before counting down to the next occurrence.', 'ontrack' ); ?></p>
			</td>
		</tr>

	</table>

	<script>
	(function () {
		var modeSelect   = document.getElementById( 'ontrack-countdown-mode' );
		var weeklyRows   = document.querySelectorAll( '.ontrack-countdown-weekly-row' );
		var onceRows     = document.querySelectorAll( '.ontrack-countdown-once-row' );
		if ( ! modeSelect ) return;
		function toggle() {
			var isWeekly = modeSelect.value === 'weekly';
			weeklyRows.forEach( function ( r ) { r.style.display = isWeekly ? '' : 'none'; } );
			onceRows.forEach(   function ( r ) { r.style.display = isWeekly ? 'none' : ''; } );
		}
		modeSelect.addEventListener( 'change', toggle );
	} )();
	</script>
	<?php
}

/**
 * Save Members Area page meta.
 *
 * @param int $post_id Post ID.
 */
function ontrack_save_members_area_meta( $post_id ) {
	if ( ! isset( $_POST['ontrack_members_area_nonce'] ) ||
		! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ontrack_members_area_nonce'] ) ), 'ontrack_members_area_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	update_post_meta( $post_id, '_ontrack_members_show_animation', ! empty( $_POST['ontrack_members_show_animation'] ) ? '1' : '' );

	$animation_id = isset( $_POST['ontrack_members_animation_id'] ) ? (int) wp_unslash( $_POST['ontrack_members_animation_id'] ) : 0;
	update_post_meta( $post_id, '_ontrack_members_animation_id', $animation_id > 0 ? $animation_id : '' );

	update_post_meta( $post_id, '_ontrack_members_show_countdown', ! empty( $_POST['ontrack_members_show_countdown'] ) ? '1' : '' );

	$mode = isset( $_POST['ontrack_members_countdown_mode'] ) && 'once' === $_POST['ontrack_members_countdown_mode'] ? 'once' : 'weekly';
	update_post_meta( $post_id, '_ontrack_members_countdown_mode', $mode );

	$day = isset( $_POST['ontrack_members_countdown_day'] ) ? (int) wp_unslash( $_POST['ontrack_members_countdown_day'] ) : 0;
	update_post_meta( $post_id, '_ontrack_members_countdown_day', max( 0, min( 6, $day ) ) );

	$time = isset( $_POST['ontrack_members_countdown_time'] ) ? sanitize_text_field( wp_unslash( $_POST['ontrack_members_countdown_time'] ) ) : '09:00';
	if ( ! preg_match( '/^\d{2}:\d{2}$/', $time ) ) {
		$time = '09:00';
	}
	update_post_meta( $post_id, '_ontrack_members_countdown_time', $time );

	$rest = isset( $_POST['ontrack_members_countdown_rest'] ) ? (int) wp_unslash( $_POST['ontrack_members_countdown_rest'] ) : 3;
	update_post_meta( $post_id, '_ontrack_members_countdown_rest', max( 0, min( 24, $rest ) ) );

	$date = isset( $_POST['ontrack_members_countdown_date'] ) ? sanitize_text_field( wp_unslash( $_POST['ontrack_members_countdown_date'] ) ) : '';
	update_post_meta( $post_id, '_ontrack_members_countdown_date', $date );
}
add_action( 'save_post_page', 'ontrack_save_members_area_meta' );
