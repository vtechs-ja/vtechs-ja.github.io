/**
 * Ontrack video player: playlist from REST, Bunny or Vimeo embed iframe.
 *
 * The page template supplies the embed, the "now playing" line and an empty
 * playlist list. This script fetches the playlist and builds the rest: the
 * Previous / Next / Hide playlist controls, the playlist panel with its scroll
 * cues, and the playlist rows. Layout is handled entirely by CSS.
 *
 * @package Ontrack
 */

(function () {
	'use strict';

	var wrap = document.getElementById('ontrack-video-player-wrap');
	if (!wrap) return;

	var collectionId = wrap.getAttribute('data-collection-id');
	if (!collectionId) return;

	var cfg = typeof ontrackVideoPlayer !== 'undefined' ? ontrackVideoPlayer : {};
	var restUrl = cfg.restUrl ? cfg.restUrl : '/wp-json/klac/v1';
	var playlistUrl = restUrl + '/video-collection/' + collectionId + '/playlist';

	var STRINGS = {
		playlist: 'Playlist',
		previous: 'Previous',
		next: 'Next',
		hidePlaylist: 'Hide playlist',
		showPlaylist: 'Show playlist',
		hideList: 'Hide list',
		showList: 'Show list',
		nowPlaying: 'Now playing',
		nowPlayingOf: 'Now playing \u00b7 {n} of {total}',
		videoOf: 'Video {n} of {total}',
		video: 'Video {n}',
		moreVideos: 'More videos'
	};
	var strings = cfg.i18n || {};

	function t(key, vars) {
		var s = strings[key] || STRINGS[key] || key;
		if (vars) {
			Object.keys(vars).forEach(function (k) {
				s = s.split('{' + k + '}').join(String(vars[k]));
			});
		}
		return s;
	}

	var STORAGE_KEY = 'ontrack_video_playlist_open';

	var loadingEl = wrap.querySelector('.ontrack-video-player-loading');
	var mainEl = wrap.querySelector('.ontrack-video-player-main');
	var errorEl = wrap.querySelector('.ontrack-video-player-error');
	var embedWrap = wrap.querySelector('.ontrack-video-embed-wrap');
	var iframeEl = wrap.querySelector('.ontrack-video-iframe');
	var nowPlayingEl = wrap.querySelector('.ontrack-video-now-playing');
	var playlistOl = wrap.querySelector('.ontrack-video-playlist');
	var oldLabelEl = wrap.querySelector('.ontrack-playlist-label');

	var tracks = [];
	var currentIndex = 0;
	var playlistOpen = true;

	var positionEl, prevBtn, nextBtn, toggleBtn, toggleLong, toggleShort;
	var panelEl, countEl, listWrap, scroller, moreBtn;

	function el(tag, className, text) {
		var n = document.createElement(tag);
		if (className) n.className = className;
		if (text) n.textContent = text;
		return n;
	}

	function readOpenPref() {
		try {
			return window.localStorage.getItem(STORAGE_KEY) !== '0';
		} catch (e) {
			return true;
		}
	}

	function saveOpenPref(open) {
		try {
			window.localStorage.setItem(STORAGE_KEY, open ? '1' : '0');
		} catch (e) { /* storage unavailable: the preference just isn't remembered */ }
	}

	/**
	 * Build the controls and the playlist panel around the existing nodes.
	 */
	function buildChrome() {
		if (oldLabelEl && oldLabelEl.parentNode) oldLabelEl.parentNode.removeChild(oldLabelEl);

		var stage = el('div', 'ontrack-video-stage');
		mainEl.insertBefore(stage, mainEl.firstChild);
		stage.appendChild(embedWrap);

		var controls = el('div', 'ontrack-video-controls');
		var nowWrap = el('div', 'ontrack-video-nowwrap');
		positionEl = el('span', 'ontrack-video-position');
		nowWrap.appendChild(positionEl);
		nowWrap.appendChild(nowPlayingEl);
		controls.appendChild(nowWrap);

		var buttons = el('div', 'ontrack-video-buttons');
		prevBtn = el('button', 'ontrack-btn ontrack-video-prev', t('previous'));
		prevBtn.type = 'button';
		nextBtn = el('button', 'ontrack-btn ontrack-btn-primary ontrack-video-next', t('next'));
		nextBtn.type = 'button';
		toggleBtn = el('button', 'ontrack-btn ontrack-video-toggle');
		toggleBtn.type = 'button';
		toggleLong = el('span', 'ontrack-label-long');
		toggleShort = el('span', 'ontrack-label-short');
		toggleBtn.appendChild(toggleLong);
		toggleBtn.appendChild(toggleShort);
		buttons.appendChild(prevBtn);
		buttons.appendChild(nextBtn);
		buttons.appendChild(el('span', 'ontrack-btn-spacer'));
		buttons.appendChild(toggleBtn);
		controls.appendChild(buttons);
		stage.appendChild(controls);

		panelEl = el('div', 'ontrack-video-panel');
		panelEl.id = 'ontrack-video-panel';
		var head = el('div', 'ontrack-video-panel-head');
		head.appendChild(el('strong', '', t('playlist')));
		countEl = el('span', 'ontrack-video-count');
		head.appendChild(countEl);
		panelEl.appendChild(head);

		listWrap = el('div', 'ontrack-listwrap');
		scroller = el('div', 'ontrack-scroller');
		scroller.appendChild(playlistOl);
		listWrap.appendChild(scroller);
		listWrap.appendChild(el('div', 'ontrack-fade'));
		moreBtn = el('button', 'ontrack-more', t('moreVideos'));
		moreBtn.type = 'button';
		listWrap.appendChild(moreBtn);
		panelEl.appendChild(listWrap);
		mainEl.appendChild(panelEl);

		toggleBtn.setAttribute('aria-controls', panelEl.id);
		prevBtn.addEventListener('click', function () { playIndex(currentIndex - 1, true); });
		nextBtn.addEventListener('click', function () { playIndex(currentIndex + 1, true); });
		toggleBtn.addEventListener('click', function () {
			setPlaylistOpen(!playlistOpen);
			saveOpenPref(playlistOpen);
		});
		moreBtn.addEventListener('click', function () {
			scroller.scrollBy({ top: scroller.clientHeight * 0.8, behavior: 'smooth' });
		});
		scroller.addEventListener('scroll', updateScrollCues);
		window.addEventListener('resize', updateScrollCues);

		setPlaylistOpen(readOpenPref());
	}

	function setPlaylistOpen(open) {
		playlistOpen = open;
		panelEl.hidden = !open;
		mainEl.classList.toggle('is-playlist-hidden', !open);
		toggleBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
		toggleLong.textContent = open ? t('hidePlaylist') : t('showPlaylist');
		toggleShort.textContent = open ? t('hideList') : t('showList');
		if (open) {
			revealActive();
			updateScrollCues();
		}
	}

	function updateScrollCues() {
		if (!scroller) return;
		var atEnd = scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 4;
		listWrap.classList.toggle('is-at-end', atEnd);
	}

	/** Scroll the list itself (never the page) so the current row sits mid-list. */
	function revealActive() {
		var row = playlistOl.querySelector('.is-active');
		if (!row || !scroller || panelEl.hidden) return;
		scroller.scrollTop = Math.max(0, row.offsetTop - (scroller.clientHeight - row.offsetHeight) / 2);
	}

	function showLoading(show) {
		loadingEl.hidden = !show;
		if (show) {
			mainEl.setAttribute('hidden', '');
			errorEl.hidden = true;
		}
	}

	function showError(message) {
		loadingEl.hidden = true;
		mainEl.setAttribute('hidden', '');
		errorEl.hidden = false;
		errorEl.textContent = message || 'Failed to load playlist.';
	}

	function showMain() {
		loadingEl.hidden = true;
		errorEl.hidden = true;
		mainEl.removeAttribute('hidden');
	}

	function playIndex(index, autoplay) {
		if (index < 0 || index >= tracks.length || !iframeEl) return;
		currentIndex = index;
		var tr = tracks[index];
		var url = tr.embed_url;
		if (autoplay) {
			url += (url.indexOf('?') >= 0 ? '&' : '?') + 'autoplay=1';
		}
		iframeEl.src = url;
		iframeEl.setAttribute('title', tr.title);
		nowPlayingEl.textContent = tr.title;
		positionEl.textContent = t('nowPlayingOf', { n: index + 1, total: tracks.length });
		countEl.textContent = t('videoOf', { n: index + 1, total: tracks.length });
		prevBtn.disabled = index === 0;
		nextBtn.disabled = index === tracks.length - 1;

		playlistOl.querySelectorAll('li').forEach(function (li, i) {
			var on = i === index;
			li.classList.toggle('is-active', on);
			var btn = li.firstChild;
			if (on) btn.setAttribute('aria-current', 'true'); else btn.removeAttribute('aria-current');
			var meta = li.querySelector('.ontrack-video-meta');
			meta.textContent = '';
			if (on) {
				meta.appendChild(el('span', 'ontrack-pill', t('nowPlaying')));
			} else {
				meta.textContent = t('video', { n: i + 1 });
			}
		});
		revealActive();
		updateScrollCues();
	}

	function buildPlaylist() {
		playlistOl.innerHTML = '';
		tracks.forEach(function (tr, i) {
			var li = el('li', 'ontrack-video-playlist-item');
			var btn = el('button', 'ontrack-video-playlist-link');
			btn.type = 'button';
			var thumb = el('span', 'ontrack-video-thumb');
			if (tr.thumbnail_url) {
				var img = document.createElement('img');
				img.src = tr.thumbnail_url;
				img.alt = '';
				img.loading = 'lazy';
				img.className = 'ontrack-video-playlist-thumb';
				thumb.appendChild(img);
			}
			btn.appendChild(thumb);
			var text = el('span', 'ontrack-video-text');
			text.appendChild(el('span', 'ontrack-video-title', tr.title));
			text.appendChild(el('span', 'ontrack-video-meta'));
			btn.appendChild(text);
			btn.addEventListener('click', function () {
				playIndex(i, true);
			});
			li.appendChild(btn);
			playlistOl.appendChild(li);
		});
	}

	buildChrome();
	showLoading(true);
	fetch(playlistUrl, { method: 'GET', credentials: 'same-origin' })
		.then(function (res) { return res.json(); })
		.then(function (data) {
			if (data.error) {
				showError(data.error);
				return;
			}
			tracks = data.tracks || [];
			if (tracks.length === 0) {
				showError(data.error || 'No videos in this collection.');
				return;
			}
			showMain();
			buildPlaylist();
			playIndex(0, false);
		})
		.catch(function () {
			showError('Failed to load playlist.');
		});
})();
