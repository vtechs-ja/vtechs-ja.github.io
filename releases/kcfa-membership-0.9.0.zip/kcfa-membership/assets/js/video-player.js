/**
 * Ontrack video player: playlist from REST, Bunny or Vimeo embed iframe.
 *
 * @package Ontrack
 */

(function () {
	'use strict';

	var wrap = document.getElementById('ontrack-video-player-wrap');
	if (!wrap) return;

	var collectionId = wrap.getAttribute('data-collection-id');
	if (!collectionId) return;

	var restUrl = (typeof ontrackVideoPlayer !== 'undefined' && ontrackVideoPlayer.restUrl)
		? ontrackVideoPlayer.restUrl
		: '/wp-json/klac/v1';
	var playlistUrl = restUrl + '/video-collection/' + collectionId + '/playlist';

	var loadingEl = wrap.querySelector('.ontrack-video-player-loading');
	var mainEl = wrap.querySelector('.ontrack-video-player-main');
	var errorEl = wrap.querySelector('.ontrack-video-player-error');
	var iframeEl = wrap.querySelector('.ontrack-video-iframe');
	var nowPlayingEl = wrap.querySelector('.ontrack-video-now-playing');
	var playlistOl = wrap.querySelector('.ontrack-video-playlist');

	var tracks = [];

	function showLoading(show) {
		loadingEl.hidden = !show;
		if (show) {
			mainEl.setAttribute('hidden', '');
			errorEl.hidden = true;
		}
	}

	function showError(message) {
		loadingEl.hidden = true;
		mainEl.setAttribute('hidden', '');
		errorEl.hidden = false;
		errorEl.textContent = message || 'Failed to load playlist.';
	}

	function showMain() {
		loadingEl.hidden = true;
		errorEl.hidden = true;
		mainEl.removeAttribute('hidden');
	}

	function playIndex(index) {
		if (index < 0 || index >= tracks.length || !iframeEl) return;
		var t = tracks[index];
		iframeEl.src = t.embed_url + (t.embed_url.indexOf('?') >= 0 ? '&' : '?') + 'autoplay=1';
		iframeEl.setAttribute('title', t.title);
		nowPlayingEl.textContent = t.title;
		playlistOl.querySelectorAll('li').forEach(function (li, i) {
			li.classList.toggle('is-active', i === index);
		});
	}

	function buildPlaylist() {
		playlistOl.innerHTML = '';
		tracks.forEach(function (t, i) {
			var li = document.createElement('li');
			li.className = 'ontrack-video-playlist-item' + (i === 0 ? ' is-active' : '');
			var btn = document.createElement('button');
			btn.type = 'button';
			btn.className = 'ontrack-video-playlist-link';
			if (t.thumbnail_url) {
				var img = document.createElement('img');
				img.src = t.thumbnail_url;
				img.alt = '';
				img.className = 'ontrack-video-playlist-thumb';
				btn.appendChild(img);
			}
			var span = document.createElement('span');
			span.textContent = t.title;
			btn.appendChild(span);
			btn.addEventListener('click', function () {
				playIndex(i);
			});
			li.appendChild(btn);
			playlistOl.appendChild(li);
		});
	}

	showLoading(true);
	fetch(playlistUrl, { method: 'GET', credentials: 'same-origin' })
		.then(function (res) { return res.json(); })
		.then(function (data) {
			if (data.error) {
				showError(data.error);
				return;
			}
			tracks = data.tracks || [];
			if (tracks.length === 0) {
				showError(data.error || 'No videos in this collection.');
				return;
			}
			showMain();
			buildPlaylist();
			playIndex(0);
		})
		.catch(function () {
			showError('Failed to load playlist.');
		});
})();
