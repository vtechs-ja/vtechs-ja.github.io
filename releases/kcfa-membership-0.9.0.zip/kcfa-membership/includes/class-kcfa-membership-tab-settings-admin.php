<?php
/**
 * Admin meta box for "Mobile Tab Settings" on WordPress pages.
 *
 * Configures which content the mobile app pulls for each menu-driven tab:
 *   - Post feed driven by a category or tag
 *   - Post feed limit (1–20)
 *   - Which collection type to surface (audio / video / both / none)
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and renders the "Mobile Tab Settings" meta box on pages.
 */
class Ontrack_Tab_Settings_Admin {

	public static function init() {
		add_action( 'plugins_loaded', array( __CLASS__, 'boot' ), 20 );
	}

	public static function boot() {
		if ( ! is_admin() ) {
			return;
		}
		add_action( 'add_meta_boxes_page', array( __CLASS__, 'add_meta_box' ) );
		add_action( 'save_post_page', array( __CLASS__, 'save_post' ) );
	}

	public static function add_meta_box() {
		add_meta_box(
			'ontrack_tab_settings',
			__( 'Mobile Tab Settings', 'ontrack' ),
			array( __CLASS__, 'render' ),
			'page',
			'side',
			'default'
		);
	}

	/**
	 * @param WP_Post $post Post.
	 */
	public static function render( WP_Post $post ) {
		wp_nonce_field( 'ontrack_tab_settings_save', 'ontrack_tab_settings_nonce' );

		$category_id     = (int) get_post_meta( $post->ID, '_ontrack_tab_post_category_id', true );
		$tag_id          = (int) get_post_meta( $post->ID, '_ontrack_tab_post_tag_id', true );
		$post_limit      = (int) get_post_meta( $post->ID, '_ontrack_tab_post_limit', true ) ?: 10;
		$collection_type = get_post_meta( $post->ID, '_ontrack_tab_collection_type', true ) ?: 'none';

		$categories = get_categories( array( 'hide_empty' => false ) );
		$tags       = get_tags( array( 'hide_empty' => false ) );
		?>
		<p style="margin:0 0 0.25em;">
			<strong><?php esc_html_e( 'Post feed', 'ontrack' ); ?></strong>
		</p>
		<p class="description" style="margin-bottom:0.5em;">
			<?php esc_html_e( 'Show posts from a category or tag. Leave both empty for no post feed.', 'ontrack' ); ?>
		</p>

		<label for="ontrack_tab_post_category_id" style="display:block; margin-bottom:0.2em; font-weight:600;">
			<?php esc_html_e( 'Category', 'ontrack' ); ?>
		</label>
		<select name="ontrack_tab_post_category_id" id="ontrack_tab_post_category_id" style="max-width:100%; margin-bottom:0.5em;">
			<option value="0"><?php esc_html_e( '— none —', 'ontrack' ); ?></option>
			<?php foreach ( $categories as $cat ) : ?>
				<option value="<?php echo (int) $cat->term_id; ?>" <?php selected( $category_id, $cat->term_id ); ?>>
					<?php echo esc_html( $cat->name ); ?>
				</option>
			<?php endforeach; ?>
		</select>

		<label for="ontrack_tab_post_tag_id" style="display:block; margin-bottom:0.2em; font-weight:600;">
			<?php esc_html_e( 'Tag (if no category set)', 'ontrack' ); ?>
		</label>
		<select name="ontrack_tab_post_tag_id" id="ontrack_tab_post_tag_id" style="max-width:100%; margin-bottom:0.5em;">
			<option value="0"><?php esc_html_e( '— none —', 'ontrack' ); ?></option>
			<?php foreach ( $tags as $tag ) : ?>
				<option value="<?php echo (int) $tag->term_id; ?>" <?php selected( $tag_id, $tag->term_id ); ?>>
					<?php echo esc_html( $tag->name ); ?>
				</option>
			<?php endforeach; ?>
		</select>

		<label for="ontrack_tab_post_limit" style="display:block; margin-bottom:0.2em; font-weight:600;">
			<?php esc_html_e( 'Post limit', 'ontrack' ); ?>
		</label>
		<input type="number" name="ontrack_tab_post_limit" id="ontrack_tab_post_limit"
			value="<?php echo (int) $post_limit; ?>" min="1" max="20"
			style="width:60px; margin-bottom:0.75em;" />

		<hr style="margin:0.75em 0;" />

		<p style="margin:0 0 0.25em;">
			<strong><?php esc_html_e( 'Collections', 'ontrack' ); ?></strong>
		</p>
		<label for="ontrack_tab_collection_type" style="display:block; margin-bottom:0.2em; font-weight:600;">
			<?php esc_html_e( 'Show collections', 'ontrack' ); ?>
		</label>
		<select name="ontrack_tab_collection_type" id="ontrack_tab_collection_type" style="max-width:100%;">
			<?php
			foreach ( array(
				'none'  => __( 'None', 'ontrack' ),
				'audio' => __( 'Audio only', 'ontrack' ),
				'video' => __( 'Video only', 'ontrack' ),
				'both'  => __( 'Audio and Video', 'ontrack' ),
			) as $value => $label ) {
				printf(
					'<option value="%s"%s>%s</option>',
					esc_attr( $value ),
					selected( $collection_type, $value, false ),
					esc_html( $label )
				);
			}
			?>
		</select>
		<p class="description" style="margin-top:0.5em;">
			<?php esc_html_e( 'Access-permitted collections appear as cards in this tab. Icon hint for the tab bar: set the menu item Description to an Ionicon name (e.g. musical-notes, newspaper, people, play-circle).', 'ontrack' ); ?>
		</p>
		<?php
	}

	/**
	 * @param int $post_id Post ID.
	 */
	public static function save_post( $post_id ) {
		if ( ! isset( $_POST['ontrack_tab_settings_nonce'] ) ||
			! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ontrack_tab_settings_nonce'] ) ), 'ontrack_tab_settings_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$category_id = isset( $_POST['ontrack_tab_post_category_id'] ) ? absint( $_POST['ontrack_tab_post_category_id'] ) : 0;
		if ( $category_id > 0 ) {
			update_post_meta( $post_id, '_ontrack_tab_post_category_id', $category_id );
		} else {
			delete_post_meta( $post_id, '_ontrack_tab_post_category_id' );
		}

		$tag_id = isset( $_POST['ontrack_tab_post_tag_id'] ) ? absint( $_POST['ontrack_tab_post_tag_id'] ) : 0;
		if ( $tag_id > 0 ) {
			update_post_meta( $post_id, '_ontrack_tab_post_tag_id', $tag_id );
		} else {
			delete_post_meta( $post_id, '_ontrack_tab_post_tag_id' );
		}

		$limit = isset( $_POST['ontrack_tab_post_limit'] ) ? absint( $_POST['ontrack_tab_post_limit'] ) : 10;
		update_post_meta( $post_id, '_ontrack_tab_post_limit', max( 1, min( 20, $limit ) ) );

		$valid_types = array( 'none', 'audio', 'video', 'both' );
		$type        = isset( $_POST['ontrack_tab_collection_type'] ) ? sanitize_key( $_POST['ontrack_tab_collection_type'] ) : 'none';
		update_post_meta( $post_id, '_ontrack_tab_collection_type', in_array( $type, $valid_types, true ) ? $type : 'none' );
	}
}
