=== KCFA Membership ===
Contributors: kcfa
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 0.7.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Admin-assigned membership, demographic groups, and access control for KCFA catalogues and the mobile app API.

== Description ==

KCFA Membership provides:

* Four custom roles (KLAC Member, KLAC Leader, KLAC Community Leader, KLAC Admin) with a granular capability model.
* Coordinator designation — leaders can be assigned view-only access to specific groups without a role change.
* Group hierarchy — Growth Groups nest inside People Groups; access scope cascades through descendants.
* Audio metadata table — display name overrides and a "featured" flag for each Box file, synced via admin UI.
* Mobile authentication — custom JWT endpoints (`/wp-json/klac/v1/auth/*`) for the KLAC mobile app. No third-party auth plugin required.
* Catalogue access control — per-collection access levels (public / visitor / full member) enforced on REST endpoints and archive queries.

== Installation ==

1. Upload the `kcfa-membership` folder to `/wp-content/plugins/`.
2. Activate the plugin through the **Plugins** screen.
3. Go to **Settings → KCFA Membership** to review configuration.

That's it. The plugin generates a signing key for mobile authentication automatically on first activation — no manual setup required.

== Post-activation steps ==

After activating, visit **Settings → KCFA Membership** to confirm:

* **Mobile authentication** — the auto-generated signing key is shown with an 8-character fingerprint. No action needed unless you want to use a custom key.
* **Minimum role for member flag** — set the lowest role that may toggle the "full member" flag on user profiles.
* **Enforce collection access levels** — leave off until media collections have been configured and access levels set; then turn on before launch.

== Advanced: custom signing key (optional) ==

By default the plugin generates and stores a cryptographically strong signing key in the database on first activation. If you prefer to manage the key yourself (e.g. keep it out of the database, rotate it via deployment), add the following line to `wp-config.php`:

    define( 'KCFA_JWT_SECRET', 'your-long-random-string-at-least-32-characters' );

When the constant is present it takes precedence over the stored key, and the "Regenerate" button on the settings page is disabled. To generate a strong value:

    php -r "echo bin2hex(random_bytes(32)) . PHP_EOL;"

== REST API endpoints ==

All endpoints are under `/wp-json/klac/v1/`.

= Authentication =

* `POST /auth/token` — Exchange email + password for an access token and refresh token.
* `POST /auth/refresh` — Exchange a refresh token for a new token pair (rotates on each use).
* `GET /auth/me` — Returns the authenticated user's membership profile.
* `POST /auth/forgot-password` — Triggers a WordPress password reset email. Always returns 200.

Access tokens are short-lived (1 hour). Refresh tokens expire after 30 days. The mobile app should silently refresh using the refresh token before the access token expires.

= Media =

* `GET /audio-collection/{id}/playlist` — Playlist for a Box-backed audio collection.
* `GET /video-collection/{id}/playlist` — Playlist for a Bunny Stream or Vimeo video collection.
* `GET /stream/{file_id}` — Proxied audio stream from Box.

== Roles and capabilities ==

| Role | View roster | Edit members | Edit groups | Manage settings & media |
|---|---|---|---|---|
| KLAC Member | — | Own profile only | — | — |
| KLAC Leader | Group only | Group only | Group only | — |
| KLAC Community Leader | All | All | All | — |
| KLAC Admin | All | All | All | Yes |

Coordinators (set via user meta `kcfa_coordinator_group_ids`) get view-only access to specific groups on top of their assigned role.

== Changelog ==

= 0.7.0 =
* Added custom roles and capability model (klac_member, klac_leader, klac_community_leader, klac_admin).
* Added coordinator designation meta and scope resolution helpers.
* Added audio metadata custom DB table (kcfa_audio_metadata).
* Added JWT authentication endpoints (/auth/token, /auth/refresh, /auth/me, /auth/forgot-password).
* Auto-generated JWT signing key with settings-page regeneration and optional wp-config.php override.

= 0.6.0 =
* Initial plugin scaffold with settings page, group CPT, and catalogue access helpers.
