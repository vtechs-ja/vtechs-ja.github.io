<?php
/**
 * Plugin Name:       Ontrack
 * Plugin URI:        https://example.org/kcfa-membership
 * Description:       Membership management, access control, and media catalogue integration (Box, Bunny, Vimeo) for KCFA.
 * Version:           0.11.4
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            KCFA
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ontrack
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ONTRACK_VERSION', '0.11.4' );
define( 'ONTRACK_FILE', __FILE__ );
define( 'ONTRACK_PATH', plugin_dir_path( __FILE__ ) );
define( 'ONTRACK_URL', plugin_dir_url( __FILE__ ) );
define( 'ONTRACK_MEDIA_PATH', ONTRACK_PATH . 'includes/media/' );
define( 'ONTRACK_ASSETS_URL', ONTRACK_URL . 'assets/' );

// Update checker — vendor/ is included in deployed zips; absent in bare checkouts.
if ( file_exists( ONTRACK_PATH . 'vendor/autoload.php' ) ) {
	require_once ONTRACK_PATH . 'vendor/autoload.php';
	\YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
		'https://vtechs.com.jm/update-info/plugin.json',
		__FILE__,
		'kcfa-membership'
	);
}

// Media files — API integrations, REST endpoints, CPTs, admin UI, player assets.
require_once ONTRACK_PATH . 'includes/media/api/box-api.php';
require_once ONTRACK_PATH . 'includes/media/api/bunny-video-api.php';
require_once ONTRACK_PATH . 'includes/media/api/vimeo-video-api.php';
require_once ONTRACK_PATH . 'includes/media/rest.php';
require_once ONTRACK_PATH . 'includes/media/assets.php';
require_once ONTRACK_PATH . 'includes/media/template-loader.php';
require_once ONTRACK_PATH . 'includes/media/shortcodes.php';
if ( is_admin() ) {
	require_once ONTRACK_PATH . 'includes/media/admin/menu.php';
	require_once ONTRACK_PATH . 'includes/media/admin/settings.php';
	require_once ONTRACK_PATH . 'includes/media/admin/meta-boxes.php';
	require_once ONTRACK_PATH . 'includes/class-kcfa-membership-event-admin.php';
}

// Membership files — load roles first (defines constants used by other files).
require_once ONTRACK_PATH . 'includes/functions-roles.php';
require_once ONTRACK_PATH . 'includes/functions-post-types.php';
require_once ONTRACK_PATH . 'includes/functions-audio-metadata.php';
require_once ONTRACK_PATH . 'includes/functions-membership.php';
require_once ONTRACK_PATH . 'includes/functions-catalogue-access.php';
require_once ONTRACK_PATH . 'includes/functions-post-access.php';
require_once ONTRACK_PATH . 'includes/functions-demographics.php';
require_once ONTRACK_PATH . 'includes/functions-groups.php';
require_once ONTRACK_PATH . 'includes/functions-demographic-mismatch.php';
// Class files.
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-activator.php';
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-jwt.php';
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-rest-auth.php';
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-settings-admin.php';
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-user-admin.php';
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-demographics-admin.php';
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-group-post-type.php';
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-group-admin-meta.php';
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-user-groups-admin.php';
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-mismatch-admin.php';
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-management-menu.php';
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-coordinator-admin.php';
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-members-admin.php';
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-post-access-admin.php';
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-tab-settings-admin.php';
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-rest-mobile.php';
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-plugin.php';
require_once ONTRACK_PATH . 'includes/class-kcfa-membership-nav-filter.php';
Ontrack_Nav_Filter::init();
Ontrack_Post_Access_Admin::init();
Ontrack_Tab_Settings_Admin::init();

// WP-CLI commands — loaded only when running under WP-CLI.
if ( defined( 'WP_CLI' ) && WP_CLI ) {
	require_once ONTRACK_PATH . 'includes/class-kcfa-membership-cli.php';
}

register_activation_hook( ONTRACK_FILE, array( 'Ontrack_Activator', 'activate' ) );
register_deactivation_hook( ONTRACK_FILE, array( 'Ontrack_Activator', 'deactivate' ) );

/**
 * Returns the main plugin instance.
 *
 * @return Ontrack_Plugin
 */
function ontrack() {
	return Ontrack_Plugin::instance();
}

ontrack();
