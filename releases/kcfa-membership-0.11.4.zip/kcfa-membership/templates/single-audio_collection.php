<?php
/**
 * Plugin fallback template: single Audio Collection.
 *
 * Loaded only when the active theme does not supply single-audio_collection.php.
 * Provides a functional player with minimal presentational assumptions.
 *
 * @package Ontrack
 */

get_header();

while ( have_posts() ) :
	the_post();
	$collection_id = get_the_ID();
	?>
	<main id="primary" class="site-main">
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'ontrack-collection-article' ); ?>>

			<header class="entry-header">
				<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
			</header>

			<?php if ( has_post_thumbnail() ) : ?>
				<div class="ontrack-collection-thumbnail">
					<?php the_post_thumbnail( 'medium' ); ?>
				</div>
			<?php endif; ?>

			<?php if ( get_the_content() ) : ?>
				<div class="entry-content">
					<?php the_content(); ?>
				</div>
			<?php endif; ?>

			<div id="ontrack-audio-player-wrap" class="ontrack-audio-player-wrap"
				data-collection-id="<?php echo esc_attr( (string) $collection_id ); ?>">

				<div class="ontrack-audio-player-loading" aria-live="polite">
					<span class="ontrack-audio-loading-dot"></span>
					<?php esc_html_e( 'Loading playlist…', 'ontrack' ); ?>
				</div>

				<div class="ontrack-audio-player-container" hidden>

					<div class="ontrack-audio-header">
						<span class="ontrack-audio-header-icon" aria-hidden="true">
							<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M12 3v10.55A4 4 0 1 0 14 17V7h4V3h-6z"/></svg>
						</span>
						<span class="ontrack-audio-now-playing" aria-live="polite"></span>
					</div>

					<div class="ontrack-audio-controls">
						<button type="button" class="ontrack-audio-btn ontrack-audio-prev" aria-label="<?php esc_attr_e( 'Previous track', 'ontrack' ); ?>">
							<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M6 6h2v12H6zm3.5 6 8.5 6V6z"/></svg>
						</button>
						<button type="button" class="ontrack-audio-btn ontrack-audio-play ontrack-audio-play-main" aria-label="<?php esc_attr_e( 'Play', 'ontrack' ); ?>">
							<svg class="ontrack-icon-play" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="28" height="28"><path d="M8 5v14l11-7z"/></svg>
							<svg class="ontrack-icon-pause" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="28" height="28" style="display:none"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
						</button>
						<button type="button" class="ontrack-audio-btn ontrack-audio-next" aria-label="<?php esc_attr_e( 'Next track', 'ontrack' ); ?>">
							<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M6 18l8.5-6L6 6v12zm8.5-6 3.5 6V6l-3.5 6z"/><path d="M16 6h2v12h-2z"/></svg>
						</button>
					</div>

					<div class="ontrack-audio-progress-wrap">
						<span class="ontrack-audio-time-current">0:00</span>
						<div class="ontrack-audio-seek-wrap">
							<input type="range" class="ontrack-audio-seek" min="0" max="100" value="0" step="0.1"
								aria-label="<?php esc_attr_e( 'Seek', 'ontrack' ); ?>">
						</div>
						<span class="ontrack-audio-time-duration">0:00</span>
					</div>

					<audio class="ontrack-audio-element" preload="metadata"></audio>
					<ol class="ontrack-audio-playlist" aria-label="<?php esc_attr_e( 'Playlist', 'ontrack' ); ?>"></ol>
				</div>

				<div class="ontrack-audio-player-error" hidden aria-live="assertive"></div>
			</div>

		</article>
	</main>
	<?php
endwhile;

get_sidebar();
get_footer();
