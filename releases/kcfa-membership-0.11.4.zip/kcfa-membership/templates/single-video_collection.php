<?php
/**
 * Plugin fallback template: single Video Collection.
 *
 * Loaded only when the active theme does not supply single-video_collection.php.
 * Provides a functional player with minimal presentational assumptions.
 *
 * @package Ontrack
 */

get_header();

while ( have_posts() ) :
	the_post();
	$collection_id = get_the_ID();
	?>
	<main id="primary" class="site-main">
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'ontrack-collection-article' ); ?>>

			<header class="entry-header">
				<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
			</header>

			<?php if ( has_post_thumbnail() ) : ?>
				<div class="ontrack-collection-thumbnail">
					<?php the_post_thumbnail( 'medium' ); ?>
				</div>
			<?php endif; ?>

			<?php if ( get_the_content() ) : ?>
				<div class="entry-content">
					<?php the_content(); ?>
				</div>
			<?php endif; ?>

			<div id="ontrack-video-player-wrap" class="ontrack-video-player-wrap"
				data-collection-id="<?php echo esc_attr( (string) $collection_id ); ?>">

				<div class="ontrack-video-player-loading" aria-live="polite">
					<span class="ontrack-audio-loading-dot"></span>
					<?php esc_html_e( 'Loading playlist…', 'ontrack' ); ?>
				</div>

				<div class="ontrack-video-player-main" hidden>
					<div class="ontrack-video-embed-wrap">
						<iframe class="ontrack-video-iframe" title=""
							allow="accelerometer; gyroscope; autoplay; encrypted-media; picture-in-picture;"
							allowfullscreen loading="lazy"></iframe>
					</div>
					<p class="ontrack-video-now-playing" aria-live="polite"></p>
					<ol class="ontrack-video-playlist" aria-label="<?php esc_attr_e( 'Playlist', 'ontrack' ); ?>"></ol>
				</div>

				<div class="ontrack-video-player-error" hidden aria-live="assertive"></div>
			</div>

		</article>
	</main>
	<?php
endwhile;

get_sidebar();
get_footer();
