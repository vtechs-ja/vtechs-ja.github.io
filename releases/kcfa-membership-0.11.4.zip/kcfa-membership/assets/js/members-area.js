/**
 * Members Area: configurable countdown timer.
 *
 * Config is passed via wp_localize_script as ontrackMembersArea.countdown:
 *   mode   — 'weekly' | 'once'
 *   day    — 0–6 (0=Sunday), used when mode='weekly'
 *   hour   — 0–23
 *   minute — 0–59
 *   rest   — hours after target to show "in progress" (default 3)
 *   date   — ISO datetime string (YYYY-MM-DDTHH:MM), used when mode='once'
 *
 * @package Ontrack
 */

( function () {
	'use strict';

	var countdown = document.getElementById( 'ontrack-countdown' );
	if ( ! countdown ) return;

	var cfg = ( typeof ontrackMembersArea !== 'undefined' && ontrackMembersArea.countdown )
		? ontrackMembersArea.countdown
		: { mode: 'weekly', day: 0, hour: 9, minute: 0, rest: 3, date: '' };

	var mode   = cfg.mode   || 'weekly';
	var day    = parseInt( cfg.day,    10 ) || 0;
	var hour   = parseInt( cfg.hour,   10 ) || 0;
	var minute = parseInt( cfg.minute, 10 ) || 0;
	var rest   = parseInt( cfg.rest,   10 );
	if ( isNaN( rest ) ) rest = 3;

	var labelEl      = countdown.querySelector( '.ontrack-countdown__label' );
	var gridEl       = document.getElementById( 'ontrack-countdown-grid' );
	var daysEl       = document.getElementById( 'ontrack-countdown-days' );
	var hoursEl      = document.getElementById( 'ontrack-countdown-hours' );
	var minutesEl    = document.getElementById( 'ontrack-countdown-minutes' );
	var secondsEl    = document.getElementById( 'ontrack-countdown-seconds' );
	var inProgressEl = document.getElementById( 'ontrack-countdown-inprogress' );

	function pad( n ) {
		return n < 10 ? '0' + n : String( n );
	}

	function getNextWeeklyTarget( now ) {
		var target = new Date( now );
		target.setHours( hour, minute, 0, 0 );
		var diff = day - target.getDay();
		if ( diff < 0 ) diff += 7;
		if ( diff === 0 && now >= target ) diff = 7;
		target.setDate( target.getDate() + diff );
		return target;
	}

	function getOnceTarget() {
		return cfg.date ? new Date( cfg.date ) : null;
	}

	function tick() {
		var now    = new Date();
		var target, inProgress;

		if ( mode === 'once' ) {
			target = getOnceTarget();
			if ( ! target || isNaN( target.getTime() ) ) return;
			var msAfter = now - target;
			inProgress = msAfter >= 0 && msAfter < rest * 3600 * 1000;
		} else {
			target = getNextWeeklyTarget( now );
			// Check whether we're inside a rest window following the previous occurrence.
			var prevTarget = new Date( target );
			prevTarget.setDate( prevTarget.getDate() - 7 );
			var msAfterPrev = now - prevTarget;
			inProgress = msAfterPrev >= 0 && msAfterPrev < rest * 3600 * 1000;
		}

		if ( inProgress ) {
			labelEl.hidden      = true;
			gridEl.hidden       = true;
			inProgressEl.hidden = false;
			return;
		}

		// For a past one-time target outside the rest window, nothing more to show.
		if ( mode === 'once' && now > target ) {
			countdown.hidden = true;
			return;
		}

		labelEl.hidden      = false;
		gridEl.hidden       = false;
		inProgressEl.hidden = true;

		var diff         = Math.max( 0, target - now );
		var totalSeconds = Math.floor( diff / 1000 );
		var d            = Math.floor( totalSeconds / 86400 );
		var h            = Math.floor( ( totalSeconds % 86400 ) / 3600 );
		var m            = Math.floor( ( totalSeconds % 3600 ) / 60 );
		var s            = totalSeconds % 60;

		daysEl.textContent    = pad( d );
		hoursEl.textContent   = pad( h );
		minutesEl.textContent = pad( m );
		secondsEl.textContent = pad( s );
	}

	tick();
	setInterval( tick, 1000 );
} )();
