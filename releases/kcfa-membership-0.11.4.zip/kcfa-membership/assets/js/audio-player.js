/**
 * Ontrack audio player: fetches playlist from REST and builds HTML5 player with playlist.
 *
 * @package Ontrack
 */

(function () {
	'use strict';

	var wrap = document.getElementById('ontrack-audio-player-wrap');
	if (!wrap) return;

	var collectionId = wrap.getAttribute('data-collection-id');
	if (!collectionId) return;

	var restUrl = typeof ontrackAudioPlayer !== 'undefined' && ontrackAudioPlayer.restUrl
		? ontrackAudioPlayer.restUrl
		: (window.wp && window.wp.apiRoot ? window.wp.apiRoot : '/wp-json') + '/klac/v1';
	var playlistUrl = restUrl + '/audio-collection/' + collectionId + '/playlist';

	var loadingEl = wrap.querySelector('.ontrack-audio-player-loading');
	var containerEl = wrap.querySelector('.ontrack-audio-player-container');
	var errorEl = wrap.querySelector('.ontrack-audio-player-error');
	var audioEl = wrap.querySelector('.ontrack-audio-element');
	var playlistOl = wrap.querySelector('.ontrack-audio-playlist');
	var nowPlayingSpan = wrap.querySelector('.ontrack-audio-now-playing');
	var playBtn = wrap.querySelector('.ontrack-audio-play');
	var prevBtn = wrap.querySelector('.ontrack-audio-prev');
	var nextBtn = wrap.querySelector('.ontrack-audio-next');
	var seekInput = wrap.querySelector('.ontrack-audio-seek');
	var timeCurrentSpan = wrap.querySelector('.ontrack-audio-time-current');
	var timeDurationSpan = wrap.querySelector('.ontrack-audio-time-duration');

	var tracks = [];
	var currentIndex = 0;

	function showLoading(show) {
		loadingEl.hidden = !show;
		if (show) {
			containerEl.setAttribute('hidden', '');
			errorEl.hidden = true;
		}
	}

	function showError(message) {
		loadingEl.hidden = true;
		containerEl.setAttribute('hidden', '');
		errorEl.hidden = false;
		errorEl.textContent = message || 'Failed to load playlist.';
	}

	function showPlayer() {
		loadingEl.hidden = true;
		errorEl.hidden = true;
		containerEl.removeAttribute('hidden');
	}

	function formatTime(seconds) {
		if (!isFinite(seconds) || isNaN(seconds)) return '0:00';
		var m = Math.floor(seconds / 60);
		var s = Math.floor(seconds % 60);
		return m + ':' + (s < 10 ? '0' : '') + s;
	}

	function setPlayingState(isPlaying) {
		var iconPlay = playBtn.querySelector('.ontrack-icon-play');
		var iconPause = playBtn.querySelector('.ontrack-icon-pause');
		if (iconPlay) iconPlay.style.display = isPlaying ? 'none' : '';
		if (iconPause) iconPause.style.display = isPlaying ? '' : 'none';
		playBtn.setAttribute('aria-label', isPlaying ? 'Pause' : 'Play');
	}

	function setTrack(index) {
		if (index < 0 || index >= tracks.length) return;
		currentIndex = index;
		var t = tracks[index];
		audioEl.src = t.url;
		nowPlayingSpan.textContent = t.name;
		playlistOl.querySelectorAll('li').forEach(function (li, i) {
			li.classList.toggle('is-active', i === index);
		});
		audioEl.load();
		seekInput.value = 0;
		timeCurrentSpan.textContent = '0:00';
		timeDurationSpan.textContent = '0:00';
	}

	function play() {
		if (tracks.length === 0) return;
		audioEl.play().catch(function () {});
	}

	function pause() {
		audioEl.pause();
	}

	function togglePlay() {
		if (audioEl.paused) play(); else pause();
	}

	function prev() {
		if (currentIndex > 0) {
			setTrack(currentIndex - 1);
			play();
		}
	}

	function next() {
		if (currentIndex < tracks.length - 1) {
			setTrack(currentIndex + 1);
			play();
		} else {
			pause();
			audioEl.currentTime = 0;
		}
	}

	function updateTime() {
		var current = audioEl.currentTime;
		var duration = audioEl.duration;
		if (!isFinite(duration)) duration = 0;
		timeCurrentSpan.textContent = formatTime(current);
		timeDurationSpan.textContent = formatTime(duration);
		var pct = duration > 0 ? (current / duration) * 100 : 0;
		seekInput.value = pct;
	}

	function seek() {
		var pct = parseFloat(seekInput.value, 10);
		var duration = audioEl.duration;
		if (isFinite(duration)) audioEl.currentTime = (pct / 100) * duration;
	}

	function buildPlaylistList() {
		playlistOl.innerHTML = '';
		tracks.forEach(function (t, i) {
			var li = document.createElement('li');
			li.className = 'ontrack-audio-playlist-item' + (i === 0 ? ' is-active' : '');
			var btn = document.createElement('button');
			btn.type = 'button';
			btn.className = 'ontrack-audio-playlist-link';
			btn.textContent = t.name;
			btn.addEventListener('click', function () {
				setTrack(i);
				play();
			});
			li.appendChild(btn);
			playlistOl.appendChild(li);
		});
	}

	// Events
	audioEl.addEventListener('play', function () { setPlayingState(true); });
	audioEl.addEventListener('pause', function () { setPlayingState(false); });
	audioEl.addEventListener('timeupdate', updateTime);
	audioEl.addEventListener('durationchange', updateTime);
	audioEl.addEventListener('ended', next);
	playBtn.addEventListener('click', togglePlay);
	prevBtn.addEventListener('click', prev);
	nextBtn.addEventListener('click', next);
	seekInput.addEventListener('input', seek);

	// Fetch playlist
	showLoading(true);
	fetch(playlistUrl, { method: 'GET', credentials: 'same-origin' })
		.then(function (res) { return res.json(); })
		.then(function (data) {
			if (data.error) {
				showError(data.error);
				return;
			}
			tracks = data.tracks || [];
			if (tracks.length === 0) {
				showError(data.error || 'No audio files in this collection.');
				return;
			}
			showPlayer();
			buildPlaylistList();
			setTrack(0);
		})
		.catch(function () {
			showError('Failed to load playlist.');
		});
})();
