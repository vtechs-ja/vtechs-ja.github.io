<?php
/**
 * Audio file metadata storage (Box file IDs → curation data).
 *
 * Box is the source of truth for file existence; this table stores only
 * display name overrides and the featured flag used for mobile auto-download.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Full table name including WP table prefix.
 *
 * @return string
 */
function ontrack_audio_metadata_table() {
	global $wpdb;
	return $wpdb->prefix . 'kcfa_audio_metadata';
}

/**
 * Create or upgrade the audio metadata table via dbDelta.
 * Called on plugin activation; idempotent.
 */
function ontrack_audio_metadata_create_table() {
	global $wpdb;
	$table           = ontrack_audio_metadata_table();
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE {$table} (
		box_file_id   varchar(255)        NOT NULL,
		collection_id bigint(20) unsigned NOT NULL,
		display_name  varchar(500)        DEFAULT NULL,
		featured      tinyint(1)          NOT NULL DEFAULT 0,
		PRIMARY KEY  (box_file_id),
		KEY collection_id (collection_id),
		KEY featured (featured)
	) {$charset_collate};";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql );
}

/**
 * All metadata rows for a collection, keyed by box_file_id.
 *
 * @param int $collection_id audio_collection post ID.
 * @return array<string, array{ box_file_id: string, display_name: string|null, featured: bool }>
 */
function ontrack_audio_metadata_get_for_collection( $collection_id ) {
	global $wpdb;
	$collection_id = (int) $collection_id;
	if ( $collection_id <= 0 ) {
		return array();
	}

	$table = ontrack_audio_metadata_table();
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$rows = $wpdb->get_results(
		$wpdb->prepare(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"SELECT box_file_id, display_name, featured FROM {$table} WHERE collection_id = %d",
			$collection_id
		),
		ARRAY_A
	);

	if ( ! $rows ) {
		return array();
	}

	$keyed = array();
	foreach ( $rows as $row ) {
		$keyed[ $row['box_file_id'] ] = array(
			'box_file_id'  => $row['box_file_id'],
			'display_name' => $row['display_name'],
			'featured'     => (bool) $row['featured'],
		);
	}
	return $keyed;
}

/**
 * All featured audio rows across all collections.
 * Used by the mobile auto-download REST endpoint.
 *
 * @return array<array{ box_file_id: string, collection_id: int, display_name: string|null }>
 */
function ontrack_audio_metadata_get_featured() {
	global $wpdb;

	$table = ontrack_audio_metadata_table();
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$rows = $wpdb->get_results(
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		"SELECT box_file_id, collection_id, display_name FROM {$table} WHERE featured = 1",
		ARRAY_A
	);

	if ( ! $rows ) {
		return array();
	}

	return array_map( function ( $row ) {
		return array(
			'box_file_id'   => $row['box_file_id'],
			'collection_id' => (int) $row['collection_id'],
			'display_name'  => $row['display_name'],
		);
	}, $rows );
}

/**
 * Insert or update a metadata row.
 *
 * @param string      $box_file_id   Box file ID.
 * @param int         $collection_id audio_collection post ID.
 * @param string|null $display_name  Display name override; null uses the Box filename.
 * @param bool        $featured      Featured for mobile auto-download.
 * @return bool True on success.
 */
function ontrack_audio_metadata_upsert( $box_file_id, $collection_id, $display_name, $featured ) {
	global $wpdb;

	$box_file_id   = sanitize_text_field( (string) $box_file_id );
	$collection_id = (int) $collection_id;
	$display_name  = ( null === $display_name || '' === $display_name )
		? null
		: sanitize_text_field( substr( (string) $display_name, 0, 500 ) );
	$featured      = $featured ? 1 : 0;

	if ( '' === $box_file_id || $collection_id <= 0 ) {
		return false;
	}

	$table = ontrack_audio_metadata_table();
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$result = $wpdb->query(
		$wpdb->prepare(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"INSERT INTO {$table} (box_file_id, collection_id, display_name, featured)
			 VALUES (%s, %d, %s, %d)
			 ON DUPLICATE KEY UPDATE
			   collection_id = VALUES(collection_id),
			   display_name  = VALUES(display_name),
			   featured      = VALUES(featured)",
			$box_file_id,
			$collection_id,
			$display_name,
			$featured
		)
	);

	return false !== $result;
}

/**
 * Delete rows for a collection whose file ID is no longer present in Box.
 * Call this after a sync to prune stale entries.
 * Skips deletion if $current_file_ids is empty to guard against accidental wipe on API error.
 *
 * @param int      $collection_id    audio_collection post ID.
 * @param string[] $current_file_ids File IDs currently present in the Box folder.
 * @return int Number of rows deleted.
 */
function ontrack_audio_metadata_delete_stale( $collection_id, array $current_file_ids ) {
	global $wpdb;

	$collection_id = (int) $collection_id;
	if ( $collection_id <= 0 || empty( $current_file_ids ) ) {
		return 0;
	}

	$current_file_ids = array_values(
		array_filter( array_map( 'sanitize_text_field', $current_file_ids ) )
	);
	if ( empty( $current_file_ids ) ) {
		return 0;
	}

	$placeholders = implode( ', ', array_fill( 0, count( $current_file_ids ), '%s' ) );
	$table        = ontrack_audio_metadata_table();

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$deleted = $wpdb->query(
		$wpdb->prepare(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"DELETE FROM {$table} WHERE collection_id = %d AND box_file_id NOT IN ({$placeholders})",
			array_merge( array( $collection_id ), $current_file_ids )
		)
	);

	return (int) $deleted;
}
