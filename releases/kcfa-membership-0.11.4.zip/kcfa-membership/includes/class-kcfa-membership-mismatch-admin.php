<?php
/**
 * User profile: demographic mismatch list and acknowledgments.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mismatch UI on user edit screen.
 */
class Ontrack_Mismatch_Admin {

	const NONCE_ACTION = 'ontrack_mismatch_ack';

	const NONCE_FIELD  = 'ontrack_mismatch_ack_nonce';

	/**
	 * Register hooks.
	 */
	public function register() {
		add_action( 'show_user_profile', array( $this, 'render_section' ), 20 );
		add_action( 'edit_user_profile', array( $this, 'render_section' ), 20 );
		add_action( 'personal_options_update', array( $this, 'save_acks' ) );
		add_action( 'edit_user_profile_update', array( $this, 'save_acks' ) );
	}

	/**
	 * Output mismatch list and per-group ack forms.
	 *
	 * @param WP_User $user User.
	 */
	public function render_section( $user ) {
		if ( ! $user instanceof WP_User ) {
			return;
		}
		if ( ! current_user_can( 'edit_user', $user->ID ) ) {
			return;
		}

		$items = ontrack_get_demographic_mismatches_for_user( $user->ID );
		$can_ack = ontrack_current_user_can_manage_user_groups( $user->ID );

		?>
		<h2 id="ontrack-mismatch-heading"><?php esc_html_e( 'Demographic mismatches', 'ontrack' ); ?></h2>
		<p class="description" id="ontrack-mismatch-desc">
			<?php esc_html_e( 'Compared to each assigned group’s effective demographic rule (age and gender). Acknowledgments are for intentional exceptions.', 'ontrack' ); ?>
		</p>
		<?php if ( empty( $items ) ) : ?>
			<p class="ontrack-mismatch-none" aria-labelledby="ontrack-mismatch-heading" aria-describedby="ontrack-mismatch-desc"><?php esc_html_e( 'No conflicts with assigned groups.', 'ontrack' ); ?></p>
		<?php else : ?>
			<table class="widefat striped" style="max-width: 52em;" aria-labelledby="ontrack-mismatch-heading" aria-describedby="ontrack-mismatch-desc">
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Group', 'ontrack' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Details', 'ontrack' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Status', 'ontrack' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $items as $row ) : ?>
						<tr>
							<td>
								<strong><?php echo esc_html( $row['group_title'] ); ?></strong>
								<div class="row-actions">
									<a href="<?php echo esc_url( admin_url( 'admin.php?page=kcfa-management-assign&group_id=' . (int) $row['group_id'] ) ); ?>"><?php esc_html_e( 'Roster', 'ontrack' ); ?></a>
								</div>
							</td>
							<td>
								<ul style="margin:0 0 0 1.2em;">
									<?php foreach ( $row['reasons'] as $reason ) : ?>
										<li><?php echo esc_html( $reason ); ?></li>
									<?php endforeach; ?>
								</ul>
								<?php if ( ! empty( $row['acknowledged'] ) && '' !== $row['ack_note'] ) : ?>
									<p class="description"><?php esc_html_e( 'Note:', 'ontrack' ); ?> <?php echo esc_html( $row['ack_note'] ); ?></p>
								<?php endif; ?>
							</td>
							<td>
								<?php if ( ! empty( $row['acknowledged'] ) ) : ?>
									<span class="ontrack-mismatch-badge"><?php esc_html_e( 'Acknowledged', 'ontrack' ); ?></span>
									<?php if ( $can_ack ) : ?>
										<form method="post" action="" style="margin-top:8px;">
											<?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_FIELD ); ?>
											<input type="hidden" name="ontrack_mismatch_ack_group_id" value="<?php echo esc_attr( (string) $row['group_id'] ); ?>" />
											<?php
											submit_button(
												__( 'Revoke acknowledgment', 'ontrack' ),
												'delete small',
												'ontrack_mismatch_ack_clear_submit',
												false,
												array(
													'onclick' => 'return confirm("' . esc_js( __( 'Remove acknowledgment for this group?', 'ontrack' ) ) . '");',
												)
											);
											?>
										</form>
									<?php endif; ?>
								<?php elseif ( $can_ack ) : ?>
									<form method="post" action="" class="ontrack-mismatch-ack-form">
										<?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_FIELD ); ?>
										<input type="hidden" name="ontrack_mismatch_ack_group_id" value="<?php echo esc_attr( (string) $row['group_id'] ); ?>" />
										<p>
											<label for="ontrack_ack_note_<?php echo esc_attr( (string) $row['group_id'] ); ?>" class="screen-reader-text"><?php esc_html_e( 'Note (optional)', 'ontrack' ); ?></label>
											<textarea name="ontrack_mismatch_ack_note" id="ontrack_ack_note_<?php echo esc_attr( (string) $row['group_id'] ); ?>" rows="2" cols="28" placeholder="<?php esc_attr_e( 'Optional note…', 'ontrack' ); ?>"></textarea>
										</p>
										<?php submit_button( __( 'Acknowledge', 'ontrack' ), 'secondary small', 'ontrack_mismatch_ack_add_submit', false ); ?>
									</form>
								<?php else : ?>
									<span class="description"><?php esc_html_e( 'Not acknowledged', 'ontrack' ); ?></span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		<?php
	}

	/**
	 * Save acknowledgment add/clear from profile forms.
	 *
	 * @param int $user_id User ID.
	 */
	public function save_acks( $user_id ) {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 ) {
			return;
		}
		if ( ! isset( $_POST[ self::NONCE_FIELD ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE_FIELD ] ) ), self::NONCE_ACTION ) ) {
			return;
		}
		if ( ! ontrack_current_user_can_manage_user_groups( $user_id ) ) {
			return;
		}

		$gid = isset( $_POST['ontrack_mismatch_ack_group_id'] ) ? (int) $_POST['ontrack_mismatch_ack_group_id'] : 0;
		if ( $gid <= 0 ) {
			return;
		}

		if ( ! empty( $_POST['ontrack_mismatch_ack_add_submit'] ) ) {
			$note = isset( $_POST['ontrack_mismatch_ack_note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ontrack_mismatch_ack_note'] ) ) : '';
			ontrack_set_mismatch_ack( $user_id, $gid, $note );
			return;
		}

		if ( ! empty( $_POST['ontrack_mismatch_ack_clear_submit'] ) ) {
			ontrack_clear_mismatch_ack( $user_id, $gid );
		}
	}
}
