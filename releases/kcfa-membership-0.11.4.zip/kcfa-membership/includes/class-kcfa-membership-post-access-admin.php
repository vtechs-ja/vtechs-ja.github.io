<?php
/**
 * Admin meta box for post-level group restriction and mobile feed pinning.
 *
 * Appears on the standard post edit screen. Uses the same _klac_allowed_group_ids
 * meta key as collections for a consistent access control model.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and renders the "Mobile Access" meta box on posts.
 */
class Ontrack_Post_Access_Admin {

	public static function init() {
		add_action( 'plugins_loaded', array( __CLASS__, 'boot' ), 20 );
	}

	public static function boot() {
		if ( ! is_admin() ) {
			return;
		}
		add_action( 'add_meta_boxes_post', array( __CLASS__, 'add_meta_box' ) );
		add_action( 'save_post_post', array( __CLASS__, 'save_post' ) );
	}

	public static function add_meta_box() {
		add_meta_box(
			'ontrack_post_mobile_access',
			__( 'Mobile Access', 'ontrack' ),
			array( __CLASS__, 'render' ),
			'post',
			'side',
			'default'
		);
	}

	/**
	 * @param WP_Post $post Post.
	 */
	public static function render( WP_Post $post ) {
		wp_nonce_field( 'ontrack_post_mobile_access_save', 'ontrack_post_mobile_access_nonce' );

		$pinned         = (bool) get_post_meta( $post->ID, '_ontrack_pinned', true );
		$allowed_groups = ontrack_get_collection_allowed_group_ids( $post->ID );
		$all_groups     = get_posts( array(
			'post_type'      => ontrack_group_post_type(),
			'posts_per_page' => -1,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'post_status'    => 'publish',
			'no_found_rows'  => true,
		) );
		?>
		<p>
			<label>
				<input type="checkbox" name="ontrack_post_pinned" value="1" <?php checked( $pinned ); ?> />
				<?php esc_html_e( 'Pin to top of mobile feed', 'ontrack' ); ?>
			</label>
		</p>
		<p class="description">
			<?php esc_html_e( 'Pinned posts appear above newest-first posts in the mobile app feed.', 'ontrack' ); ?>
		</p>

		<?php if ( ! empty( $all_groups ) ) : ?>
		<hr style="margin:1em 0;" />
		<p style="margin:0 0 0.25em;"><strong><?php esc_html_e( 'Restrict to groups (optional)', 'ontrack' ); ?></strong></p>
		<p class="description" style="margin-bottom:0.5em;">
			<?php esc_html_e( 'Leave all unchecked to allow any full member. Check groups to limit access to only those members.', 'ontrack' ); ?>
		</p>
		<?php foreach ( $all_groups as $group ) : ?>
			<label style="display:block; margin-bottom:0.2em;">
				<input type="checkbox" name="ontrack_post_allowed_group_ids[]" value="<?php echo (int) $group->ID; ?>"
					<?php checked( in_array( (int) $group->ID, $allowed_groups, true ) ); ?> />
				<?php echo esc_html( $group->post_title ); ?>
			</label>
		<?php endforeach; ?>
		<?php endif; ?>

		<p class="description" style="margin-top:0.75em;">
			<?php esc_html_e( 'Group restrictions apply when REST enforcement is enabled in KCFA Membership → Settings.', 'ontrack' ); ?>
		</p>
		<?php
	}

	/**
	 * @param int $post_id Post ID.
	 */
	public static function save_post( $post_id ) {
		if ( ! isset( $_POST['ontrack_post_mobile_access_nonce'] ) ||
			! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ontrack_post_mobile_access_nonce'] ) ), 'ontrack_post_mobile_access_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$pinned = isset( $_POST['ontrack_post_pinned'] ) && '1' === $_POST['ontrack_post_pinned'];
		if ( $pinned ) {
			update_post_meta( $post_id, '_ontrack_pinned', true );
		} else {
			delete_post_meta( $post_id, '_ontrack_pinned' );
		}

		if ( isset( $_POST['ontrack_post_allowed_group_ids'] ) && is_array( $_POST['ontrack_post_allowed_group_ids'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$group_ids = array_values( array_filter( array_map( 'intval', wp_unslash( $_POST['ontrack_post_allowed_group_ids'] ) ) ) );
			if ( ! empty( $group_ids ) ) {
				update_post_meta( $post_id, '_ontrack_allowed_group_ids', $group_ids );
			} else {
				delete_post_meta( $post_id, '_ontrack_allowed_group_ids' );
			}
		} else {
			delete_post_meta( $post_id, '_ontrack_allowed_group_ids' );
		}
	}
}
