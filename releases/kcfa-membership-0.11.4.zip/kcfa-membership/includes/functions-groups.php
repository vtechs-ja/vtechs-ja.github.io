<?php
/**
 * Group CPT helpers: IDs, hierarchy, demographics merge.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Group custom post type slug.
 *
 * @return string
 */
function ontrack_group_post_type() {
	return 'kcfa_group';
}

/**
 * Parent admin menu slug for KCFA Management (Groups + tools).
 *
 * @return string
 */
function ontrack_management_menu_slug() {
	return 'kcfa-management';
}

/**
 * Post meta: demographic rule fragment for this group node (JSON-able array).
 *
 * @return string
 */
function ontrack_group_demographics_meta_key() {
	return 'ontrack_group_demographics';
}

/**
 * User meta: assigned group post IDs (array of ints).
 *
 * @return string
 */
function ontrack_user_group_ids_meta_key() {
	return 'ontrack_user_group_ids';
}

/**
 * Whether a capability string belongs to the group CPT (after WP mapping).
 *
 * @param string $cap Capability.
 * @return bool
 */
function ontrack_is_group_post_type_cap( $cap ) {
	return is_string( $cap ) && false !== strpos( $cap, 'kcfa_group' );
}

/**
 * Default empty demographics fragment.
 *
 * @return array{age_min: ?int, age_max: ?int, gender: string}
 */
function ontrack_demographics_empty() {
	return array(
		'age_min' => null,
		'age_max' => null,
		'gender'  => '',
	);
}

/**
 * Sanitize stored demographics array from meta.
 *
 * @param mixed $raw Meta value.
 * @return array{age_min: ?int, age_max: ?int, gender: string}
 */
function ontrack_sanitize_demographics_fragment( $raw ) {
	$out = ontrack_demographics_empty();
	if ( ! is_array( $raw ) ) {
		return $out;
	}
	if ( isset( $raw['age_min'] ) && '' !== $raw['age_min'] && null !== $raw['age_min'] ) {
		$out['age_min'] = max( 0, min( 150, (int) $raw['age_min'] ) );
	}
	if ( isset( $raw['age_max'] ) && '' !== $raw['age_max'] && null !== $raw['age_max'] ) {
		$out['age_max'] = max( 0, min( 150, (int) $raw['age_max'] ) );
	}
	if ( null !== $out['age_min'] && null !== $out['age_max'] && $out['age_max'] < $out['age_min'] ) {
		$out['age_max'] = $out['age_min'];
	}
	if ( ! empty( $raw['gender'] ) ) {
		$g = sanitize_key( (string) $raw['gender'] );
		if ( 'male' === $g || 'female' === $g ) {
			$out['gender'] = $g;
		}
	}
	return $out;
}

/**
 * Get demographics fragment stored on a group post (not merged).
 *
 * @param int $group_post_id Group post ID.
 * @return array{age_min: ?int, age_max: ?int, gender: string}
 */
function ontrack_get_group_own_demographics( $group_post_id ) {
	$group_post_id = (int) $group_post_id;
	if ( $group_post_id <= 0 ) {
		return ontrack_demographics_empty();
	}
	$raw = get_post_meta( $group_post_id, ontrack_group_demographics_meta_key(), true );
	if ( is_string( $raw ) ) {
		$decoded = json_decode( $raw, true );
		$raw     = is_array( $decoded ) ? $decoded : array();
	}
	return ontrack_sanitize_demographics_fragment( $raw );
}

/**
 * Ordered ancestor chain from root to self (includes self). Empty if invalid post.
 *
 * @param int $group_post_id Group post ID.
 * @return int[] Post IDs.
 */
function ontrack_get_group_ancestor_chain_root_to_self( $group_post_id ) {
	$group_post_id = (int) $group_post_id;
	if ( $group_post_id <= 0 || ontrack_group_post_type() !== get_post_type( $group_post_id ) ) {
		return array();
	}
	$chain = array();
	$seen  = array();
	$cur   = $group_post_id;
	while ( $cur > 0 && ! isset( $seen[ $cur ] ) ) {
		$seen[ $cur ] = true;
		array_unshift( $chain, $cur );
		$p = (int) get_post_field( 'post_parent', $cur );
		if ( $p && ontrack_group_post_type() === get_post_type( $p ) ) {
			$cur = $p;
		} else {
			break;
		}
	}
	return $chain;
}

/**
 * Merge demographics root → target: intersect age bounds; gender = first explicit along chain (children must match on save).
 *
 * @param int $group_post_id Target group.
 * @return array{age_min: ?int, age_max: ?int, gender: string}
 */
function ontrack_get_effective_group_demographics( $group_post_id ) {
	$chain = ontrack_get_group_ancestor_chain_root_to_self( $group_post_id );
	if ( empty( $chain ) ) {
		return ontrack_demographics_empty();
	}
	$eff = ontrack_demographics_empty();
	foreach ( $chain as $gid ) {
		$own = ontrack_get_group_own_demographics( $gid );
		if ( null !== $own['age_min'] ) {
			$eff['age_min'] = null === $eff['age_min'] ? $own['age_min'] : max( $eff['age_min'], $own['age_min'] );
		}
		if ( null !== $own['age_max'] ) {
			$eff['age_max'] = null === $eff['age_max'] ? $own['age_max'] : min( $eff['age_max'], $own['age_max'] );
		}
		if ( '' !== $own['gender'] && '' === $eff['gender'] ) {
			$eff['gender'] = $own['gender'];
		}
	}
	if ( null !== $eff['age_min'] && null !== $eff['age_max'] && $eff['age_max'] < $eff['age_min'] ) {
		$eff['age_max'] = $eff['age_min'];
	}
	return $eff;
}

/**
 * Sanitize list of group post IDs (published groups only).
 *
 * @param mixed $raw Array or comma list.
 * @return int[]
 */
function ontrack_sanitize_user_group_ids( $raw ) {
	if ( is_string( $raw ) ) {
		$raw = explode( ',', $raw );
	}
	if ( ! is_array( $raw ) ) {
		return array();
	}
	$out = array();
	foreach ( $raw as $id ) {
		$id = (int) $id;
		if ( $id <= 0 ) {
			continue;
		}
		$p = get_post( $id );
		if ( $p && ontrack_group_post_type() === $p->post_type && 'publish' === $p->post_status ) {
			$out[] = $id;
		}
	}
	return array_values( array_unique( $out ) );
}

/**
 * Assigned group IDs for a user (direct assignments only).
 *
 * @param int|null $user_id User ID or null for current.
 * @return int[]
 */
function ontrack_get_user_assigned_group_ids( $user_id = null ) {
	if ( null === $user_id ) {
		$user_id = get_current_user_id();
	}
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return array();
	}
	$raw = get_user_meta( $user_id, ontrack_user_group_ids_meta_key(), true );
	if ( ! is_array( $raw ) ) {
		return array();
	}
	return ontrack_sanitize_user_group_ids( $raw );
}

/**
 * Persist assigned group IDs for a user (current user must pass manage check).
 *
 * @param int   $user_id Target user ID.
 * @param mixed $raw     Raw group IDs (array from POST or equivalent).
 * @return bool True if saved or cleared; false if not allowed or invalid user.
 */
function ontrack_set_user_assigned_group_ids( $user_id, $raw ) {
	$user_id = (int) $user_id;
	if ( $user_id <= 0 || ! ontrack_current_user_can_manage_user_groups( $user_id ) ) {
		return false;
	}
	$ids = ontrack_sanitize_user_group_ids( $raw );
	if ( empty( $ids ) ) {
		delete_user_meta( $user_id, ontrack_user_group_ids_meta_key() );
	} else {
		update_user_meta( $user_id, ontrack_user_group_ids_meta_key(), $ids );
	}
	return true;
}

/**
 * Sentinel group ID for “Unassigned” roster (not a real post).
 *
 * @return int
 */
function ontrack_unassigned_group_sentinel() {
	return 0;
}

/**
 * Whether a roster context ID is the pseudo Unassigned bucket.
 *
 * @param int $group_id Context ID from admin (0 = unassigned).
 * @return bool
 */
function ontrack_is_unassigned_group_context( $group_id ) {
	return 0 === (int) $group_id;
}

/**
 * Add one published group to a user’s direct assignments (cap check inside set).
 *
 * @param int $user_id  User ID.
 * @param int $group_id Published group post ID.
 * @return bool
 */
function ontrack_add_user_to_group( $user_id, $group_id ) {
	$user_id  = (int) $user_id;
	$group_id = (int) $group_id;
	if ( $user_id <= 0 || $group_id <= 0 ) {
		return false;
	}
	$post = get_post( $group_id );
	if ( ! $post || ontrack_group_post_type() !== $post->post_type || 'publish' !== $post->post_status ) {
		return false;
	}
	$current = ontrack_get_user_assigned_group_ids( $user_id );
	if ( in_array( $group_id, $current, true ) ) {
		return true;
	}
	$current[] = $group_id;
	return ontrack_set_user_assigned_group_ids( $user_id, $current );
}

/**
 * Remove one group ID from a user’s direct assignments.
 *
 * @param int $user_id  User ID.
 * @param int $group_id Group post ID.
 * @return bool
 */
function ontrack_remove_user_from_group( $user_id, $group_id ) {
	$user_id  = (int) $user_id;
	$group_id = (int) $group_id;
	if ( $user_id <= 0 || $group_id <= 0 ) {
		return false;
	}
	$current = ontrack_get_user_assigned_group_ids( $user_id );
	$current = array_values( array_diff( $current, array( $group_id ) ) );
	return ontrack_set_user_assigned_group_ids( $user_id, $current );
}

/**
 * User IDs with a direct assignment to this published group (roster; actor must be able to manage each user).
 *
 * @param int   $group_post_id Group post ID.
 * @param array $args          Optional. `number` (default 500).
 * @return int[]
 */
function ontrack_get_user_ids_assigned_to_group( $group_post_id, array $args = array() ) {
	$group_post_id = (int) $group_post_id;
	if ( $group_post_id <= 0 ) {
		return array();
	}
	$post = get_post( $group_post_id );
	if ( ! $post || ontrack_group_post_type() !== $post->post_type || 'publish' !== $post->post_status ) {
		return array();
	}
	$number = isset( $args['number'] ) ? max( 1, min( 5000, (int) $args['number'] ) ) : 500;
	$query  = new WP_User_Query(
		array(
			'fields'     => 'ID',
			'number'     => $number,
			'meta_query' => array(
				array(
					'key'     => ontrack_user_group_ids_meta_key(),
					'value'   => 'i:' . $group_post_id . ';',
					'compare' => 'LIKE',
				),
			),
		)
	);
	$raw = array_map( 'intval', (array) $query->get_results() );
	$out = array();
	foreach ( $raw as $uid ) {
		if ( $uid <= 0 ) {
			continue;
		}
		if ( ! ontrack_current_user_can_manage_user_groups( $uid ) ) {
			continue;
		}
		if ( in_array( $group_post_id, ontrack_get_user_assigned_group_ids( $uid ), true ) ) {
			$out[] = $uid;
		}
	}
	return array_values( array_unique( $out ) );
}

/**
 * User IDs the current user may manage for group assignment (bounded by scope model).
 *
 * @param int $limit Cap results (default 500).
 * @return int[]
 */
function ontrack_get_manageable_user_ids_for_group_roster( $limit = 500 ) {
	$limit = max( 1, min( 5000, (int) $limit ) );
	$scope = ontrack_get_user_management_scope( get_current_user_id() );
	$edit  = $scope['edit'];
	if ( empty( $edit ) ) {
		return array();
	}
	return array_slice( $edit, 0, $limit );
}

/**
 * Users with no direct group assignments the current user can manage (Unassigned roster).
 *
 * @param int $limit Cap results (default 500).
 * @return int[]
 */
function ontrack_get_roster_unassigned_user_ids( $limit = 500 ) {
	$limit = max( 1, (int) $limit );
	$seen  = array();
	$out   = array();

	$meta_query = new WP_User_Query(
		array(
			'fields'     => 'ID',
			'number'     => $limit,
			'orderby'    => 'ID',
			'order'      => 'ASC',
			'meta_query' => array(
				'relation' => 'OR',
				array(
					'key'     => ontrack_user_group_ids_meta_key(),
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'     => ontrack_user_group_ids_meta_key(),
					'value'   => 'a:0:{}',
					'compare' => '=',
				),
			),
		)
	);
	foreach ( array_map( 'intval', (array) $meta_query->get_results() ) as $uid ) {
		if ( $uid <= 0 || isset( $seen[ $uid ] ) ) {
			continue;
		}
		if ( ! ontrack_current_user_can_manage_user_groups( $uid ) ) {
			continue;
		}
		if ( ! empty( ontrack_get_user_assigned_group_ids( $uid ) ) ) {
			continue;
		}
		$seen[ $uid ] = true;
		$out[]        = $uid;
		if ( count( $out ) >= $limit ) {
			return $out;
		}
	}

	foreach ( ontrack_get_manageable_user_ids_for_group_roster( $limit ) as $uid ) {
		if ( isset( $seen[ $uid ] ) ) {
			continue;
		}
		if ( empty( ontrack_get_user_assigned_group_ids( $uid ) ) ) {
			$seen[ $uid ] = true;
			$out[]        = $uid;
			if ( count( $out ) >= $limit ) {
				break;
			}
		}
	}

	return $out;
}

/**
 * Total users whose meta matches a direct assignment to this published group (DB count; not filtered by edit_user).
 *
 * @param int $group_post_id Published group post ID.
 * @return int
 */
function ontrack_count_users_assigned_to_group( $group_post_id ) {
	$group_post_id = (int) $group_post_id;
	if ( $group_post_id <= 0 ) {
		return 0;
	}
	$post = get_post( $group_post_id );
	if ( ! $post || ontrack_group_post_type() !== $post->post_type || 'publish' !== $post->post_status ) {
		return 0;
	}
	$query = new WP_User_Query(
		array(
			'count_total' => true,
			'number'      => 1,
			'fields'      => 'ids',
			'meta_query'  => array(
				array(
					'key'     => ontrack_user_group_ids_meta_key(),
					'value'   => 'i:' . $group_post_id . ';',
					'compare' => 'LIKE',
				),
			),
		)
	);
	return (int) $query->get_total();
}

/**
 * Format a roster nav count (cap display for very large totals).
 *
 * @param int $total Raw count.
 * @return string
 */
function ontrack_format_roster_nav_count( $total ) {
	$total = (int) $total;
	if ( $total >= 500 ) {
		return '500+';
	}
	return (string) $total;
}

/**
 * Unassigned roster size for the current actor (capped list; shows "500+" when truncated).
 *
 * @return string
 */
function ontrack_count_roster_unassigned_for_nav() {
	$ids = ontrack_get_roster_unassigned_user_ids( 500 );
	$n   = count( $ids );
	if ( $n >= 500 ) {
		return '500+';
	}
	return (string) $n;
}

/**
 * Ancestor group IDs for a single group (not including self).
 *
 * @param int $group_post_id Group ID.
 * @return int[]
 */
function ontrack_get_group_ancestor_ids( $group_post_id ) {
	$chain = ontrack_get_group_ancestor_chain_root_to_self( $group_post_id );
	if ( empty( $chain ) ) {
		return array();
	}
	array_pop( $chain );
	return $chain;
}

/**
 * Effective group IDs for access checks: assigned groups plus all ancestors of each.
 *
 * @param int|null $user_id User ID or null for current.
 * @return int[] Unique IDs.
 */
function ontrack_get_user_effective_group_ids( $user_id = null ) {
	$assigned = ontrack_get_user_assigned_group_ids( $user_id );
	$all      = array();
	foreach ( $assigned as $gid ) {
		$chain = ontrack_get_group_ancestor_chain_root_to_self( $gid );
		foreach ( $chain as $id ) {
			$all[ $id ] = true;
		}
	}
	return array_map( 'intval', array_keys( $all ) );
}

/**
 * Whether user is assigned to a group or a descendant of an assigned group (for parent-scoped content).
 *
 * @param int   $user_id         User ID.
 * @param int   $group_post_id   Group (collection gate).
 * @param bool  $exact_only      If true, user must be assigned to this exact ID (child-scoped content).
 * @return bool
 */
function ontrack_user_has_group_access( $user_id, $group_post_id, $exact_only = false ) {
	$user_id       = (int) $user_id;
	$group_post_id = (int) $group_post_id;
	if ( $user_id <= 0 || $group_post_id <= 0 ) {
		return false;
	}
	$assigned = ontrack_get_user_assigned_group_ids( $user_id );
	if ( $exact_only ) {
		return in_array( $group_post_id, $assigned, true );
	}
	foreach ( $assigned as $aid ) {
		$chain = ontrack_get_group_ancestor_chain_root_to_self( $aid );
		if ( in_array( $group_post_id, $chain, true ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Whether current user may assign/remove group memberships for a user.
 *
 * @param int $target_user_id Target user.
 * @return bool
 */
function ontrack_current_user_can_manage_user_groups( $target_user_id ) {
	if ( ! current_user_can( KCFA_CAP_EDIT_GROUP_ASSIGNMENTS ) ) {
		return false;
	}
	return ontrack_actor_can_edit_user( get_current_user_id(), (int) $target_user_id );
}

/**
 * Published groups as id => indented title for multiselects (pre-order tree walk).
 *
 * @return array<int, string>
 */
function ontrack_get_group_select_options() {
	$posts = get_posts(
		array(
			'post_type'      => ontrack_group_post_type(),
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'orderby'        => array(
				'menu_order' => 'ASC',
				'title'      => 'ASC',
			),
		)
	);
	if ( empty( $posts ) ) {
		return array();
	}
	$by_parent = array();
	foreach ( $posts as $p ) {
		$pid = (int) $p->post_parent;
		if ( ! isset( $by_parent[ $pid ] ) ) {
			$by_parent[ $pid ] = array();
		}
		$by_parent[ $pid ][] = $p;
	}
	$out = array();
	ontrack_walk_groups_for_select( 0, 0, $by_parent, $out );
	return $out;
}

/**
 * Recursive tree walk for select labels.
 *
 * @param int   $parent_id Parent ID.
 * @param int   $depth     Depth.
 * @param array $by_parent Map parent_id => WP_Post[].
 * @param array $out       Output id => label (by ref).
 */
function ontrack_walk_groups_for_select( $parent_id, $depth, array $by_parent, array &$out ) {
	if ( empty( $by_parent[ $parent_id ] ) ) {
		return;
	}
	foreach ( $by_parent[ $parent_id ] as $p ) {
		$pad                 = $depth > 0 ? str_repeat( '— ', $depth ) : '';
		$out[ (int) $p->ID ] = $pad . $p->post_title;
		ontrack_walk_groups_for_select( (int) $p->ID, $depth + 1, $by_parent, $out );
	}
}

/**
 * Validate a child group's own fragment against the parent's effective demographics.
 *
 * @param array{age_min: ?int, age_max: ?int, gender: string} $parent_effective From ontrack_get_effective_group_demographics( parent_id ).
 * @param array{age_min: ?int, age_max: ?int, gender: string} $fragment        Sanitized own fragment for the child.
 * @return true|WP_Error
 */
function ontrack_validate_demographics_fragment_vs_parent( $parent_effective, $fragment ) {
	if ( null !== $fragment['age_min'] ) {
		if ( null !== $parent_effective['age_min'] && $fragment['age_min'] < $parent_effective['age_min'] ) {
			return new WP_Error(
				'ontrack_age_min',
				__( 'Minimum age cannot be below the parent group’s allowed range.', 'ontrack' )
			);
		}
		if ( null !== $parent_effective['age_max'] && $fragment['age_min'] > $parent_effective['age_max'] ) {
			return new WP_Error(
				'ontrack_age_min_range',
				__( 'Minimum age cannot exceed the parent group’s maximum age.', 'ontrack' )
			);
		}
	}
	if ( null !== $fragment['age_max'] ) {
		if ( null !== $parent_effective['age_max'] && $fragment['age_max'] > $parent_effective['age_max'] ) {
			return new WP_Error(
				'ontrack_age_max',
				__( 'Maximum age cannot be above the parent group’s allowed range.', 'ontrack' )
			);
		}
		if ( null !== $parent_effective['age_min'] && $fragment['age_max'] < $parent_effective['age_min'] ) {
			return new WP_Error(
				'ontrack_age_max_range',
				__( 'Maximum age cannot be below the parent group’s minimum age.', 'ontrack' )
			);
		}
	}
	if ( '' !== $fragment['gender'] && '' !== $parent_effective['gender'] && $fragment['gender'] !== $parent_effective['gender'] ) {
		return new WP_Error(
			'kcfa_gender',
			__( 'Gender cannot differ from the parent group’s demographic rule.', 'ontrack' )
		);
	}
	return true;
}

/**
 * Human-readable age range from an effective demographics fragment (list/UI).
 *
 * @param array{age_min: ?int, age_max: ?int, gender: string} $eff Effective demographics.
 * @return string
 */
function ontrack_format_demographics_age_range_for_display( array $eff ) {
	$min = $eff['age_min'] ?? null;
	$max = $eff['age_max'] ?? null;
	if ( null === $min && null === $max ) {
		return '—';
	}
	if ( null !== $min && null !== $max ) {
		return sprintf( '%d–%d', (int) $min, (int) $max );
	}
	if ( null !== $min ) {
		/* translators: %d: minimum age in years */
		return sprintf( __( '%d+', 'ontrack' ), (int) $min );
	}
	/* translators: %d: maximum age in years */
	return sprintf( __( '≤ %d', 'ontrack' ), (int) $max );
}

/**
 * Human-readable gender from an effective demographics fragment (uses gender choice labels).
 *
 * @param array{age_min: ?int, age_max: ?int, gender: string} $eff Effective demographics.
 * @return string
 */
function ontrack_format_demographics_gender_for_display( array $eff ) {
	$g = isset( $eff['gender'] ) ? (string) $eff['gender'] : '';
	if ( '' === $g ) {
		return '—';
	}
	$choices = ontrack_gender_choices();
	return isset( $choices[ $g ] ) ? $choices[ $g ] : $g;
}
