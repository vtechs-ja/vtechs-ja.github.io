<?php
/**
 * Compare user profile demographics to assigned groups’ effective rules.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * User meta: acknowledged demographic mismatches per group (serialized array).
 *
 * @return string
 */
function ontrack_mismatch_ack_meta_key() {
	return 'ontrack_mismatch_ack';
}

/**
 * Raw acknowledgment map: group_id (string key) => array{note?: string}.
 *
 * @param int $user_id User ID.
 * @return array<string, array{note?: string}>
 */
function ontrack_get_mismatch_ack_map( $user_id ) {
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return array();
	}
	$raw = get_user_meta( $user_id, ontrack_mismatch_ack_meta_key(), true );
	if ( ! is_array( $raw ) ) {
		return array();
	}
	$out = array();
	foreach ( $raw as $k => $row ) {
		$gid = (int) $k;
		if ( $gid <= 0 ) {
			continue;
		}
		$key = (string) $gid;
		if ( ! is_array( $row ) ) {
			$out[ $key ] = array();
			continue;
		}
		$note = isset( $row['note'] ) && is_string( $row['note'] ) ? sanitize_textarea_field( $row['note'] ) : '';
		$out[ $key ] = array( 'note' => $note );
	}
	return $out;
}

/**
 * Whether this user’s mismatch for a group is acknowledged by an admin.
 *
 * @param int $user_id  User ID.
 * @param int $group_id Group post ID.
 * @return bool
 */
function ontrack_is_assignment_mismatch_acknowledged( $user_id, $group_id ) {
	$map = ontrack_get_mismatch_ack_map( $user_id );
	return isset( $map[ (string) (int) $group_id ] );
}

/**
 * Acknowledgment note for a group (if any).
 *
 * @param int $user_id  User ID.
 * @param int $group_id Group post ID.
 * @return string
 */
function ontrack_get_mismatch_ack_note( $user_id, $group_id ) {
	$map = ontrack_get_mismatch_ack_map( $user_id );
	$key = (string) (int) $group_id;
	if ( ! isset( $map[ $key ]['note'] ) ) {
		return '';
	}
	return (string) $map[ $key ]['note'];
}

/**
 * Save or update acknowledgment for one group (caller must cap-check).
 *
 * @param int    $user_id  User ID.
 * @param int    $group_id Group post ID.
 * @param string $note     Optional note.
 * @return bool
 */
function ontrack_set_mismatch_ack( $user_id, $group_id, $note = '' ) {
	$user_id  = (int) $user_id;
	$group_id = (int) $group_id;
	if ( $user_id <= 0 || $group_id <= 0 ) {
		return false;
	}
	$map               = ontrack_get_mismatch_ack_map( $user_id );
	$map[ (string) $group_id ] = array( 'note' => sanitize_textarea_field( (string) $note ) );
	return (bool) update_user_meta( $user_id, ontrack_mismatch_ack_meta_key(), $map );
}

/**
 * Remove acknowledgment for a group.
 *
 * @param int $user_id  User ID.
 * @param int $group_id Group post ID.
 * @return bool
 */
function ontrack_clear_mismatch_ack( $user_id, $group_id ) {
	$user_id  = (int) $user_id;
	$group_id = (int) $group_id;
	if ( $user_id <= 0 || $group_id <= 0 ) {
		return false;
	}
	$map = ontrack_get_mismatch_ack_map( $user_id );
	unset( $map[ (string) $group_id ] );
	if ( empty( $map ) ) {
		return (bool) delete_user_meta( $user_id, ontrack_mismatch_ack_meta_key() );
	}
	return (bool) update_user_meta( $user_id, ontrack_mismatch_ack_meta_key(), $map );
}

/**
 * Mismatch rows for assigned groups (published only).
 *
 * Each item: group_id, group_title, reasons (string[]), acknowledged (bool), ack_note (string).
 *
 * @param int $user_id User ID.
 * @return array<int, array{group_id: int, group_title: string, reasons: string[], acknowledged: bool, ack_note: string}>
 */
function ontrack_get_demographic_mismatches_for_user( $user_id ) {
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return array();
	}

	$age    = ontrack_get_user_age_years( $user_id );
	$gender = ontrack_get_user_gender( $user_id );
	$ack_map = ontrack_get_mismatch_ack_map( $user_id );

	$choices = ontrack_gender_choices();
	$items   = array();

	foreach ( ontrack_get_user_assigned_group_ids( $user_id ) as $gid ) {
		$gid = (int) $gid;
		if ( $gid <= 0 ) {
			continue;
		}
		$post = get_post( $gid );
		if ( ! $post || ontrack_group_post_type() !== $post->post_type || 'publish' !== $post->post_status ) {
			continue;
		}

		$eff     = ontrack_get_effective_group_demographics( $gid );
		$reasons = array();

		$needs_age = null !== $eff['age_min'] || null !== $eff['age_max'];
		if ( $needs_age && null === $age ) {
			if ( null !== $eff['age_min'] && null !== $eff['age_max'] ) {
				$reasons[] = sprintf(
					/* translators: 1: minimum age, 2: maximum age */
					__( 'This group expects an age between %1$d and %2$d, but this user has no date of birth on file.', 'ontrack' ),
					(int) $eff['age_min'],
					(int) $eff['age_max']
				);
			} elseif ( null !== $eff['age_min'] ) {
				$reasons[] = sprintf(
					/* translators: %d: minimum age */
					__( 'This group expects a minimum age of %d, but this user has no date of birth on file.', 'ontrack' ),
					(int) $eff['age_min']
				);
			} else {
				$reasons[] = sprintf(
					/* translators: %d: maximum age */
					__( 'This group expects a maximum age of %d, but this user has no date of birth on file.', 'ontrack' ),
					(int) $eff['age_max']
				);
			}
		} else {
			if ( null !== $eff['age_min'] && null !== $age && $age < (int) $eff['age_min'] ) {
				$reasons[] = sprintf(
					/* translators: 1: user age, 2: minimum age required */
					__( 'This group expects a minimum age of %2$d; the profile age is %1$d.', 'ontrack' ),
					$age,
					(int) $eff['age_min']
				);
			}
			if ( null !== $eff['age_max'] && null !== $age && $age > (int) $eff['age_max'] ) {
				$reasons[] = sprintf(
					/* translators: 1: user age, 2: maximum age allowed */
					__( 'This group expects a maximum age of %2$d; the profile age is %1$d.', 'ontrack' ),
					$age,
					(int) $eff['age_max']
				);
			}
		}

		if ( '' !== $eff['gender'] ) {
			$want_label = isset( $choices[ $eff['gender'] ] ) ? $choices[ $eff['gender'] ] : $eff['gender'];
			if ( '' === $gender ) {
				$reasons[] = sprintf(
					/* translators: %s: expected gender label */
					__( 'This group expects gender “%s”, but the profile gender is not set.', 'ontrack' ),
					$want_label
				);
			} elseif ( $gender !== $eff['gender'] ) {
				$have_label = isset( $choices[ $gender ] ) ? $choices[ $gender ] : $gender;
				$reasons[]  = sprintf(
					/* translators: 1: group expectation, 2: profile value */
					__( 'This group expects “%1$s”; the profile is “%2$s”.', 'ontrack' ),
					$want_label,
					$have_label
				);
			}
		}

		if ( empty( $reasons ) ) {
			continue;
		}

		$ack_key = (string) $gid;
		$items[] = array(
			'group_id'      => $gid,
			'group_title'   => get_the_title( $gid ),
			'reasons'       => $reasons,
			'acknowledged'  => isset( $ack_map[ $ack_key ] ),
			'ack_note'      => isset( $ack_map[ $ack_key ]['note'] ) ? (string) $ack_map[ $ack_key ]['note'] : '',
		);
	}

	/**
	 * Filter mismatch rows before display.
	 *
	 * @param array $items   List of mismatch structs.
	 * @param int   $user_id User ID.
	 */
	return apply_filters( 'ontrack_demographic_mismatch_items', $items, $user_id );
}

/**
 * Mismatch rows excluding those marked acknowledged (for “active issues” counts/lists).
 *
 * @param int $user_id User ID.
 * @return array
 */
function ontrack_get_active_demographic_mismatches_for_user( $user_id ) {
	$out = array();
	foreach ( ontrack_get_demographic_mismatches_for_user( $user_id ) as $row ) {
		if ( ! empty( $row['acknowledged'] ) ) {
			continue;
		}
		$out[] = $row;
	}
	return $out;
}
