<?php
/**
 * User profile: full member checkbox.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * User edit / profile fields for membership.
 */
class Ontrack_User_Admin {

	const NONCE_ACTION = 'ontrack_save_member';
	const NONCE_FIELD  = 'ontrack_member_nonce';

	/**
	 * Bootstrap hooks.
	 */
	public function register() {
		add_action( 'show_user_profile', array( $this, 'render_fields' ) );
		add_action( 'edit_user_profile', array( $this, 'render_fields' ) );
		add_action( 'personal_options_update', array( $this, 'save_profile' ) );
		add_action( 'edit_user_profile_update', array( $this, 'save_profile' ) );
	}

	/**
	 * Output membership section when the current user may manage membership for this profile.
	 *
	 * @param WP_User $user User being edited.
	 */
	public function render_fields( $user ) {
		if ( ! $user instanceof WP_User ) {
			return;
		}

		if ( ! ontrack_current_user_can_manage_member_flag_for_user( $user->ID ) ) {
			return;
		}

		$is_member = ontrack_user_is_full_member( $user->ID );
		wp_nonce_field( self::NONCE_ACTION, self::NONCE_FIELD );
		?>
		<h2 id="ontrack-membership-heading"><?php esc_html_e( 'KCFA membership', 'ontrack' ); ?></h2>
		<table class="form-table" role="presentation" aria-labelledby="ontrack-membership-heading">
			<tr>
				<th scope="row"><?php esc_html_e( 'Full member', 'ontrack' ); ?></th>
				<td>
					<label for="kcfa_is_member">
						<input type="checkbox" name="kcfa_is_member" id="kcfa_is_member" value="1" <?php checked( $is_member ); ?> />
						<?php esc_html_e( 'User is a full member (wider catalogue access when enforcement is enabled).', 'ontrack' ); ?>
					</label>
					<p class="description">
						<?php esc_html_e( 'Visitors are logged-in users without this flag. Guests are users who are not logged in.', 'ontrack' ); ?>
					</p>
				</td>
			</tr>
		</table>
		<?php
	}

	/**
	 * Persist full member flag when permitted and nonce verifies.
	 *
	 * @param int $user_id User ID.
	 */
	public function save_profile( $user_id ) {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 ) {
			return;
		}

		if ( ! isset( $_POST[ self::NONCE_FIELD ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE_FIELD ] ) ), self::NONCE_ACTION ) ) {
			return;
		}

		if ( ! ontrack_current_user_can_manage_member_flag_for_user( $user_id ) ) {
			return;
		}

		$is_member = isset( $_POST['kcfa_is_member'] ) && '1' === $_POST['kcfa_is_member'];
		update_user_meta( $user_id, ontrack_meta_key_is_member(), $is_member ? '1' : '0' );
	}
}
