<?php
/**
 * Activation and versioned setup.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Runs on plugin activation and when the plugin version bumps.
 */
class Ontrack_Activator {

	/**
	 * Register roles, create tables, seed options, ensure JWT secret, schedule cron.
	 * Sets a flag so rewrite rules are flushed on the next init (after CPTs are registered).
	 */
	public static function activate() {
		self::register_roles();
		ontrack_audio_metadata_create_table();
		self::ensure_default_options();
		Ontrack_JWT::ensure_secret();
		self::schedule_cron();
		update_option( 'ontrack_flush_rewrite_rules', 1, false );
	}

	/**
	 * Flush rewrite rules if the flag is set. Hooked to init at priority 99,
	 * after CPT registration (priority 10), so new slugs are included.
	 */
	public static function maybe_flush_rewrite_rules() {
		if ( get_option( 'ontrack_flush_rewrite_rules' ) ) {
			flush_rewrite_rules();
			delete_option( 'ontrack_flush_rewrite_rules' );
		}
	}

	/**
	 * Remove custom roles, clear cron on deactivation.
	 * JWT secret option is intentionally preserved — tokens remain valid across re-activations.
	 */
	public static function deactivate() {
		foreach ( array_keys( ontrack_get_role_definitions() ) as $slug ) {
			remove_role( $slug );
		}
		wp_clear_scheduled_hook( Ontrack_Plugin::CRON_CLEANUP_HOOK );
	}

	/**
	 * Schedule daily refresh-token cleanup if not already scheduled.
	 */
	private static function schedule_cron() {
		if ( ! wp_next_scheduled( Ontrack_Plugin::CRON_CLEANUP_HOOK ) ) {
			wp_schedule_event( time(), 'daily', Ontrack_Plugin::CRON_CLEANUP_HOOK );
		}
	}

	/**
	 * Register each custom role (idempotent) and grant all klac_* caps to administrator.
	 */
	private static function register_roles() {
		$labels = array(
			KCFA_ROLE_MEMBER           => __( 'KLAC Member', 'ontrack' ),
			KCFA_ROLE_LEADER           => __( 'KLAC Leader', 'ontrack' ),
			KCFA_ROLE_COMMUNITY_LEADER => __( 'KLAC Community Leader', 'ontrack' ),
			KCFA_ROLE_ADMIN            => __( 'KLAC Admin', 'ontrack' ),
		);

		foreach ( ontrack_get_role_definitions() as $slug => $caps ) {
			if ( ! get_role( $slug ) ) {
				add_role( $slug, $labels[ $slug ] ?? $slug, $caps );
			}
		}

		$administrator = get_role( 'administrator' );
		if ( $administrator ) {
			foreach ( ontrack_get_all_capabilities() as $cap => $grant ) {
				$administrator->add_cap( $cap, $grant );
			}
		}
	}

	/**
	 * Seed default options if missing.
	 */
	private static function ensure_default_options() {
		if ( false === get_option( ontrack_options_key(), false ) ) {
			add_option( ontrack_options_key(), ontrack_default_options(), '', false );
		}
	}
}
