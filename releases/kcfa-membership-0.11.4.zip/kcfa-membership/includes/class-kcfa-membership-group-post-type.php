<?php
/**
 * Register hierarchical group CPT and map_meta_cap.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Group post type registration.
 */
class Ontrack_Group_Post_Type {

	/**
	 * Register hooks.
	 */
	public function register() {
		add_action( 'init', array( $this, 'register_post_type' ), 5 );
		add_filter( 'map_meta_cap', array( $this, 'map_group_meta_cap' ), 10, 4 );
		add_filter( 'manage_' . ontrack_group_post_type() . '_posts_columns', array( $this, 'posts_columns' ) );
		add_action( 'manage_' . ontrack_group_post_type() . '_posts_custom_column', array( $this, 'posts_custom_column' ), 10, 2 );
		add_filter( 'post_row_actions', array( $this, 'row_actions_roster' ), 10, 2 );
	}

	/**
	 * Link to Group rosters screen for this group.
	 *
	 * @param string[] $actions Row actions.
	 * @param WP_Post  $post    Post.
	 * @return string[]
	 */
	public function row_actions_roster( $actions, $post ) {
		if ( ! $post instanceof WP_Post || ontrack_group_post_type() !== $post->post_type ) {
			return $actions;
		}
		if ( 'publish' !== $post->post_status ) {
			return $actions;
		}
		if ( ! current_user_can( 'edit_kcfa_groups' ) ) {
			return $actions;
		}
		$url                    = admin_url( 'admin.php?page=kcfa-management-assign&group_id=' . (int) $post->ID );
		$actions['ontrack_roster'] = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Roster', 'ontrack' ) . '</a>';
		return $actions;
	}

	/**
	 * Add age and gender columns after the title on the groups list table.
	 *
	 * @param string[] $columns Column keys => labels.
	 * @return string[]
	 */
	public function posts_columns( $columns ) {
		if ( ! is_array( $columns ) ) {
			return $columns;
		}
		$new = array();
		foreach ( $columns as $key => $label ) {
			$new[ $key ] = $label;
			if ( 'title' === $key ) {
				$new['ontrack_group_age']    = __( 'Age range', 'ontrack' );
				$new['ontrack_group_gender'] = __( 'Gender', 'ontrack' );
			}
		}
		if ( ! isset( $new['ontrack_group_age'] ) ) {
			$new['ontrack_group_age']    = __( 'Age range', 'ontrack' );
			$new['ontrack_group_gender'] = __( 'Gender', 'ontrack' );
		}
		return $new;
	}

	/**
	 * Output effective demographic rule for list columns.
	 *
	 * @param string $column  Column key.
	 * @param int    $post_id Post ID.
	 */
	public function posts_custom_column( $column, $post_id ) {
		if ( 'ontrack_group_age' !== $column && 'ontrack_group_gender' !== $column ) {
			return;
		}
		$post_id = (int) $post_id;
		if ( $post_id <= 0 || ontrack_group_post_type() !== get_post_type( $post_id ) ) {
			echo esc_html( '—' );
			return;
		}
		$eff = ontrack_get_effective_group_demographics( $post_id );
		if ( 'ontrack_group_age' === $column ) {
			echo esc_html( ontrack_format_demographics_age_range_for_display( $eff ) );
			return;
		}
		echo esc_html( ontrack_format_demographics_gender_for_display( $eff ) );
	}

	/**
	 * Register post type and post meta for demographics.
	 */
	public function register_post_type() {
		$labels = array(
			'name'               => __( 'Groups', 'ontrack' ),
			'singular_name'      => __( 'Group', 'ontrack' ),
			'add_new'            => __( 'Add New', 'ontrack' ),
			'add_new_item'       => __( 'Add New Group', 'ontrack' ),
			'edit_item'          => __( 'Edit Group', 'ontrack' ),
			'new_item'           => __( 'New Group', 'ontrack' ),
			'view_item'          => __( 'View Group', 'ontrack' ),
			'search_items'       => __( 'Search Groups', 'ontrack' ),
			'not_found'          => __( 'No groups found.', 'ontrack' ),
			'not_found_in_trash' => __( 'No groups found in Trash.', 'ontrack' ),
			'parent_item_colon'  => __( 'Parent group:', 'ontrack' ),
			'all_items'          => __( 'All Groups', 'ontrack' ),
			'menu_name'          => __( 'Groups', 'ontrack' ),
		);

		register_post_type(
			ontrack_group_post_type(),
			array(
				'labels'              => $labels,
				'description'         => __( 'KCFA membership groups (hierarchical).', 'ontrack' ),
				'public'              => false,
				'show_ui'             => true,
				'show_in_menu'        => ontrack_management_menu_slug(),
				'menu_icon'           => 'dashicons-groups',
				'hierarchical'        => true,
				'supports'            => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
				'capability_type'     => array( 'kcfa_group', 'kcfa_groups' ),
				'map_meta_cap'        => true,
				'rewrite'             => false,
				'query_var'           => false,
				'delete_with_user'    => false,
				'show_in_rest'        => false,
			)
		);

		register_post_meta(
			ontrack_group_post_type(),
			ontrack_group_demographics_meta_key(),
			array(
				'type'              => 'string',
				'single'            => true,
				'sanitize_callback' => array( $this, 'sanitize_demographics_meta' ),
				'show_in_rest'      => false,
				'auth_callback'     => array( $this, 'can_edit_group_meta' ),
			)
		);
	}

	/**
	 * REST/auth callback for demographics meta.
	 *
	 * @param bool   $allowed Whether allowed.
	 * @param string $meta_key Meta key.
	 * @param int    $post_id Post ID.
	 * @return bool
	 */
	public function can_edit_group_meta( $allowed, $meta_key, $post_id ) {
		$post_id = (int) $post_id;
		$user_id = get_current_user_id();
		if ( $post_id <= 0 || ! $user_id ) {
			return false;
		}
		return ontrack_user_meets_min_role_to_manage_member_flag( $user_id )
			&& current_user_can( 'edit_post', $post_id );
	}

	/**
	 * Sanitize JSON demographics for register_post_meta.
	 *
	 * @param string $value Value.
	 * @return string JSON.
	 */
	public function sanitize_demographics_meta( $value ) {
		if ( is_array( $value ) ) {
			$clean = ontrack_sanitize_demographics_fragment( $value );
		} else {
			$decoded = json_decode( (string) $value, true );
			$clean   = ontrack_sanitize_demographics_fragment( is_array( $decoded ) ? $decoded : array() );
		}
		return wp_json_encode( $clean );
	}

	/**
	 * Grant group CPT capabilities when user meets minimum membership-admin role.
	 *
	 * @param string[] $caps    Primitive caps for the user.
	 * @param string   $cap     Capability being checked.
	 * @param int      $user_id User ID.
	 * @param array    $args    Extra args.
	 * @return string[]
	 */
	public function map_group_meta_cap( $caps, $cap, $user_id, $args ) {
		$user_id = (int) $user_id;
		$is_group_context = ontrack_is_group_post_type_cap( (string) $cap );

		if ( ! $is_group_context && ! empty( $args[0] ) ) {
			$post = get_post( (int) $args[0] );
			if ( $post && ontrack_group_post_type() === $post->post_type ) {
				$is_group_context = true;
			}
		}

		if ( ! $is_group_context ) {
			return $caps;
		}

		if ( $user_id <= 0 ) {
			return array( 'do_not_allow' );
		}
		if ( ontrack_user_meets_min_role_to_manage_member_flag( $user_id ) ) {
			return array();
		}
		return array( 'do_not_allow' );
	}
}
