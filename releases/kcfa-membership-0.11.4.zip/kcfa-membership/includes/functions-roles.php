<?php
/**
 * Role and capability definitions, coordinator meta, and scope resolution.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ---------------------------------------------------------------------------
// Role slugs — use these constants everywhere; never magic-string role names.
// ---------------------------------------------------------------------------

define( 'KCFA_ROLE_MEMBER',           'klac_member' );
define( 'KCFA_ROLE_LEADER',           'klac_leader' );
define( 'KCFA_ROLE_COMMUNITY_LEADER', 'klac_community_leader' );
define( 'KCFA_ROLE_ADMIN',            'klac_admin' );

// ---------------------------------------------------------------------------
// Capability keys — use these constants everywhere.
// ---------------------------------------------------------------------------

define( 'KCFA_CAP_EDIT_OWN_PROFILE',       'klac_edit_own_profile' );
define( 'KCFA_CAP_VIEW_ROSTER',            'klac_view_roster' );
define( 'KCFA_CAP_VIEW_DEMOGRAPHICS',      'klac_view_demographics' );
define( 'KCFA_CAP_EDIT_MEMBER_PROFILE',    'klac_edit_member_profile' );
define( 'KCFA_CAP_EDIT_MEMBERSHIP_FLAG',   'klac_edit_membership_flag' );
define( 'KCFA_CAP_EDIT_GROUP_ASSIGNMENTS', 'klac_edit_group_assignments' );
define( 'KCFA_CAP_MANAGE_GROUPS',          'klac_manage_groups' );
define( 'KCFA_CAP_MANAGE_SETTINGS',        'klac_manage_settings' );
define( 'KCFA_CAP_MANAGE_MEDIA',           'klac_manage_media' );

// ---------------------------------------------------------------------------
// Role definitions
// ---------------------------------------------------------------------------

/**
 * Returns the capability map for each custom role.
 * Single source of truth — consumed by activation to register roles.
 *
 * @return array<string, array<string, bool>> role_slug => [ cap => true, … ]
 */
function ontrack_get_role_definitions() {
	$member_caps = array(
		KCFA_CAP_EDIT_OWN_PROFILE => true,
	);

	$leader_caps = array_merge(
		$member_caps,
		array(
			KCFA_CAP_VIEW_ROSTER            => true,
			KCFA_CAP_VIEW_DEMOGRAPHICS      => true,
			KCFA_CAP_EDIT_MEMBER_PROFILE    => true,
			KCFA_CAP_EDIT_MEMBERSHIP_FLAG   => true,
			KCFA_CAP_EDIT_GROUP_ASSIGNMENTS => true,
		)
	);

	$admin_caps = array_merge(
		$leader_caps,
		array(
			KCFA_CAP_MANAGE_GROUPS   => true,
			KCFA_CAP_MANAGE_SETTINGS => true,
			KCFA_CAP_MANAGE_MEDIA    => true,
		)
	);

	return array(
		KCFA_ROLE_MEMBER           => $member_caps,
		KCFA_ROLE_LEADER           => $leader_caps,
		KCFA_ROLE_COMMUNITY_LEADER => $leader_caps, // Same caps as leader; scope is unrestricted.
		KCFA_ROLE_ADMIN            => $admin_caps,
	);
}

/**
 * Returns all klac_* capability keys (for granting to the administrator WP role).
 *
 * @return array<string, bool>
 */
function ontrack_get_all_capabilities() {
	$all = array();
	foreach ( ontrack_get_role_definitions() as $caps ) {
		$all = array_merge( $all, $caps );
	}
	return $all;
}

// ---------------------------------------------------------------------------
// Coordinator designation meta
// ---------------------------------------------------------------------------

/**
 * User meta key for coordinator group assignments (distinct from group membership).
 *
 * @return string
 */
function ontrack_coordinator_group_ids_meta_key() {
	return 'ontrack_coordinator_group_ids';
}

/**
 * Get the group IDs this user coordinates.
 *
 * @param int $user_id
 * @return int[]
 */
function ontrack_get_coordinator_group_ids( $user_id ) {
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return array();
	}
	$raw = get_user_meta( $user_id, ontrack_coordinator_group_ids_meta_key(), true );
	if ( empty( $raw ) || ! is_array( $raw ) ) {
		return array();
	}
	return array_values( array_map( 'intval', $raw ) );
}

/**
 * Set the group IDs this user coordinates.
 * Sanitises IDs and checks actor capability before writing.
 *
 * @param int   $user_id   Target user.
 * @param int[] $group_ids Group post IDs.
 * @return bool True on success, false on capability failure.
 */
function ontrack_set_coordinator_group_ids( $user_id, array $group_ids ) {
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return false;
	}
	if ( ! current_user_can( KCFA_CAP_MANAGE_GROUPS ) && ! current_user_can( 'edit_user', $user_id ) ) {
		return false;
	}
	$sanitised = ontrack_sanitize_user_group_ids( $group_ids );
	update_user_meta( $user_id, ontrack_coordinator_group_ids_meta_key(), $sanitised );
	return true;
}

// ---------------------------------------------------------------------------
// Scope resolution
// ---------------------------------------------------------------------------

/**
 * Compute which user IDs the actor may view and/or edit.
 *
 * Returns:
 *   'view' => int[]  User IDs the actor can view.
 *   'edit' => int[]  User IDs the actor can edit (always a subset of 'view').
 *
 * This function performs DB queries; cache the result if calling multiple times
 * in the same request for the same actor.
 *
 * @param int $actor_id WP user ID of the person performing the action.
 * @return array{ view: int[], edit: int[] }
 */
function ontrack_get_user_management_scope( $actor_id ) {
	$actor_id = (int) $actor_id;
	$empty    = array( 'view' => array(), 'edit' => array() );

	if ( $actor_id <= 0 ) {
		return $empty;
	}

	// Admins and community leaders see and edit all members (no group restriction).
	if ( user_can( $actor_id, KCFA_CAP_MANAGE_GROUPS ) ||
		ontrack_user_has_role( $actor_id, KCFA_ROLE_COMMUNITY_LEADER ) ) {
		$all = _ontrack_get_all_member_ids();
		return array( 'view' => $all, 'edit' => $all );
	}

	$view_ids = array();
	$edit_ids = array();

	// Leaders: scope = all users in their people group(s) and descendant groups.
	if ( ontrack_user_has_role( $actor_id, KCFA_ROLE_LEADER ) ) {
		$leader_groups = ontrack_get_user_assigned_group_ids( $actor_id );
		$scoped_groups = array();
		foreach ( $leader_groups as $gid ) {
			$scoped_groups = array_merge( $scoped_groups, _ontrack_get_group_and_descendant_ids( $gid ) );
		}
		foreach ( array_unique( $scoped_groups ) as $gid ) {
			$members  = _ontrack_get_raw_user_ids_for_group( $gid );
			$view_ids = array_merge( $view_ids, $members );
			$edit_ids = array_merge( $edit_ids, $members );
		}
	}

	// Coordinator designation: view-only access to specifically assigned groups.
	$coord_groups = ontrack_get_coordinator_group_ids( $actor_id );
	foreach ( $coord_groups as $gid ) {
		$view_ids = array_merge( $view_ids, _ontrack_get_raw_user_ids_for_group( $gid ) );
		// No edit access for coordinators.
	}

	return array(
		'view' => array_values( array_unique( array_map( 'intval', $view_ids ) ) ),
		'edit' => array_values( array_unique( array_map( 'intval', $edit_ids ) ) ),
	);
}

/**
 * Whether the actor can view the target user's profile.
 * Always true when actor === target.
 *
 * @param int $actor_id
 * @param int $target_id
 * @return bool
 */
function ontrack_actor_can_view_user( $actor_id, $target_id ) {
	$actor_id  = (int) $actor_id;
	$target_id = (int) $target_id;
	if ( $actor_id === $target_id ) {
		return true;
	}
	$scope = ontrack_get_user_management_scope( $actor_id );
	return in_array( $target_id, $scope['view'], true );
}

/**
 * Whether the actor can edit the target user's profile.
 * Always true when actor === target (bounded to klac_edit_own_profile).
 *
 * @param int $actor_id
 * @param int $target_id
 * @return bool
 */
function ontrack_actor_can_edit_user( $actor_id, $target_id ) {
	$actor_id  = (int) $actor_id;
	$target_id = (int) $target_id;
	if ( $actor_id === $target_id ) {
		return user_can( $actor_id, KCFA_CAP_EDIT_OWN_PROFILE );
	}
	$scope = ontrack_get_user_management_scope( $actor_id );
	return in_array( $target_id, $scope['edit'], true );
}

// ---------------------------------------------------------------------------
// Internal helpers (not part of the public API)
// ---------------------------------------------------------------------------

/**
 * Whether a user has a specific role slug.
 *
 * @param int    $user_id
 * @param string $role
 * @return bool
 */
function ontrack_user_has_role( $user_id, $role ) {
	$user = get_userdata( (int) $user_id );
	if ( ! $user ) {
		return false;
	}
	return in_array( $role, (array) $user->roles, true );
}

/**
 * All member user IDs (kcfa_is_member = 1). Used for unrestricted scope.
 *
 * @return int[]
 */
function _ontrack_get_all_member_ids() {
	$query = new WP_User_Query( array(
		'fields'     => 'ID',
		'number'     => -1,
		'meta_query' => array(
			array(
				'key'   => ontrack_meta_key_is_member(),
				'value' => '1',
			),
		),
	) );
	return array_values( array_map( 'intval', (array) $query->get_results() ) );
}

/**
 * A group post ID and all its published descendants (recursive).
 *
 * @param int $group_id
 * @return int[]
 */
function _ontrack_get_group_and_descendant_ids( $group_id ) {
	$group_id = (int) $group_id;
	$result   = array( $group_id );
	$children = get_posts( array(
		'post_type'      => ontrack_group_post_type(),
		'post_parent'    => $group_id,
		'post_status'    => 'publish',
		'fields'         => 'ids',
		'posts_per_page' => -1,
	) );
	foreach ( $children as $child_id ) {
		$result = array_merge( $result, _ontrack_get_group_and_descendant_ids( (int) $child_id ) );
	}
	return $result;
}

/**
 * User IDs directly assigned to a group — no capability filtering.
 * Used internally by scope resolution to avoid circular capability checks.
 *
 * @param int $group_id
 * @return int[]
 */
function _ontrack_get_raw_user_ids_for_group( $group_id ) {
	$group_id = (int) $group_id;
	if ( $group_id <= 0 ) {
		return array();
	}
	$query = new WP_User_Query( array(
		'fields'     => 'ID',
		'number'     => -1,
		'meta_query' => array(
			array(
				'key'     => ontrack_user_group_ids_meta_key(),
				'value'   => 'i:' . $group_id . ';',
				'compare' => 'LIKE',
			),
		),
	) );
	$raw = array_map( 'intval', (array) $query->get_results() );
	// Verify assignment is genuine (not a false LIKE match on a similar ID).
	return array_values( array_filter( $raw, function ( $uid ) use ( $group_id ) {
		return in_array( $group_id, ontrack_get_user_assigned_group_ids( $uid ), true );
	} ) );
}
