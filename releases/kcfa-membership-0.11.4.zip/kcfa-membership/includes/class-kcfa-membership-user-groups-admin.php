<?php
/**
 * User profile: group assignments.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Assign users to KCFA groups (post IDs).
 */
class Ontrack_User_Groups_Admin {

	const NONCE_ACTION = 'ontrack_save_user_groups';
	const NONCE_FIELD  = 'ontrack_user_groups_nonce';

	/**
	 * Register hooks.
	 */
	public function register() {
		add_action( 'show_user_profile', array( $this, 'render_fields' ), 15 );
		add_action( 'edit_user_profile', array( $this, 'render_fields' ), 15 );
		add_action( 'personal_options_update', array( $this, 'save_profile' ) );
		add_action( 'edit_user_profile_update', array( $this, 'save_profile' ) );
	}

	/**
	 * Output group multiselect.
	 *
	 * @param WP_User $user User.
	 */
	public function render_fields( $user ) {
		if ( ! $user instanceof WP_User ) {
			return;
		}
		if ( ! ontrack_current_user_can_manage_user_groups( $user->ID ) ) {
			return;
		}

		$assigned = ontrack_get_user_assigned_group_ids( $user->ID );
		$options  = ontrack_get_group_select_options();
		wp_nonce_field( self::NONCE_ACTION, self::NONCE_FIELD );
		?>
		<h2 id="ontrack-user-groups-heading"><?php esc_html_e( 'KCFA groups', 'ontrack' ); ?></h2>
		<p class="description" id="ontrack-user-groups-desc">
			<?php esc_html_e( 'Assign this user to one or more groups. You can also use KCFA Management → Group rosters (pick a group or Unassigned). Parent collections (Phase 7) will include descendants; child-only collections require an assignment to that child group.', 'ontrack' ); ?>
		</p>
		<table class="form-table" role="presentation" aria-labelledby="ontrack-user-groups-heading" aria-describedby="ontrack-user-groups-desc">
			<tr>
				<th scope="row"><label for="ontrack_user_group_ids"><?php esc_html_e( 'Groups', 'ontrack' ); ?></label></th>
				<td>
					<?php if ( empty( $options ) ) : ?>
						<p><?php esc_html_e( 'No published groups yet. Create groups under KCFA Management → Groups.', 'ontrack' ); ?></p>
					<?php else : ?>
						<select name="ontrack_user_group_ids[]" id="ontrack_user_group_ids" multiple="multiple" size="8" class="ontrack-user-groups-select" style="min-width: 20em;">
							<?php foreach ( $options as $gid => $label ) : ?>
								<option value="<?php echo esc_attr( (string) $gid ); ?>" <?php selected( in_array( (int) $gid, $assigned, true ) ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'Hold Ctrl (Windows) or Command (Mac) to select multiple.', 'ontrack' ); ?></p>
					<?php endif; ?>
				</td>
			</tr>
		</table>
		<?php
	}

	/**
	 * Save assignments.
	 *
	 * @param int $user_id User ID.
	 */
	public function save_profile( $user_id ) {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 ) {
			return;
		}
		if ( ! isset( $_POST[ self::NONCE_FIELD ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE_FIELD ] ) ), self::NONCE_ACTION ) ) {
			return;
		}
		$raw = isset( $_POST['ontrack_user_group_ids'] ) ? wp_unslash( $_POST['ontrack_user_group_ids'] ) : array();
		ontrack_set_user_assigned_group_ids( $user_id, $raw );
	}
}
