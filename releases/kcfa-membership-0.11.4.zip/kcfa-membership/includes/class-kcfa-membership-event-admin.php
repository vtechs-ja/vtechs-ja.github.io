<?php
/**
 * Admin meta box for Event posts (ontrack_event CPT).
 *
 * Meta fields:
 *   _event_datetime   — Y-m-d H:i:s (site local time)
 *   _event_location   — text
 *   _event_stream_url — URL, optional
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and renders the "Event Details" meta box on ontrack_event posts.
 */
class Ontrack_Event_Admin {

	public function register() {
		add_action( 'add_meta_boxes_ontrack_event', array( $this, 'add_meta_boxes' ) );
		add_action( 'save_post_ontrack_event', array( $this, 'save_post' ) );
	}

	public function add_meta_boxes() {
		add_meta_box(
			'ontrack_event_details',
			__( 'Event Details', 'ontrack' ),
			array( $this, 'render' ),
			'ontrack_event',
			'normal',
			'high'
		);
	}

	/**
	 * @param WP_Post $post Post.
	 */
	public function render( WP_Post $post ) {
		wp_nonce_field( 'ontrack_event_save', 'ontrack_event_nonce' );

		$raw_dt     = (string) get_post_meta( $post->ID, '_event_datetime', true );
		$location   = (string) get_post_meta( $post->ID, '_event_location', true );
		$stream_url = (string) get_post_meta( $post->ID, '_event_stream_url', true );

		// datetime-local input expects "YYYY-MM-DDTHH:MM".
		$dt_value = $raw_dt ? date( 'Y-m-d\TH:i', strtotime( $raw_dt ) ) : '';
		?>
		<table class="form-table" style="margin-top:0;">
			<tr>
				<th scope="row">
					<label for="ontrack_event_datetime"><?php esc_html_e( 'Date & Time', 'ontrack' ); ?></label>
				</th>
				<td>
					<input type="datetime-local" id="ontrack_event_datetime" name="ontrack_event_datetime"
						value="<?php echo esc_attr( $dt_value ); ?>" />
				</td>
			</tr>
			<tr>
				<th scope="row">
					<label for="ontrack_event_location"><?php esc_html_e( 'Location', 'ontrack' ); ?></label>
				</th>
				<td>
					<input type="text" id="ontrack_event_location" name="ontrack_event_location"
						value="<?php echo esc_attr( $location ); ?>" class="regular-text" />
				</td>
			</tr>
			<tr>
				<th scope="row">
					<label for="ontrack_event_stream_url"><?php esc_html_e( 'Streaming Link', 'ontrack' ); ?></label>
				</th>
				<td>
					<input type="url" id="ontrack_event_stream_url" name="ontrack_event_stream_url"
						value="<?php echo esc_attr( $stream_url ); ?>" class="regular-text"
						placeholder="https://" />
					<p class="description"><?php esc_html_e( 'Optional. Shown as a "Watch Live" button on the event detail view.', 'ontrack' ); ?></p>
				</td>
			</tr>
		</table>
		<?php
	}

	/**
	 * @param int $post_id Post ID.
	 */
	public function save_post( $post_id ) {
		if ( ! isset( $_POST['ontrack_event_nonce'] ) ||
			! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ontrack_event_nonce'] ) ), 'ontrack_event_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// datetime-local sends "YYYY-MM-DDTHH:MM" — normalise to "YYYY-MM-DD HH:MM:00".
		if ( ! empty( $_POST['ontrack_event_datetime'] ) ) {
			$raw = sanitize_text_field( wp_unslash( $_POST['ontrack_event_datetime'] ) );
			$ts  = strtotime( $raw );
			if ( $ts ) {
				update_post_meta( $post_id, '_event_datetime', date( 'Y-m-d H:i:s', $ts ) );
			}
		} else {
			delete_post_meta( $post_id, '_event_datetime' );
		}

		$location = isset( $_POST['ontrack_event_location'] )
			? sanitize_text_field( wp_unslash( $_POST['ontrack_event_location'] ) )
			: '';
		if ( $location ) {
			update_post_meta( $post_id, '_event_location', $location );
		} else {
			delete_post_meta( $post_id, '_event_location' );
		}

		$stream_url = isset( $_POST['ontrack_event_stream_url'] )
			? esc_url_raw( wp_unslash( $_POST['ontrack_event_stream_url'] ) )
			: '';
		if ( $stream_url ) {
			update_post_meta( $post_id, '_event_stream_url', $stream_url );
		} else {
			delete_post_meta( $post_id, '_event_stream_url' );
		}
	}
}
