<?php
/**
 * JWT utility (HS256, no external library).
 *
 * Secret key resolution order:
 *   1. KCFA_JWT_SECRET constant in wp-config.php (optional override).
 *   2. Auto-generated key stored in WP options (created on first use / activation).
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Static JWT helper: encode, decode, token-pair generation, refresh rotation.
 */
class Ontrack_JWT {

	/** @var int Access token lifetime in seconds. */
	const ACCESS_TOKEN_TTL = 3600; // 1 hour

	/** @var int Refresh token lifetime in seconds. */
	const REFRESH_TOKEN_TTL = 2592000; // 30 days

	/** @var string WP option name for the auto-generated signing secret. */
	const SECRET_OPTION = 'ontrack_jwt_secret';

	/** @var string User meta key for stored refresh token hash + expiry. */
	const META_REFRESH_TOKEN = 'ontrack_refresh_token';

	/** @var string User meta key for refresh token expiry timestamp (for cron query). */
	const META_REFRESH_TOKEN_EXPIRES = 'ontrack_refresh_token_expires';

	// -------------------------------------------------------------------------
	// Public API
	// -------------------------------------------------------------------------

	/**
	 * Encode a payload as a signed HS256 JWT.
	 * Always overwrites `iat`; callers must set `exp` before calling.
	 *
	 * @param array $payload Associative claims array. Must include 'exp'.
	 * @return string Signed JWT.
	 */
	public static function encode( array $payload ) {
		$payload['iat'] = time();

		$secret = self::get_secret();
		$header = self::base64url_encode( (string) wp_json_encode( array( 'alg' => 'HS256', 'typ' => 'JWT' ) ) );
		$body   = self::base64url_encode( (string) wp_json_encode( $payload ) );
		$sig    = self::base64url_encode( hash_hmac( 'sha256', $header . '.' . $body, $secret, true ) );

		return $header . '.' . $body . '.' . $sig;
	}

	/**
	 * Decode and verify a JWT.
	 *
	 * @param string $token Raw JWT string.
	 * @return array|WP_Error Payload on success; WP_Error with code jwt_invalid or jwt_expired on failure.
	 */
	public static function decode( $token ) {
		$parts = explode( '.', (string) $token );
		if ( 3 !== count( $parts ) ) {
			return new WP_Error( 'jwt_invalid', __( 'Malformed token.', 'ontrack' ), array( 'status' => 401 ) );
		}

		list( $header, $body, $sig ) = $parts;

		$secret   = self::get_secret();
		$expected = self::base64url_encode( hash_hmac( 'sha256', $header . '.' . $body, $secret, true ) );
		if ( ! hash_equals( $expected, $sig ) ) {
			return new WP_Error( 'jwt_invalid', __( 'Invalid token signature.', 'ontrack' ), array( 'status' => 401 ) );
		}

		$payload = json_decode( self::base64url_decode( $body ), true );
		if ( ! is_array( $payload ) ) {
			return new WP_Error( 'jwt_invalid', __( 'Invalid token payload.', 'ontrack' ), array( 'status' => 401 ) );
		}

		if ( isset( $payload['exp'] ) && (int) $payload['exp'] < time() ) {
			return new WP_Error( 'jwt_expired', __( 'Token has expired.', 'ontrack' ), array( 'status' => 401 ) );
		}

		return $payload;
	}

	/**
	 * Issue a fresh access + refresh token pair for a user.
	 * Stores a hash of the refresh token in user meta; rotates on every call.
	 *
	 * @param WP_User $user
	 * @return array{ access_token: string, refresh_token: string, expires_in: int }
	 */
	public static function generate_token_pair( WP_User $user ) {
		$now = time();

		$access_token = self::encode( array(
			'sub'   => $user->ID,
			'email' => $user->user_email,
			'exp'   => $now + self::ACCESS_TOKEN_TTL,
		) );

		$raw_token     = bin2hex( random_bytes( 32 ) );
		$refresh_token = $user->ID . ':' . $raw_token;
		$refresh_hash  = hash( 'sha256', $raw_token );
		$expires       = $now + self::REFRESH_TOKEN_TTL;

		update_user_meta( $user->ID, self::META_REFRESH_TOKEN, array(
			'token_hash' => $refresh_hash,
			'expires'    => $expires,
		) );
		update_user_meta( $user->ID, self::META_REFRESH_TOKEN_EXPIRES, $expires );

		return array(
			'access_token'  => $access_token,
			'refresh_token' => $refresh_token,
			'expires_in'    => self::ACCESS_TOKEN_TTL,
		);
	}

	/**
	 * Validate a refresh token and rotate it (issues a new token pair).
	 * Token format: "{user_id}:{random_hex}" — user ID prefix lets us look up the right meta row.
	 *
	 * @param string $token Opaque refresh token from the client.
	 * @return array|WP_Error New token pair on success; WP_Error on failure.
	 */
	public static function rotate_refresh_token( $token ) {
		$parts = explode( ':', (string) $token, 2 );
		if ( 2 !== count( $parts ) || '' === $parts[0] || '' === $parts[1] ) {
			return new WP_Error( 'jwt_invalid', __( 'Invalid refresh token.', 'ontrack' ), array( 'status' => 401 ) );
		}

		$user_id = (int) $parts[0];
		if ( $user_id <= 0 ) {
			return new WP_Error( 'jwt_invalid', __( 'Invalid refresh token.', 'ontrack' ), array( 'status' => 401 ) );
		}

		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return new WP_Error( 'jwt_invalid', __( 'Invalid refresh token.', 'ontrack' ), array( 'status' => 401 ) );
		}

		$stored = get_user_meta( $user_id, self::META_REFRESH_TOKEN, true );
		if ( ! is_array( $stored ) || empty( $stored['token_hash'] ) || empty( $stored['expires'] ) ) {
			return new WP_Error( 'jwt_invalid', __( 'Refresh token not found.', 'ontrack' ), array( 'status' => 401 ) );
		}

		if ( (int) $stored['expires'] < time() ) {
			return new WP_Error( 'jwt_expired', __( 'Refresh token has expired.', 'ontrack' ), array( 'status' => 401 ) );
		}

		if ( ! hash_equals( $stored['token_hash'], hash( 'sha256', $parts[1] ) ) ) {
			return new WP_Error( 'jwt_invalid', __( 'Invalid refresh token.', 'ontrack' ), array( 'status' => 401 ) );
		}

		return self::generate_token_pair( $user );
	}

	/**
	 * Revoke a user's refresh token (logout or forced invalidation).
	 *
	 * @param int $user_id
	 */
	public static function revoke_refresh_token( $user_id ) {
		$user_id = (int) $user_id;
		delete_user_meta( $user_id, self::META_REFRESH_TOKEN );
		delete_user_meta( $user_id, self::META_REFRESH_TOKEN_EXPIRES );
	}

	/**
	 * Ensure a signing secret exists; generate and store one if not.
	 * Called during plugin activation.
	 */
	public static function ensure_secret() {
		if ( self::using_constant() ) {
			return; // Constant overrides everything; nothing to store.
		}
		if ( '' === (string) get_option( self::SECRET_OPTION, '' ) ) {
			self::generate_and_store_secret();
		}
	}

	/**
	 * Regenerate the stored signing secret, invalidating all existing tokens.
	 * No-op when a constant override is in use (can't overwrite a constant).
	 *
	 * @return bool True if regenerated; false if constant is in use.
	 */
	public static function regenerate_secret() {
		if ( self::using_constant() ) {
			return false;
		}
		self::generate_and_store_secret();
		return true;
	}

	/**
	 * Whether the KCFA_JWT_SECRET constant is defined and non-empty.
	 *
	 * @return bool
	 */
	public static function using_constant() {
		return defined( 'KCFA_JWT_SECRET' ) && '' !== KCFA_JWT_SECRET;
	}

	/**
	 * Short fingerprint of the active secret for display in the settings UI.
	 * Safe to show — it is a hash of the secret, not the secret itself.
	 *
	 * @return string 8-character hex string.
	 */
	public static function get_secret_fingerprint() {
		return substr( hash( 'sha256', self::get_secret() ), 0, 8 );
	}

	// -------------------------------------------------------------------------
	// Internal helpers
	// -------------------------------------------------------------------------

	/**
	 * Return the active signing secret, auto-generating it on first use.
	 *
	 * @return string
	 */
	private static function get_secret() {
		if ( self::using_constant() ) {
			return KCFA_JWT_SECRET;
		}
		$stored = (string) get_option( self::SECRET_OPTION, '' );
		if ( '' !== $stored ) {
			return $stored;
		}
		// Fallback: generate here if activate() was somehow skipped.
		return self::generate_and_store_secret();
	}

	/**
	 * @return string The newly stored secret.
	 */
	private static function generate_and_store_secret() {
		$secret = wp_generate_password( 64, true, true );
		update_option( self::SECRET_OPTION, $secret, false ); // no autoload
		return $secret;
	}

	private static function base64url_encode( $data ) {
		return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' );
	}

	private static function base64url_decode( $data ) {
		return base64_decode( strtr( (string) $data, '-_', '+/' ) );
	}
}
