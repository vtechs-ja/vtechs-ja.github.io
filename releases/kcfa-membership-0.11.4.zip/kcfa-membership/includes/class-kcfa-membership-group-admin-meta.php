<?php
/**
 * Group edit screen: demographic rule metabox.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Demographics metabox for the group CPT.
 */
class Ontrack_Group_Admin_Meta {

	const NONCE_ACTION = 'ontrack_save_group_demographics';
	const NONCE_FIELD  = 'ontrack_group_demographics_nonce';

	/**
	 * Register hooks.
	 */
	public function register() {
		add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
		add_action( 'save_post_' . ontrack_group_post_type(), array( $this, 'save_post' ), 10, 3 );
		add_action( 'admin_notices', array( $this, 'maybe_admin_notice_demographics_error' ) );
	}

	/**
	 * Add metabox.
	 */
	public function add_meta_box() {
		add_meta_box(
			'kcfa_group_demographics',
			__( 'Demographic expectations', 'ontrack' ),
			array( $this, 'render_metabox' ),
			ontrack_group_post_type(),
			'normal',
			'default'
		);
	}

	/**
	 * Render fields.
	 *
	 * @param WP_Post $post Post.
	 */
	public function render_metabox( $post ) {
		wp_nonce_field( self::NONCE_ACTION, self::NONCE_FIELD );
		$frag = ontrack_get_group_own_demographics( $post->ID );
		$parent_id = (int) $post->post_parent;
		if ( $parent_id > 0 ) {
			$peff = ontrack_get_effective_group_demographics( $parent_id );
			echo '<p class="description">';
			esc_html_e( 'Parent effective rule (for reference):', 'ontrack' );
			echo ' ';
			echo esc_html( wp_json_encode( $peff ) );
			echo '</p>';
		}
		?>
		<p class="description"><?php esc_html_e( 'Leave fields blank to inherit from parent (age/gender). Values here narrow the parent’s range; they cannot contradict it.', 'ontrack' ); ?></p>
		<p>
			<label for="ontrack_grp_age_min"><?php esc_html_e( 'Minimum age (years)', 'ontrack' ); ?></label><br />
			<input type="number" name="ontrack_grp_age_min" id="ontrack_grp_age_min" class="small-text" min="0" max="150" step="1" value="<?php echo null !== $frag['age_min'] ? (int) $frag['age_min'] : ''; ?>" placeholder="—" />
		</p>
		<p>
			<label for="ontrack_grp_age_max"><?php esc_html_e( 'Maximum age (years)', 'ontrack' ); ?></label><br />
			<input type="number" name="ontrack_grp_age_max" id="ontrack_grp_age_max" class="small-text" min="0" max="150" step="1" value="<?php echo null !== $frag['age_max'] ? (int) $frag['age_max'] : ''; ?>" placeholder="—" />
		</p>
		<p>
			<label for="ontrack_grp_gender"><?php esc_html_e( 'Gender expectation', 'ontrack' ); ?></label><br />
			<select name="ontrack_grp_gender" id="ontrack_grp_gender">
				<option value="" <?php selected( $frag['gender'], '' ); ?>><?php esc_html_e( '— Not specified (inherit) —', 'ontrack' ); ?></option>
				<option value="female" <?php selected( $frag['gender'], 'female' ); ?>><?php esc_html_e( 'Female', 'ontrack' ); ?></option>
				<option value="male" <?php selected( $frag['gender'], 'male' ); ?>><?php esc_html_e( 'Male', 'ontrack' ); ?></option>
			</select>
		</p>
		<?php
	}

	/**
	 * Save demographics meta.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post.
	 * @param bool    $update  Update.
	 */
	public function save_post( $post_id, $post, $update ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 || wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}
		if ( ! isset( $_POST[ self::NONCE_FIELD ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE_FIELD ] ) ), self::NONCE_ACTION ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$raw = array(
			'age_min' => isset( $_POST['ontrack_grp_age_min'] ) && '' !== $_POST['ontrack_grp_age_min'] ? (int) $_POST['ontrack_grp_age_min'] : null,
			'age_max' => isset( $_POST['ontrack_grp_age_max'] ) && '' !== $_POST['ontrack_grp_age_max'] ? (int) $_POST['ontrack_grp_age_max'] : null,
			'gender'  => isset( $_POST['ontrack_grp_gender'] ) ? sanitize_key( wp_unslash( $_POST['ontrack_grp_gender'] ) ) : '',
		);
		if ( '' !== $raw['gender'] && 'male' !== $raw['gender'] && 'female' !== $raw['gender'] ) {
			$raw['gender'] = '';
		}
		$fragment = ontrack_sanitize_demographics_fragment( $raw );

		$parent_id = (int) wp_get_post_parent_id( $post_id );
		if ( $parent_id > 0 ) {
			$parent_eff = ontrack_get_effective_group_demographics( $parent_id );
			$valid      = ontrack_validate_demographics_fragment_vs_parent( $parent_eff, $fragment );
			if ( is_wp_error( $valid ) ) {
				set_transient(
					'ontrack_group_demo_err_' . get_current_user_id(),
					$valid->get_error_message(),
					60
				);
				return;
			}
		}

		$json = wp_json_encode( $fragment );
		if ( wp_json_encode( ontrack_demographics_empty() ) === $json || '{"age_min":null,"age_max":null,"gender":""}' === $json ) {
			delete_post_meta( $post_id, ontrack_group_demographics_meta_key() );
		} else {
			update_post_meta( $post_id, ontrack_group_demographics_meta_key(), $json );
		}
	}

	/**
	 * Show validation error after failed demographics save.
	 */
	public function maybe_admin_notice_demographics_error() {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return;
		}
		$screen = get_current_screen();
		if ( ! $screen || ontrack_group_post_type() !== $screen->id ) {
			return;
		}
		$key = 'ontrack_group_demo_err_' . get_current_user_id();
		$msg = get_transient( $key );
		if ( ! is_string( $msg ) || '' === $msg ) {
			return;
		}
		delete_transient( $key );
		echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( $msg ) . '</p></div>';
	}
}
