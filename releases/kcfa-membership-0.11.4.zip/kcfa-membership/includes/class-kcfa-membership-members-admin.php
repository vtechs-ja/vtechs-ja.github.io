<?php
/**
 * KCFA Management → Members admin page.
 *
 * Scope-aware member list with bulk member-flag toggle.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and renders the Members submenu under KCFA Management.
 */
class Ontrack_Members_Admin {

	const PAGE_SLUG   = 'kcfa-management-members';
	const BULK_ACTION = 'ontrack_bulk_member_flag';
	const BULK_NONCE  = 'ontrack_bulk_member_flag';
	const PER_PAGE    = 50;

	/**
	 * Register hooks.
	 */
	public function register() {
		add_action( 'admin_menu', array( $this, 'add_submenu' ), 8 );
		add_action( 'admin_post_' . self::BULK_ACTION, array( $this, 'handle_bulk_action' ) );
	}

	/**
	 * Add Members submenu under KCFA Management.
	 */
	public function add_submenu() {
		if ( ! current_user_can( KCFA_CAP_VIEW_ROSTER ) ) {
			return;
		}
		add_submenu_page(
			ontrack_management_menu_slug(),
			__( 'Members', 'ontrack' ),
			__( 'Members', 'ontrack' ),
			KCFA_CAP_VIEW_ROSTER,
			self::PAGE_SLUG,
			array( $this, 'render_page' )
		);
	}

	/**
	 * Render the members list page.
	 */
	public function render_page() {
		if ( ! current_user_can( KCFA_CAP_VIEW_ROSTER ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'ontrack' ) );
		}

		$this->maybe_show_notices();

		// Filters from query string.
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$search      = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$role_filter = isset( $_GET['role_filter'] ) ? sanitize_key( wp_unslash( $_GET['role_filter'] ) ) : '';
		$paged       = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$can_edit_flag = current_user_can( KCFA_CAP_EDIT_MEMBERSHIP_FLAG );

		// Resolve scope.
		$actor_id  = get_current_user_id();
		$view_ids  = $this->get_viewable_member_ids( $actor_id );
		$edit_ids  = current_user_can( KCFA_CAP_MANAGE_GROUPS )
			? $view_ids
			: ontrack_get_user_management_scope( $actor_id )['edit'];

		// Build query args.
		$query_args = array(
			'fields'     => 'all',
			'number'     => self::PER_PAGE,
			'paged'      => $paged,
			'orderby'    => 'display_name',
			'order'      => 'ASC',
			'meta_query' => array(
				array(
					'key'   => ontrack_meta_key_is_member(),
					'value' => '1',
				),
			),
		);

		if ( ! empty( $view_ids ) && ! current_user_can( KCFA_CAP_MANAGE_GROUPS ) ) {
			$query_args['include'] = $view_ids;
		}

		if ( '' !== $search ) {
			$query_args['search']         = '*' . $search . '*';
			$query_args['search_columns'] = array( 'user_login', 'user_email', 'display_name' );
		}

		if ( '' !== $role_filter && get_role( $role_filter ) ) {
			$query_args['role'] = $role_filter;
		}

		$user_query = new WP_User_Query( $query_args );
		$users      = $user_query->get_results();
		$total      = (int) $user_query->get_total();
		$max_page   = $total > 0 ? (int) ceil( $total / self::PER_PAGE ) : 1;

		$page_url   = admin_url( 'admin.php?page=' . self::PAGE_SLUG );
		$roles_map  = $this->get_role_display_names();

		$pagination = paginate_links( array(
			'base'      => add_query_arg( 'paged', '%#%', $page_url ),
			'format'    => '',
			'current'   => $paged,
			'total'     => max( 1, $max_page ),
			'prev_text' => __( '&laquo;', 'ontrack' ),
			'next_text' => __( '&raquo;', 'ontrack' ),
		) );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Members', 'ontrack' ); ?></h1>
			<p class="description">
				<?php
				if ( current_user_can( KCFA_CAP_MANAGE_GROUPS ) ) {
					esc_html_e( 'All full members.', 'ontrack' );
				} else {
					esc_html_e( 'Full members within your management scope.', 'ontrack' );
				}
				?>
			</p>

			<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
				<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE_SLUG ); ?>" />
				<p class="search-box">
					<label class="screen-reader-text" for="ontrack-member-search"><?php esc_html_e( 'Search members', 'ontrack' ); ?></label>
					<input type="search" id="ontrack-member-search" name="s" value="<?php echo esc_attr( $search ); ?>" />
					&nbsp;
					<label class="screen-reader-text" for="ontrack-role-filter"><?php esc_html_e( 'Filter by role', 'ontrack' ); ?></label>
					<select name="role_filter" id="ontrack-role-filter">
						<option value=""><?php esc_html_e( '— All roles —', 'ontrack' ); ?></option>
						<?php foreach ( $roles_map as $slug => $label ) : ?>
							<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $role_filter, $slug ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
					&nbsp;
					<?php submit_button( __( 'Filter', 'ontrack' ), 'secondary', '', false ); ?>
				</p>
			</form>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::BULK_ACTION ); ?>" />
				<?php wp_nonce_field( self::BULK_NONCE, 'ontrack_bulk_member_nonce' ); ?>

				<?php if ( $can_edit_flag ) : ?>
				<div class="tablenav top">
					<div class="alignleft actions bulkactions">
						<label for="ontrack-bulk-action" class="screen-reader-text"><?php esc_html_e( 'Bulk action', 'ontrack' ); ?></label>
						<select name="bulk_op" id="ontrack-bulk-action">
							<option value=""><?php esc_html_e( 'Bulk action', 'ontrack' ); ?></option>
							<option value="set_member"><?php esc_html_e( 'Set as full member', 'ontrack' ); ?></option>
							<option value="unset_member"><?php esc_html_e( 'Remove full member flag', 'ontrack' ); ?></option>
						</select>
						<?php submit_button( __( 'Apply', 'ontrack' ), 'action', '', false ); ?>
					</div>
					<div class="tablenav-pages">
						<?php echo wp_kses_post( (string) $pagination ); ?>
					</div>
				</div>
				<?php endif; ?>

				<table class="widefat striped">
					<thead>
						<tr>
							<?php if ( $can_edit_flag ) : ?>
							<td class="manage-column column-cb check-column">
								<input id="ontrack-cb-select-all" type="checkbox" />
							</td>
							<?php endif; ?>
							<th scope="col"><?php esc_html_e( 'Name', 'ontrack' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Email', 'ontrack' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Role', 'ontrack' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Groups', 'ontrack' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if ( empty( $users ) ) : ?>
							<tr>
								<td colspan="<?php echo $can_edit_flag ? '5' : '4'; ?>">
									<?php esc_html_e( 'No members found.', 'ontrack' ); ?>
								</td>
							</tr>
						<?php else : ?>
							<?php foreach ( $users as $u ) : ?>
								<?php
								if ( ! $u instanceof WP_User ) {
									continue;
								}
								$can_edit_this = $can_edit_flag && in_array( $u->ID, $edit_ids, true );
								$group_ids     = ontrack_get_user_assigned_group_ids( $u->ID );
								$group_names   = array();
								foreach ( $group_ids as $gid ) {
									$title = get_the_title( $gid );
									if ( $title ) {
										$group_names[] = $title;
									}
								}
								$role_label = '';
								foreach ( (array) $u->roles as $r ) {
									if ( isset( $roles_map[ $r ] ) ) {
										$role_label = $roles_map[ $r ];
										break;
									}
								}
								?>
								<tr>
									<?php if ( $can_edit_flag ) : ?>
									<th scope="row" class="check-column">
										<?php if ( $can_edit_this ) : ?>
											<input type="checkbox" name="user_ids[]" value="<?php echo esc_attr( (string) $u->ID ); ?>" />
										<?php endif; ?>
									</th>
									<?php endif; ?>
									<td>
										<strong>
											<a href="<?php echo esc_url( get_edit_user_link( $u->ID ) ); ?>"><?php echo esc_html( $u->display_name ); ?></a>
										</strong>
										<span class="description">(<?php echo esc_html( $u->user_login ); ?>)</span>
									</td>
									<td><a href="mailto:<?php echo esc_attr( $u->user_email ); ?>"><?php echo esc_html( $u->user_email ); ?></a></td>
									<td><?php echo esc_html( $role_label ); ?></td>
									<td>
										<?php if ( empty( $group_names ) ) : ?>
											<span class="description"><?php esc_html_e( 'None', 'ontrack' ); ?></span>
										<?php else : ?>
											<?php echo esc_html( implode( ', ', $group_names ) ); ?>
										<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; ?>
						<?php endif; ?>
					</tbody>
				</table>

				<?php if ( $can_edit_flag && ! empty( $users ) ) : ?>
				<div class="tablenav bottom">
					<div class="tablenav-pages">
						<?php echo wp_kses_post( (string) $pagination ); ?>
					</div>
				</div>
				<?php endif; ?>
			</form>
		</div>
		<script>
		(function(){
			var all = document.getElementById('ontrack-cb-select-all');
			if (!all) return;
			all.addEventListener('change', function(){
				document.querySelectorAll('input[name="user_ids[]"]').forEach(function(cb){
					cb.checked = all.checked;
				});
			});
		})();
		</script>
		<?php
	}

	/**
	 * Handle bulk member flag toggle.
	 */
	public function handle_bulk_action() {
		if ( ! current_user_can( KCFA_CAP_EDIT_MEMBERSHIP_FLAG ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'ontrack' ) );
		}
		check_admin_referer( self::BULK_NONCE, 'ontrack_bulk_member_nonce' );

		$op       = isset( $_POST['bulk_op'] ) ? sanitize_key( wp_unslash( $_POST['bulk_op'] ) ) : '';
		$user_ids = isset( $_POST['user_ids'] ) ? array_map( 'intval', (array) wp_unslash( $_POST['user_ids'] ) ) : array();

		if ( ! in_array( $op, array( 'set_member', 'unset_member' ), true ) || empty( $user_ids ) ) {
			wp_safe_redirect( add_query_arg( 'error', '1', admin_url( 'admin.php?page=' . self::PAGE_SLUG ) ) );
			exit;
		}

		$actor_id  = get_current_user_id();
		$edit_ids  = ontrack_get_user_management_scope( $actor_id )['edit'];
		$value     = ( 'set_member' === $op ) ? '1' : '0';
		$updated   = 0;

		foreach ( $user_ids as $uid ) {
			if ( $uid <= 0 ) {
				continue;
			}
			if ( ! current_user_can( KCFA_CAP_MANAGE_GROUPS ) && ! in_array( $uid, $edit_ids, true ) ) {
				continue;
			}
			update_user_meta( $uid, ontrack_meta_key_is_member(), $value );
			++$updated;
		}

		wp_safe_redirect( add_query_arg(
			array( 'page' => self::PAGE_SLUG, 'updated' => $updated ),
			admin_url( 'admin.php' )
		) );
		exit;
	}

	// -------------------------------------------------------------------------
	// Internal helpers
	// -------------------------------------------------------------------------

	/**
	 * User IDs of full members visible to the actor.
	 *
	 * @param int $actor_id
	 * @return int[] Empty means "query without include restriction" (full scope).
	 */
	private function get_viewable_member_ids( $actor_id ) {
		if ( current_user_can( KCFA_CAP_MANAGE_GROUPS ) ) {
			return array(); // Unrestricted; WP_User_Query will use meta_query only.
		}
		$scope = ontrack_get_user_management_scope( $actor_id );
		return $scope['view'];
	}

	/**
	 * Role slug → display name map for all registered roles.
	 *
	 * @return array<string, string>
	 */
	private function get_role_display_names() {
		$wp_roles = wp_roles();
		$out      = array();
		foreach ( $wp_roles->roles as $slug => $data ) {
			$out[ $slug ] = translate_user_role( $data['name'] );
		}
		return $out;
	}

	/**
	 * Show updated/error notices.
	 */
	private function maybe_show_notices() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( ! empty( $_GET['updated'] ) ) {
			$n = (int) $_GET['updated'];
			echo '<div class="notice notice-success is-dismissible"><p>';
			echo esc_html( sprintf(
				/* translators: %d: number of users updated */
				_n( '%d member updated.', '%d members updated.', $n, 'ontrack' ),
				$n
			) );
			echo '</p></div>';
		}
		if ( ! empty( $_GET['error'] ) ) {
			echo '<div class="notice notice-error is-dismissible"><p>';
			esc_html_e( 'No changes applied. Select users and a valid bulk action.', 'ontrack' );
			echo '</p></div>';
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
	}
}
