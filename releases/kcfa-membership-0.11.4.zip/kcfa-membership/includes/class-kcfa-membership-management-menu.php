<?php
/**
 * Top-level KCFA Management menu: overview, nested Groups, group rosters, mismatch home.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers admin menu and custom pages under KCFA Management.
 */
class Ontrack_Management_Menu {

	const PAGE_ASSIGN = 'kcfa-management-assign';

	const PAGE_MISMATCHES = 'kcfa-management-mismatches';

	/** @var int Users per WP_User_Query page on Demographic mismatches report. */
	const MISMATCH_REPORT_PER_PAGE = 50;

	const ROSTER_ACTION = 'ontrack_roster';

	const ROSTER_NONCE = 'ontrack_roster';

	/**
	 * Register hooks.
	 */
	public function register() {
		add_action( 'admin_menu', array( $this, 'add_parent_menu' ), 3 );
		add_action( 'admin_menu', array( $this, 'remove_duplicate_submenu' ), 8 );
		add_action( 'admin_menu', array( $this, 'add_tool_submenus' ), 9 );
		add_action( 'admin_post_' . self::ROSTER_ACTION, array( $this, 'handle_roster_post' ) );
	}

	/**
	 * Top-level menu (before CPT submenu at priority 5).
	 */
	public function add_parent_menu() {
		if ( ! current_user_can( 'edit_kcfa_groups' ) ) {
			return;
		}
		add_menu_page(
			__( 'KCFA Management', 'ontrack' ),
			__( 'KCFA Management', 'ontrack' ),
			'edit_kcfa_groups',
			ontrack_management_menu_slug(),
			array( $this, 'render_overview' ),
			'dashicons-groups',
			26
		);
	}

	/**
	 * Remove auto-added duplicate of parent as first submenu.
	 */
	public function remove_duplicate_submenu() {
		$slug = ontrack_management_menu_slug();
		remove_submenu_page( $slug, $slug );
	}

	/**
	 * Group rosters and Demographic mismatches submenus.
	 */
	public function add_tool_submenus() {
		if ( ! current_user_can( 'edit_kcfa_groups' ) ) {
			return;
		}
		add_submenu_page(
			ontrack_management_menu_slug(),
			__( 'Group rosters', 'ontrack' ),
			__( 'Group rosters', 'ontrack' ),
			'edit_kcfa_groups',
			self::PAGE_ASSIGN,
			array( $this, 'render_group_rosters' )
		);
		add_submenu_page(
			ontrack_management_menu_slug(),
			__( 'Demographic mismatches', 'ontrack' ),
			__( 'Demographic mismatches', 'ontrack' ),
			'edit_kcfa_groups',
			self::PAGE_MISMATCHES,
			array( $this, 'render_mismatches' )
		);
	}

	/**
	 * Overview landing with links to each area.
	 */
	public function render_overview() {
		if ( ! current_user_can( 'edit_kcfa_groups' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'ontrack' ) );
		}
		$groups_url   = admin_url( 'edit.php?post_type=' . ontrack_group_post_type() );
		$rosters_url  = admin_url( 'admin.php?page=' . self::PAGE_ASSIGN );
		$mismatch_url = admin_url( 'admin.php?page=' . self::PAGE_MISMATCHES );
		$settings_url = admin_url( 'options-general.php?page=kcfa-membership' );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'KCFA Management', 'ontrack' ); ?></h1>
			<p class="description"><?php esc_html_e( 'Manage membership groups, assign users by group, and review demographic mismatches.', 'ontrack' ); ?></p>
			<ul class="ontrack-management-overview" style="list-style: disc; margin-left: 1.5em; max-width: 40em;">
				<li>
					<a href="<?php echo esc_url( $groups_url ); ?>"><?php esc_html_e( 'Groups', 'ontrack' ); ?></a>
					— <?php esc_html_e( 'Create and edit hierarchical groups and their demographic expectations.', 'ontrack' ); ?>
				</li>
				<li>
					<a href="<?php echo esc_url( $rosters_url ); ?>"><?php esc_html_e( 'Group rosters', 'ontrack' ); ?></a>
					— <?php esc_html_e( 'Master–detail rosters: pick a group on the left, manage members on the right. Use Roster on the Groups list for a shortcut.', 'ontrack' ); ?>
				</li>
				<li>
					<a href="<?php echo esc_url( $mismatch_url ); ?>"><?php esc_html_e( 'Demographic mismatches', 'ontrack' ); ?></a>
					— <?php esc_html_e( 'Site-wide list of assignment conflicts with profile data.', 'ontrack' ); ?>
				</li>
				<?php if ( current_user_can( 'manage_options' ) ) : ?>
				<li>
					<a href="<?php echo esc_url( $settings_url ); ?>"><?php esc_html_e( 'KCFA Membership settings', 'ontrack' ); ?></a>
					— <?php esc_html_e( 'Minimum role for member flag and group management.', 'ontrack' ); ?>
				</li>
				<?php endif; ?>
			</ul>
		</div>
		<?php
	}

	/**
	 * Group-centric roster: master–detail (groups + Unassigned left, roster + add right).
	 */
	public function render_group_rosters() {
		if ( ! current_user_can( 'edit_kcfa_groups' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'ontrack' ) );
		}

		if ( ! empty( $_GET['updated'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Roster updated.', 'ontrack' ) . '</p></div>';
		}
		if ( ! empty( $_GET['error'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__( 'Could not apply that change (permission, invalid user, or invalid group).', 'ontrack' ) . '</p></div>';
		}

		$group_id   = isset( $_GET['group_id'] ) ? (int) $_GET['group_id'] : ontrack_unassigned_group_sentinel(); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$unassigned = ontrack_is_unassigned_group_context( $group_id );

		if ( ! $unassigned ) {
			$post = get_post( $group_id );
			if ( ! $post || ontrack_group_post_type() !== $post->post_type || 'publish' !== $post->post_status ) {
				echo '<div class="notice notice-error"><p>' . esc_html__( 'Invalid or unpublished group.', 'ontrack' ) . '</p></div>';
				$group_id   = ontrack_unassigned_group_sentinel();
				$unassigned = true;
			}
		}

		$group_options = ontrack_get_group_select_options();
		$manageable    = ontrack_get_manageable_user_ids_for_group_roster( 500 );

		if ( $unassigned ) {
			$member_ids = ontrack_get_roster_unassigned_user_ids( 500 );
		} else {
			$member_ids = ontrack_get_user_ids_assigned_to_group( $group_id, array( 'number' => 500 ) );
		}

		$page_url   = admin_url( 'admin.php?page=' . self::PAGE_ASSIGN );
		$post_url   = admin_url( 'admin-post.php' );
		$roster_key = 'ontrack_roster_nonce';

		$unassigned_nav_count = ontrack_count_roster_unassigned_for_nav();
		?>
		<div class="wrap ontrack-roster-wrap">
			<h1><?php esc_html_e( 'Group rosters', 'ontrack' ); ?></h1>
			<p class="description"><?php esc_html_e( 'Pick a group on the left. Counts reflect direct assignments in the directory (500+ when very large). The table lists users you are allowed to edit, up to 500 rows.', 'ontrack' ); ?></p>

			<style>
				.ontrack-roster-layout { display: flex; gap: 1.5rem; align-items: flex-start; max-width: 100%; margin-top: 1em; }
				.ontrack-roster-nav { flex: 0 0 280px; border: 1px solid #c3c4c7; background: #fff; margin: 0; padding: 0; box-shadow: 0 1px 1px rgba(0,0,0,.04); }
				.ontrack-roster-nav ul { list-style: none; margin: 0; padding: 0; }
				.ontrack-roster-nav li { margin: 0; border-bottom: 1px solid #dcdcde; }
				.ontrack-roster-nav li:last-child { border-bottom: none; }
				.ontrack-roster-nav a { display: block; padding: 10px 12px; text-decoration: none; color: #2c3338; }
				.ontrack-roster-nav a:hover, .ontrack-roster-nav a:focus { background: #f6f7f7; color: #2c3338; box-shadow: none; }
				.ontrack-roster-nav li.is-active a { font-weight: 600; background: #f0f0f1; box-shadow: inset 3px 0 0 var(--wp-admin-theme-color, #2271b1); }
				.ontrack-roster-nav .ontrack-roster-count { color: #646970; font-weight: 400; }
				.ontrack-roster-main { flex: 1; min-width: 0; }
				.ontrack-roster-main h2 { margin-top: 0; padding-top: 0; }
				@media (max-width: 782px) {
					.ontrack-roster-layout { flex-direction: column; }
					.ontrack-roster-nav { flex-basis: auto; width: 100%; }
				}
			</style>

			<div class="ontrack-roster-layout">
				<nav class="ontrack-roster-nav" aria-label="<?php esc_attr_e( 'Groups', 'ontrack' ); ?>">
					<ul>
						<li class="<?php echo $unassigned ? 'is-active' : ''; ?>">
							<a href="<?php echo esc_url( add_query_arg( 'group_id', '0', $page_url ) ); ?>">
								<?php esc_html_e( 'Unassigned', 'ontrack' ); ?>
								<span class="ontrack-roster-count">(<?php echo esc_html( $unassigned_nav_count ); ?>)</span>
							</a>
						</li>
						<?php foreach ( $group_options as $gid => $label ) : ?>
							<?php
							$gid   = (int) $gid;
							$total = ontrack_count_users_assigned_to_group( $gid );
							$disp  = ontrack_format_roster_nav_count( $total );
							$href  = add_query_arg( 'group_id', (string) $gid, $page_url );
							?>
							<li class="<?php echo ( ! $unassigned && (int) $group_id === $gid ) ? 'is-active' : ''; ?>">
								<a href="<?php echo esc_url( $href ); ?>">
									<?php echo esc_html( $label ); ?>
									<span class="ontrack-roster-count">(<?php echo esc_html( $disp ); ?>)</span>
								</a>
							</li>
						<?php endforeach; ?>
					</ul>
				</nav>

				<div class="ontrack-roster-main">
					<?php if ( $unassigned ) : ?>
						<h2><?php esc_html_e( 'Unassigned (no groups)', 'ontrack' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Accounts you can manage that have no direct group assignment. Full-member status is separate (user profile).', 'ontrack' ); ?></p>
					<?php else : ?>
						<h2><?php echo esc_html( get_the_title( $group_id ) ); ?></h2>
						<p class="description">
							<?php esc_html_e( 'Direct members only (not implicit parent/child access from Phase 7).', 'ontrack' ); ?>
						</p>
						<?php
						$eff = ontrack_get_effective_group_demographics( $group_id );
						echo '<p class="description">';
						esc_html_e( 'Effective demographic rule:', 'ontrack' );
						echo ' ';
						echo esc_html( ontrack_format_demographics_age_range_for_display( $eff ) );
						echo ' · ';
						echo esc_html( ontrack_format_demographics_gender_for_display( $eff ) );
						echo '</p>';
						?>
					<?php endif; ?>

					<?php if ( ! empty( $manageable ) && ! empty( $group_options ) ) : ?>
						<?php if ( $unassigned ) : ?>
							<h3><?php esc_html_e( 'Assign to groups', 'ontrack' ); ?></h3>
							<p class="description"><?php esc_html_e( 'Choose a user and one or more groups.', 'ontrack' ); ?></p>
							<form method="post" action="<?php echo esc_url( $post_url ); ?>" class="ontrack-roster-add-unassigned">
								<input type="hidden" name="action" value="<?php echo esc_attr( self::ROSTER_ACTION ); ?>" />
								<input type="hidden" name="ontrack_roster_op" value="assign_unassigned" />
								<input type="hidden" name="roster_group_id" value="0" />
								<?php wp_nonce_field( self::ROSTER_NONCE, $roster_key ); ?>
								<p>
									<label for="roster_add_user_id_unassigned"><?php esc_html_e( 'User', 'ontrack' ); ?></label><br />
									<?php
									wp_dropdown_users(
										array(
											'name'             => 'roster_add_user_id',
											'id'               => 'roster_add_user_id_unassigned',
											'show_option_none' => __( '— Select a user —', 'ontrack' ),
											'include'          => $manageable,
											'orderby'          => 'display_name',
											'order'            => 'ASC',
										)
									);
									?>
								</p>
								<p>
									<label for="ontrack_roster_groups_unassigned"><?php esc_html_e( 'Groups', 'ontrack' ); ?></label><br />
									<select name="ontrack_user_group_ids[]" id="ontrack_roster_groups_unassigned" multiple="multiple" size="8" style="min-width:22em;">
										<?php foreach ( $group_options as $gid => $label ) : ?>
											<option value="<?php echo esc_attr( (string) $gid ); ?>"><?php echo esc_html( $label ); ?></option>
										<?php endforeach; ?>
									</select>
								</p>
								<?php submit_button( __( 'Assign to groups', 'ontrack' ) ); ?>
							</form>
						<?php else : ?>
							<h3><?php esc_html_e( 'Add to this group', 'ontrack' ); ?></h3>
							<p class="description"><?php esc_html_e( 'Add a user you are allowed to edit. They may already belong to other groups.', 'ontrack' ); ?></p>
							<form method="post" action="<?php echo esc_url( $post_url ); ?>" class="ontrack-roster-add-member">
								<input type="hidden" name="action" value="<?php echo esc_attr( self::ROSTER_ACTION ); ?>" />
								<input type="hidden" name="ontrack_roster_op" value="add" />
								<input type="hidden" name="roster_group_id" value="<?php echo esc_attr( (string) $group_id ); ?>" />
								<?php wp_nonce_field( self::ROSTER_NONCE, $roster_key ); ?>
								<p>
									<label for="roster_add_user_id_member"><?php esc_html_e( 'User', 'ontrack' ); ?></label><br />
									<?php
									wp_dropdown_users(
										array(
											'name'             => 'roster_add_user_id',
											'id'               => 'roster_add_user_id_member',
											'show_option_none' => __( '— Select a user —', 'ontrack' ),
											'include'          => $manageable,
											'orderby'          => 'display_name',
											'order'            => 'ASC',
										)
									);
									?>
								</p>
								<?php submit_button( __( 'Add to this group', 'ontrack' ) ); ?>
							</form>
						<?php endif; ?>
					<?php elseif ( empty( $group_options ) ) : ?>
						<p class="description"><?php esc_html_e( 'Create published groups under KCFA Management → Groups before assigning members.', 'ontrack' ); ?></p>
					<?php endif; ?>

					<h3 style="margin-top:1.75em;"><?php esc_html_e( 'Roster', 'ontrack' ); ?></h3>
					<table class="widefat striped">
						<thead>
							<tr>
								<th scope="col"><?php esc_html_e( 'User', 'ontrack' ); ?></th>
								<th scope="col"><?php esc_html_e( 'Email', 'ontrack' ); ?></th>
								<th scope="col" class="column-actions"><?php esc_html_e( 'Actions', 'ontrack' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php if ( empty( $member_ids ) ) : ?>
								<tr>
									<td colspan="3">
										<?php
										if ( $unassigned ) {
											esc_html_e( 'No unassigned users in this list, or none you can manage.', 'ontrack' );
										} else {
											esc_html_e( 'No users in this group that you can manage, or the roster is empty.', 'ontrack' );
										}
										?>
									</td>
								</tr>
							<?php else : ?>
								<?php foreach ( $member_ids as $uid ) : ?>
									<?php
									$u = get_userdata( $uid );
									if ( ! $u ) {
										continue;
									}
									$edit_link = admin_url( 'user-edit.php?user_id=' . (int) $uid );
									?>
									<tr>
										<td>
											<strong><?php echo esc_html( $u->display_name ); ?></strong>
											<span class="description">(<?php echo esc_html( $u->user_login ); ?>)</span>
										</td>
										<td><a href="mailto:<?php echo esc_attr( $u->user_email ); ?>"><?php echo esc_html( $u->user_email ); ?></a></td>
										<td>
											<a href="<?php echo esc_url( $edit_link ); ?>"><?php esc_html_e( 'Edit user', 'ontrack' ); ?></a>
											<?php if ( ! $unassigned ) : ?>
												<span class="description"> | </span>
												<form method="post" action="<?php echo esc_url( $post_url ); ?>" style="display:inline;">
													<input type="hidden" name="action" value="<?php echo esc_attr( self::ROSTER_ACTION ); ?>" />
													<input type="hidden" name="ontrack_roster_op" value="remove" />
													<input type="hidden" name="roster_group_id" value="<?php echo esc_attr( (string) $group_id ); ?>" />
													<input type="hidden" name="roster_user_id" value="<?php echo esc_attr( (string) $uid ); ?>" />
													<?php wp_nonce_field( self::ROSTER_NONCE, $roster_key ); ?>
													<button type="submit" class="button-link-delete"><?php esc_html_e( 'Remove', 'ontrack' ); ?></button>
												</form>
											<?php endif; ?>
										</td>
									</tr>
								<?php endforeach; ?>
							<?php endif; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Site-wide demographic mismatch report (paginated over users with group assignments).
	 *
	 * Performance: each page runs mismatch logic for up to {@see self::MISMATCH_REPORT_PER_PAGE} users.
	 * Very large sites may later need batching or transient caching; MVP uses user-query pagination only.
	 */
	public function render_mismatches() {
		if ( ! current_user_can( 'edit_kcfa_groups' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'ontrack' ) );
		}

		$per_page = self::MISMATCH_REPORT_PER_PAGE;
		$paged    = isset( $_GET['paged'] ) ? max( 1, (int) wp_unslash( $_GET['paged'] ) ) : 1;

		$user_query = new WP_User_Query(
			array(
				'meta_key'     => ontrack_user_group_ids_meta_key(),
				'meta_compare' => 'EXISTS',
				'number'       => $per_page,
				'paged'        => $paged,
				'orderby'      => 'display_name',
				'order'        => 'ASC',
				'fields'       => 'all',
			)
		);

		$users    = $user_query->get_results();
		$total_q  = (int) $user_query->get_total();
		$max_page = $total_q > 0 ? (int) ceil( $total_q / $per_page ) : 1;

		$rows = array();
		foreach ( $users as $u ) {
			if ( ! $u instanceof WP_User ) {
				continue;
			}
			if ( ! ontrack_current_user_can_manage_user_groups( $u->ID ) ) {
				continue;
			}
			$mismatches = ontrack_get_demographic_mismatches_for_user( $u->ID );
			if ( empty( $mismatches ) ) {
				continue;
			}
			$rows[] = array(
				'user'       => $u,
				'mismatches' => $mismatches,
			);
		}

		$pagination = paginate_links(
			array(
				'base'      => add_query_arg( 'paged', '%#%', admin_url( 'admin.php?page=' . self::PAGE_MISMATCHES ) ),
				'format'    => '',
				'current'   => $paged,
				'total'     => max( 1, $max_page ),
				'prev_text' => __( '&laquo;', 'ontrack' ),
				'next_text' => __( '&raquo;', 'ontrack' ),
			)
		);

		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Demographic mismatches', 'ontrack' ); ?></h1>
			<p class="description">
				<?php esc_html_e( 'Users below have at least one assigned group whose effective demographic rule conflicts with their profile. Acknowledged items still appear, with a badge.', 'ontrack' ); ?>
			</p>
			<?php if ( empty( $rows ) && $total_q === 0 ) : ?>
				<p><?php esc_html_e( 'No users are assigned to any group yet.', 'ontrack' ); ?></p>
			<?php elseif ( empty( $rows ) ) : ?>
				<p>
					<?php
					printf(
						/* translators: %d: page number */
						esc_html__( 'No mismatches found among users you can manage on this results page (page %d). Try another page or add assignments.', 'ontrack' ),
						(int) $paged
					);
					?>
				</p>
			<?php else : ?>
				<table class="widefat striped">
					<thead>
						<tr>
							<th scope="col"><?php esc_html_e( 'User', 'ontrack' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Groups / issues', 'ontrack' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Summary', 'ontrack' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Profile', 'ontrack' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $rows as $block ) : ?>
							<?php
							$u          = $block['user'];
							$mismatches = $block['mismatches'];
							$edit_url   = get_edit_user_link( $u->ID );
							$titles = array();
							$ack_ct = 0;
							foreach ( $mismatches as $m ) {
								$titles[] = $m['group_title'];
								if ( ! empty( $m['acknowledged'] ) ) {
									++$ack_ct;
								}
							}
							$group_cell = esc_html(
								sprintf(
									/* translators: 1: number of groups with issues, 2: comma-separated group names */
									_n( '%1$d group: %2$s', '%1$d groups: %2$s', count( $mismatches ), 'ontrack' ),
									count( $mismatches ),
									implode( __( ', ', 'ontrack' ), $titles )
								)
							);
							$first_reason = isset( $mismatches[0]['reasons'][0] ) ? $mismatches[0]['reasons'][0] : '';
							$summary      = wp_html_excerpt( $first_reason, 120, '…' );
							?>
							<tr>
								<td>
									<strong><?php echo esc_html( $u->display_name ); ?></strong>
									<span class="description">(<?php echo esc_html( $u->user_login ); ?>)</span>
								</td>
								<td>
									<?php echo $group_cell; ?>
									<?php if ( $ack_ct > 0 ) : ?>
										<br /><span class="ontrack-mismatch-badge"><?php echo esc_html( sprintf( /* translators: %d: count */ _n( '%d acknowledged', '%d acknowledged', $ack_ct, 'ontrack' ), $ack_ct ) ); ?></span>
									<?php endif; ?>
								</td>
								<td><?php echo esc_html( $summary ); ?></td>
								<td>
									<?php if ( $edit_url ) : ?>
										<a href="<?php echo esc_url( $edit_url ); ?>"><?php esc_html_e( 'View profile', 'ontrack' ); ?></a>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
			<?php if ( $pagination ) : ?>
				<div class="tablenav"><div class="tablenav-pages"><?php echo wp_kses_post( $pagination ); ?></div></div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Roster add/remove/assign from Unassigned.
	 */
	public function handle_roster_post() {
		if ( ! current_user_can( 'edit_kcfa_groups' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'ontrack' ) );
		}
		check_admin_referer( self::ROSTER_NONCE, 'ontrack_roster_nonce' );

		$base     = admin_url( 'admin.php?page=' . self::PAGE_ASSIGN );
		$op       = isset( $_POST['ontrack_roster_op'] ) ? sanitize_key( wp_unslash( $_POST['ontrack_roster_op'] ) ) : '';
		$group_id = isset( $_POST['roster_group_id'] ) ? (int) $_POST['roster_group_id'] : 0;

		if ( 'remove' === $op ) {
			$user_id = isset( $_POST['roster_user_id'] ) ? (int) $_POST['roster_user_id'] : 0;
			$ok      = ( $group_id > 0 && $user_id > 0 && ontrack_remove_user_from_group( $user_id, $group_id ) );
			$args    = array( 'group_id' => $group_id );
			$args[ $ok ? 'updated' : 'error' ] = '1';
			wp_safe_redirect( add_query_arg( $args, $base ) );
			exit;
		}

		if ( 'add' === $op ) {
			$user_id = isset( $_POST['roster_add_user_id'] ) ? (int) $_POST['roster_add_user_id'] : 0;
			$ok      = ( $group_id > 0 && $user_id > 0 && ontrack_add_user_to_group( $user_id, $group_id ) );
			$args    = array( 'group_id' => $group_id );
			$args[ $ok ? 'updated' : 'error' ] = '1';
			wp_safe_redirect( add_query_arg( $args, $base ) );
			exit;
		}

		if ( 'assign_unassigned' === $op ) {
			$user_id = isset( $_POST['roster_add_user_id'] ) ? (int) $_POST['roster_add_user_id'] : 0;
			$raw     = isset( $_POST['ontrack_user_group_ids'] ) ? wp_unslash( $_POST['ontrack_user_group_ids'] ) : array();
			$new     = ontrack_sanitize_user_group_ids( $raw );
			$ok      = false;
			if ( $user_id > 0 && ! empty( $new ) ) {
				$cur    = ontrack_get_user_assigned_group_ids( $user_id );
				$merged = array_values( array_unique( array_merge( $cur, $new ) ) );
				$ok     = ontrack_set_user_assigned_group_ids( $user_id, $merged );
			}
			$args = array( 'group_id' => 0 );
			$args[ $ok ? 'updated' : 'error' ] = '1';
			wp_safe_redirect( add_query_arg( $args, $base ) );
			exit;
		}

		wp_safe_redirect( $base );
		exit;
	}
}
