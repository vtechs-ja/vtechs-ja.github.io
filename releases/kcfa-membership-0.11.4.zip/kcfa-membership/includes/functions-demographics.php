<?php
/**
 * Demographics user meta: keys, sanitization, getters.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * User meta: date of birth (Y-m-d or empty).
 *
 * @return string
 */
function ontrack_meta_key_date_of_birth() {
	return 'ontrack_date_of_birth';
}

/**
 * User meta: gender — `male` or `female` only (or empty if unset).
 *
 * @return string
 */
function ontrack_meta_key_gender() {
	return 'ontrack_gender';
}

/**
 * User meta: city (plain text).
 *
 * @return string
 */
function ontrack_meta_key_city() {
	return 'ontrack_city';
}

/**
 * User meta: country (plain text).
 *
 * @return string
 */
function ontrack_meta_key_country() {
	return 'ontrack_country';
}

/**
 * Gender: male / female labels only (empty key = not specified).
 *
 * @return array<string, string>
 */
function ontrack_gender_choices() {
	$choices = array(
		''       => __( '— Not specified —', 'ontrack' ),
		'female' => __( 'Female', 'ontrack' ),
		'male'   => __( 'Male', 'ontrack' ),
	);

	return apply_filters( 'ontrack_gender_choices', $choices );
}

/**
 * Whether the current user may edit demographics for the given profile.
 *
 * @param int $target_user_id User ID.
 * @return bool
 */
function ontrack_current_user_can_edit_demographics_for_user( $target_user_id ) {
	$target_user_id = (int) $target_user_id;
	if ( $target_user_id <= 0 ) {
		return false;
	}
	$current_id = get_current_user_id();
	if ( $current_id <= 0 ) {
		return false;
	}
	if ( (int) $current_id === $target_user_id ) {
		return true;
	}
	return current_user_can( 'edit_user', $target_user_id );
}

/**
 * Sanitize date of birth to Y-m-d or empty string if invalid / blank.
 *
 * @param mixed $raw POST or stored value.
 * @return string
 */
function ontrack_sanitize_date_of_birth( $raw ) {
	$raw = is_string( $raw ) ? trim( $raw ) : '';
	if ( '' === $raw ) {
		return '';
	}
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $raw ) ) {
		return '';
	}
	$d = \DateTimeImmutable::createFromFormat( '!Y-m-d', $raw, wp_timezone() );
	if ( false === $d ) {
		return '';
	}
	$errors = \DateTimeImmutable::getLastErrors();
	if ( is_array( $errors ) && ( $errors['warning_count'] > 0 || $errors['error_count'] > 0 ) ) {
		return '';
	}
	$now = new \DateTimeImmutable( 'now', wp_timezone() );
	if ( $d > $now ) {
		return '';
	}
	$year = (int) $d->format( 'Y' );
	if ( $year < 1900 ) {
		return '';
	}
	return $raw;
}

/**
 * Whether a string is a valid stored date of birth (Y-m-d, in range).
 *
 * @param string $ymd Date string.
 * @return bool
 */
function ontrack_is_valid_date_of_birth_string( $ymd ) {
	return '' !== ontrack_sanitize_date_of_birth( $ymd );
}

/**
 * Sanitize gender to `male`, `female`, or empty.
 *
 * @param mixed $raw POST value.
 * @return string
 */
function ontrack_sanitize_gender( $raw ) {
	$raw = is_string( $raw ) ? sanitize_key( $raw ) : '';
	if ( '' === $raw ) {
		return '';
	}
	if ( 'male' === $raw || 'female' === $raw ) {
		return $raw;
	}
	return '';
}

/**
 * Sanitize city or country line (short text).
 *
 * @param mixed  $raw   Raw value.
 * @param int    $limit Max characters.
 * @return string
 */
function ontrack_sanitize_location_field( $raw, $limit = 120 ) {
	if ( ! is_string( $raw ) ) {
		return '';
	}
	$raw = trim( $raw );
	$limit = max( 1, min( 250, (int) $limit ) );
	if ( function_exists( 'mb_substr' ) ) {
		$raw = mb_substr( $raw, 0, $limit );
	} else {
		$raw = substr( $raw, 0, $limit );
	}
	return sanitize_text_field( $raw );
}

/**
 * Get date of birth (Y-m-d) or empty.
 *
 * @param int|null $user_id User ID or null for current user.
 * @return string
 */
function ontrack_get_user_date_of_birth( $user_id = null ) {
	if ( null === $user_id ) {
		$user_id = get_current_user_id();
	}
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return '';
	}
	$raw = get_user_meta( $user_id, ontrack_meta_key_date_of_birth(), true );
	$raw = is_string( $raw ) ? $raw : '';
	return ontrack_sanitize_date_of_birth( $raw );
}

/**
 * Get gender: `male`, `female`, or empty.
 *
 * @param int|null $user_id User ID or null for current user.
 * @return string
 */
function ontrack_get_user_gender( $user_id = null ) {
	if ( null === $user_id ) {
		$user_id = get_current_user_id();
	}
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return '';
	}
	$raw = get_user_meta( $user_id, ontrack_meta_key_gender(), true );
	return ontrack_sanitize_gender( is_string( $raw ) ? $raw : '' );
}

/**
 * Get city or empty.
 *
 * @param int|null $user_id User ID or null for current user.
 * @return string
 */
function ontrack_get_user_city( $user_id = null ) {
	if ( null === $user_id ) {
		$user_id = get_current_user_id();
	}
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return '';
	}
	$raw = get_user_meta( $user_id, ontrack_meta_key_city(), true );
	return ontrack_sanitize_location_field( is_string( $raw ) ? $raw : '' );
}

/**
 * Get country or empty.
 *
 * @param int|null $user_id User ID or null for current user.
 * @return string
 */
function ontrack_get_user_country( $user_id = null ) {
	if ( null === $user_id ) {
		$user_id = get_current_user_id();
	}
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return '';
	}
	$raw = get_user_meta( $user_id, ontrack_meta_key_country(), true );
	return ontrack_sanitize_location_field( is_string( $raw ) ? $raw : '' );
}

/**
 * Integer age in full years from date of birth as of “today” in the site timezone.
 * Uses calendar date difference (same as DateTimeImmutable::diff()->y).
 *
 * @param int|null $user_id User ID or null for current user.
 * @return int|null Null if DOB missing or invalid.
 */
function ontrack_get_user_age_years( $user_id = null ) {
	$ymd = ontrack_get_user_date_of_birth( $user_id );
	if ( '' === $ymd ) {
		return null;
	}
	$tz = wp_timezone();
	$dob = \DateTimeImmutable::createFromFormat( '!Y-m-d', $ymd, $tz );
	if ( false === $dob ) {
		return null;
	}
	$errors = \DateTimeImmutable::getLastErrors();
	if ( is_array( $errors ) && ( $errors['warning_count'] > 0 || $errors['error_count'] > 0 ) ) {
		return null;
	}
	$now = new \DateTimeImmutable( 'now', $tz );
	if ( $dob > $now ) {
		return null;
	}
	return (int) $dob->diff( $now )->y;
}
