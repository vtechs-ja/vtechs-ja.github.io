<?php
/**
 * WP-CLI migration: Supabase JSON export → WordPress.
 *
 * Usage:
 *   wp kcfa migrate supabase --dir=/path/to/export
 *   wp kcfa migrate supabase --dir=/path/to/export --dry-run
 *
 * Expected JSON files in --dir:
 *   members.json       — array of member objects
 *   groups.json        — array of group objects (with optional parent_id)
 *   group_members.json — array of {group_id, member_id} objects
 *   member_roles.json  — array of {member_id, role_id} objects
 *   roles.json         — array of {id, slug, name} objects
 *   app_settings.json  — (optional) array of {group, key, value} objects
 *
 * Audio metadata is intentionally skipped — the Supabase table has no collection_id.
 * Use the "Sync from Box" button on each audio_collection edit screen after migration.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) {
	return;
}

/**
 * Runs the Supabase → WordPress data migration.
 */
class Ontrack_CLI_Migrate {

	/**
	 * Supabase role slug → WP custom role constant.
	 *
	 * Slugs here are what exist in the Supabase `roles` table.
	 * Any unrecognised slug defaults to KCFA_ROLE_MEMBER.
	 *
	 * @var array<string, string>
	 */
	private static $role_map = array(
		'admin'            => KCFA_ROLE_ADMIN,
		'community_leader' => KCFA_ROLE_COMMUNITY_LEADER,
		'leader'           => KCFA_ROLE_LEADER,
		'member'           => KCFA_ROLE_MEMBER,
	);

	/**
	 * Privilege order: lower index = higher privilege.
	 * Used to pick the best role when a Supabase member has multiple.
	 *
	 * @var string[]
	 */
	private static $role_rank = array(
		KCFA_ROLE_ADMIN,
		KCFA_ROLE_COMMUNITY_LEADER,
		KCFA_ROLE_LEADER,
		KCFA_ROLE_MEMBER,
	);

	/**
	 * Migrate Supabase data to WordPress.
	 *
	 * ## OPTIONS
	 *
	 * --dir=<path>
	 * : Absolute path to a directory containing the Supabase JSON export files.
	 *
	 * [--dry-run]
	 * : Log every planned action without writing any data.
	 *
	 * ## EXAMPLES
	 *
	 *     wp kcfa migrate supabase --dir=/tmp/export
	 *     wp kcfa migrate supabase --dir=/tmp/export --dry-run
	 *
	 * @when after_wp_load
	 *
	 * @param array $args       Positional arguments (unused).
	 * @param array $assoc_args Named arguments.
	 */
	public function supabase( array $args, array $assoc_args ) {
		$dir     = trailingslashit( WP_CLI\Utils\get_flag_value( $assoc_args, 'dir', '' ) );
		$dry_run = (bool) WP_CLI\Utils\get_flag_value( $assoc_args, 'dry-run', false );

		if ( ! $dir || ! is_dir( $dir ) ) {
			WP_CLI::error( '--dir must be a valid directory path.' );
		}

		if ( $dry_run ) {
			WP_CLI::log( '--- DRY RUN — no data will be written ---' );
		}

		// Validate required files before touching the database.
		$required = array( 'members', 'groups', 'group_members', 'member_roles', 'roles' );
		foreach ( $required as $name ) {
			if ( ! file_exists( $dir . $name . '.json' ) ) {
				WP_CLI::error( "Missing required file: {$dir}{$name}.json" );
			}
		}

		// Suppress all outgoing email for the duration of this command.
		$this->suppress_email_hooks();

		// Load JSON files.
		$files = array_merge( $required, array( 'app_settings', 'media_collections' ) );
		$data  = array();
		foreach ( $files as $name ) {
			$path = $dir . $name . '.json';
			if ( ! file_exists( $path ) ) {
				$data[ $name ] = array();
				continue;
			}
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$decoded = json_decode( file_get_contents( $path ), true );
			if ( ! is_array( $decoded ) ) {
				WP_CLI::error( "Could not parse {$name}.json — expected a JSON array." );
			}
			$data[ $name ] = $decoded;
		}

		$counts = array(
			'groups_created'       => 0,
			'groups_skipped'       => 0,
			'members_created'      => 0,
			'members_skipped'      => 0,
			'members_grouped'      => 0,
			'collections_created'  => 0,
			'collections_skipped'  => 0,
			'settings_set'         => 0,
		);

		// ------------------------------------------------------------------ //
		// Phase A — Groups                                                     //
		// ------------------------------------------------------------------ //

		WP_CLI::log( '' );
		WP_CLI::log( '=== Groups ===' );

		// Supabase UUID → WP post ID.
		$group_id_map = array();

		// Topological sort: keep re-queuing children until their parent is processed.
		$remaining  = $data['groups'];
		$max_passes = count( $remaining ) + 1;

		for ( $pass = 0; $pass < $max_passes && ! empty( $remaining ); $pass++ ) {
			$deferred = array();

			foreach ( $remaining as $group ) {
				$uuid      = $group['id'] ?? '';
				$parent_sb = $group['parent_id'] ?? null;

				// Defer if the parent hasn't been processed yet.
				if ( $parent_sb && ! isset( $group_id_map[ $parent_sb ] ) ) {
					$deferred[] = $group;
					continue;
				}

				$wp_parent = ( $parent_sb && isset( $group_id_map[ $parent_sb ] ) )
					? $group_id_map[ $parent_sb ]
					: 0;

				$name = sanitize_text_field( $group['name'] ?? '' );
				if ( ! $name ) {
					WP_CLI::warning( "  SKIP group {$uuid}: empty name." );
					$counts['groups_skipped']++;
					$group_id_map[ $uuid ] = 0;
					continue;
				}

				// Idempotent: find by title + parent.
				$existing = get_posts( array(
					'post_type'      => ontrack_group_post_type(),
					'post_status'    => 'publish',
					'post_parent'    => $wp_parent,
					'title'          => $name,
					'posts_per_page' => 1,
					'fields'         => 'ids',
				) );

				if ( ! empty( $existing ) ) {
					$wp_id = (int) $existing[0];
					WP_CLI::log( "  SKIP (exists) group: {$name} → WP post {$wp_id}" );
					$group_id_map[ $uuid ] = $wp_id;
					$counts['groups_skipped']++;
					continue;
				}

				if ( $dry_run ) {
					WP_CLI::log( "  [dry-run] CREATE group: {$name}" . ( $wp_parent ? " (parent WP {$wp_parent})" : '' ) );
					$group_id_map[ $uuid ] = -1; // non-zero placeholder so children resolve
					$counts['groups_created']++;
					continue;
				}

				$post_id = wp_insert_post(
					array(
						'post_type'    => ontrack_group_post_type(),
						'post_status'  => 'publish',
						'post_title'   => $name,
						'post_parent'  => $wp_parent,
						'post_content' => sanitize_textarea_field( $group['description'] ?? '' ),
					),
					true
				);

				if ( is_wp_error( $post_id ) ) {
					WP_CLI::warning( "  FAIL group {$name}: " . $post_id->get_error_message() );
					$counts['groups_skipped']++;
					$group_id_map[ $uuid ] = 0;
					continue;
				}

				// Store demographic constraints when present.
				if ( ! empty( $group['is_demographic'] ) ) {
					$demo = array(
						'age_min' => isset( $group['age_min'] ) && null !== $group['age_min'] ? (int) $group['age_min'] : null,
						'age_max' => isset( $group['age_max'] ) && null !== $group['age_max'] ? (int) $group['age_max'] : null,
						'gender'  => in_array( $group['gender'] ?? '', array( 'male', 'female' ), true ) ? $group['gender'] : '',
					);
					update_post_meta( $post_id, ontrack_group_demographics_meta_key(), $demo );
				}

				WP_CLI::log( "  CREATE group: {$name} → WP post {$post_id}" );
				$group_id_map[ $uuid ] = $post_id;
				$counts['groups_created']++;
			}

			$remaining = $deferred;
		}

		foreach ( $remaining as $g ) {
			WP_CLI::warning( "  SKIP group (circular/unresolved parent): " . ( $g['name'] ?? $g['id'] ?? '?' ) );
			$counts['groups_skipped']++;
		}

		// ------------------------------------------------------------------ //
		// Phase B — Role map (Supabase UUID → WP role slug)                  //
		// ------------------------------------------------------------------ //

		$role_id_to_slug = array();
		foreach ( $data['roles'] as $role ) {
			if ( ! empty( $role['id'] ) && ! empty( $role['slug'] ) ) {
				$role_id_to_slug[ $role['id'] ] = $role['slug'];
			}
		}

		// member UUID → best WP role slug (highest privilege wins).
		$member_role_map = array();
		foreach ( $data['member_roles'] as $mr ) {
			$mid     = $mr['member_id'] ?? '';
			$rid     = $mr['role_id'] ?? '';
			$sb_slug = $role_id_to_slug[ $rid ] ?? '';
			$wp_role = self::$role_map[ $sb_slug ] ?? null;

			if ( ! $mid ) {
				continue;
			}
			if ( ! $wp_role ) {
				WP_CLI::warning( "  Unknown Supabase role '{$sb_slug}' for member {$mid} — defaulting to klac_member." );
				$wp_role = KCFA_ROLE_MEMBER;
			}

			if ( ! isset( $member_role_map[ $mid ] ) ) {
				$member_role_map[ $mid ] = $wp_role;
			} else {
				// Keep highest-privilege role.
				$cur_rank = array_search( $member_role_map[ $mid ], self::$role_rank, true );
				$new_rank = array_search( $wp_role, self::$role_rank, true );
				if ( false !== $new_rank && $new_rank < $cur_rank ) {
					$member_role_map[ $mid ] = $wp_role;
				}
			}
		}

		// ------------------------------------------------------------------ //
		// Phase C — Members                                                   //
		// ------------------------------------------------------------------ //

		WP_CLI::log( '' );
		WP_CLI::log( '=== Members ===' );

		// Supabase UUID → WP user ID.
		$member_id_map = array();

		foreach ( $data['members'] as $member ) {
			$uuid  = $member['id'] ?? '';
			$email = sanitize_email( $member['email'] ?? '' );

			if ( ! $email ) {
				WP_CLI::warning( "  SKIP member {$uuid}: invalid email." );
				$counts['members_skipped']++;
				continue;
			}

			// Idempotent: skip if a WP user with this email already exists.
			$existing = get_user_by( 'email', $email );
			if ( $existing ) {
				WP_CLI::log( "  SKIP (exists) member: {$email} → WP user {$existing->ID}" );
				$member_id_map[ $uuid ] = $existing->ID;
				$counts['members_skipped']++;
				continue;
			}

			$full_name = sanitize_text_field( $member['full_name'] ?? '' );
			$parts     = $full_name ? explode( ' ', $full_name, 2 ) : array();
			$first     = $parts[0] ?? '';
			$last      = $parts[1] ?? '';

			$is_member = ( 'active' === ( $member['status'] ?? '' ) ) ? 1 : 0;
			$wp_role   = $member_role_map[ $uuid ] ?? KCFA_ROLE_MEMBER;

			$dob     = ontrack_sanitize_date_of_birth( $member['date_of_birth'] ?? '' );
			$gender  = ontrack_sanitize_gender( $member['gender'] ?? '' );
			$city    = ontrack_sanitize_location_field( $member['city'] ?? '' );
			$country = ontrack_sanitize_location_field( $member['country'] ?? '' );

			// Build a unique login from the email address.
			$login = sanitize_user( strtolower( $email ), true );
			if ( username_exists( $login ) ) {
				// Collision with a different account — flatten the @ sign.
				$login = sanitize_user( strtolower( str_replace( '@', '_at_', $email ) ), true );
			}

			if ( $dry_run ) {
				WP_CLI::log( "  [dry-run] CREATE member: {$email}  role={$wp_role}  is_member={$is_member}" );
				$member_id_map[ $uuid ] = -1;
				$counts['members_created']++;
				continue;
			}

			$user_id = wp_insert_user( array(
				'user_login'   => $login,
				'user_email'   => $email,
				'user_pass'    => wp_generate_password( 24, true, true ),
				'display_name' => $full_name ?: $email,
				'first_name'   => $first,
				'last_name'    => $last,
				'role'         => $wp_role,
			) );

			if ( is_wp_error( $user_id ) ) {
				WP_CLI::warning( "  FAIL member {$email}: " . $user_id->get_error_message() );
				$counts['members_skipped']++;
				continue;
			}

			update_user_meta( $user_id, ontrack_meta_key_is_member(), $is_member );

			if ( $dob )     { update_user_meta( $user_id, ontrack_meta_key_date_of_birth(), $dob ); }
			if ( $gender )  { update_user_meta( $user_id, ontrack_meta_key_gender(), $gender ); }
			if ( $city )    { update_user_meta( $user_id, ontrack_meta_key_city(), $city ); }
			if ( $country ) { update_user_meta( $user_id, ontrack_meta_key_country(), $country ); }

			WP_CLI::log( "  CREATE member: {$email} → WP user {$user_id}  role={$wp_role}  is_member={$is_member}" );
			$member_id_map[ $uuid ] = $user_id;
			$counts['members_created']++;
		}

		// ------------------------------------------------------------------ //
		// Phase D — Group memberships                                         //
		// ------------------------------------------------------------------ //

		WP_CLI::log( '' );
		WP_CLI::log( '=== Group memberships ===' );

		if ( $dry_run ) {
			// In dry-run no real IDs exist; summarise from raw data instead.
			$affected = array();
			foreach ( $data['group_members'] as $gm ) {
				$mid = $gm['member_id'] ?? '';
				if ( $mid ) {
					$affected[ $mid ] = true;
				}
			}
			WP_CLI::log( sprintf(
				'  [dry-run] %d group_member rows across %d members would be applied.',
				count( $data['group_members'] ),
				count( $affected )
			) );
		} else {
			// Collect all WP group post IDs per WP user ID.
			$user_groups = array();
			foreach ( $data['group_members'] as $gm ) {
				$mid        = $gm['member_id'] ?? '';
				$gid        = $gm['group_id'] ?? '';
				$wp_user_id = $member_id_map[ $mid ] ?? 0;
				$wp_post_id = $group_id_map[ $gid ] ?? 0;

				if ( ! $wp_user_id || $wp_user_id < 0 ) {
					WP_CLI::warning( "  Unresolved member for group_member: member={$mid}" );
					continue;
				}
				if ( ! $wp_post_id || $wp_post_id < 0 ) {
					WP_CLI::warning( "  Unresolved group for group_member: group={$gid}" );
					continue;
				}

				$user_groups[ $wp_user_id ][] = $wp_post_id;
			}

			foreach ( $user_groups as $wp_user_id => $post_ids ) {
				$post_ids = array_values( array_unique( $post_ids ) );
				update_user_meta( $wp_user_id, ontrack_user_group_ids_meta_key(), $post_ids );
				WP_CLI::log( "  SET groups for user {$wp_user_id}: " . implode( ', ', $post_ids ) );
				$counts['members_grouped']++;
			}
		}

		// ------------------------------------------------------------------ //
		// Phase E — App settings                                              //
		// ------------------------------------------------------------------ //

		if ( ! empty( $data['app_settings'] ) ) {
			WP_CLI::log( '' );
			WP_CLI::log( '=== App settings ===' );

			$opts    = ontrack_get_options();
			$changed = false;

			foreach ( $data['app_settings'] as $row ) {
				$key = $row['key'] ?? '';
				$val = $row['value'] ?? '';

				if ( 'sunday_event_time' === $key && preg_match( '/^\d{2}:\d{2}$/', (string) $val ) ) {
					if ( $dry_run ) {
						WP_CLI::log( "  [dry-run] SET sunday_event_time = {$val}" );
					} else {
						$opts['sunday_event_time'] = $val;
						$changed                   = true;
						WP_CLI::log( "  SET sunday_event_time = {$val}" );
					}
					$counts['settings_set']++;
				} else {
					$group = $row['group'] ?? 'default';
					WP_CLI::log( "  SKIP setting [{$group}] {$key}" );
				}
			}

			if ( $changed ) {
				update_option( ontrack_options_key(), $opts );
			}
		}

		// ------------------------------------------------------------------ //
		// Phase F — Media collections                                         //
		// ------------------------------------------------------------------ //

		WP_CLI::log( '' );
		WP_CLI::log( '=== Media collections ===' );

		if ( empty( $data['media_collections'] ) ) {
			WP_CLI::log( '  SKIP — media_collections.json is empty or missing.' );
		} else {
			foreach ( $data['media_collections'] as $mc ) {
				$lookup = sanitize_title( $mc['lookup_key'] ?? '' );
				$type   = $mc['type'] ?? '';
				$source = $mc['source'] ?? '';
				$name   = sanitize_text_field( $mc['name'] ?? '' );

				if ( ! $lookup || ! $name || ! in_array( $type, array( 'audio', 'video' ), true ) ) {
					WP_CLI::warning( '  SKIP collection: missing lookup_key, name, or type.' );
					$counts['collections_skipped']++;
					continue;
				}

				$post_type = ( 'audio' === $type ) ? 'audio_collection' : 'video_collection';

				// Idempotent: find by slug first, then fall back to title.
				$existing = get_posts( array(
					'post_type'      => $post_type,
					'post_status'    => 'publish',
					'name'           => $lookup,
					'posts_per_page' => 1,
					'fields'         => 'ids',
				) );
				if ( empty( $existing ) ) {
					$existing = get_posts( array(
						'post_type'      => $post_type,
						'post_status'    => 'publish',
						'title'          => $name,
						'posts_per_page' => 1,
						'fields'         => 'ids',
					) );
				}

				if ( ! empty( $existing ) ) {
					WP_CLI::log( "  SKIP (exists) collection: {$name} → WP post {$existing[0]}" );
					$counts['collections_skipped']++;
					continue;
				}

				if ( $dry_run ) {
					WP_CLI::log( "  [dry-run] CREATE {$post_type}: {$name} (slug={$lookup}, source={$source})" );
					$counts['collections_created']++;
					continue;
				}

				$post_id = wp_insert_post(
					array(
						'post_type'    => $post_type,
						'post_status'  => 'publish',
						'post_title'   => $name,
						'post_name'    => $lookup,
						'post_content' => sanitize_textarea_field( $mc['description'] ?? '' ),
					),
					true
				);

				if ( is_wp_error( $post_id ) ) {
					WP_CLI::warning( "  FAIL collection {$name}: " . $post_id->get_error_message() );
					$counts['collections_skipped']++;
					continue;
				}

				// Set provider-specific meta.
				if ( 'audio' === $type && 'box' === $source && ! empty( $mc['param1'] ) ) {
					update_post_meta( $post_id, '_ontrack_box_folder_id', sanitize_text_field( $mc['param1'] ) );
				} elseif ( 'video' === $type && 'bunny' === $source ) {
					update_post_meta( $post_id, '_ontrack_video_provider', 'bunny' );
					if ( ! empty( $mc['param2'] ) ) {
						update_post_meta( $post_id, '_ontrack_bunny_collection_id', sanitize_text_field( $mc['param2'] ) );
					}
					// param1 = Bunny library_id — site-wide in klac_ontrack_integrations, not per-post.
				} elseif ( 'video' === $type && 'vimeo' === $source ) {
					update_post_meta( $post_id, '_ontrack_video_provider', 'vimeo' );
					if ( ! empty( $mc['param1'] ) ) {
						update_post_meta( $post_id, '_ontrack_vimeo_showcase_id', sanitize_text_field( $mc['param1'] ) );
					}
				}

				WP_CLI::log( "  CREATE {$post_type}: {$name} → WP post {$post_id} (slug={$lookup})" );
				$counts['collections_created']++;
			}
		}

		// ------------------------------------------------------------------ //
		// Audio metadata notice                                               //
		// ------------------------------------------------------------------ //

		WP_CLI::log( '' );
		WP_CLI::log( '=== Audio metadata ===' );
		WP_CLI::log( '  SKIPPED — Supabase audio_metadata has no collection_id field.' );
		WP_CLI::log( '  After cutover: use the "Sync from Box" button on each audio_collection' );
		WP_CLI::log( '  edit screen to repopulate file lists and re-enter display names.' );

		// ------------------------------------------------------------------ //
		// Summary                                                             //
		// ------------------------------------------------------------------ //

		WP_CLI::log( '' );
		WP_CLI::log( '=== Summary ===' );
		WP_CLI::log( sprintf( '  Groups:            %d created, %d skipped', $counts['groups_created'],      $counts['groups_skipped'] ) );
		WP_CLI::log( sprintf( '  Members:           %d created, %d skipped', $counts['members_created'],    $counts['members_skipped'] ) );
		WP_CLI::log( sprintf( '  Group memberships: %d users updated',        $counts['members_grouped'] ) );
		WP_CLI::log( sprintf( '  Collections:       %d created, %d skipped', $counts['collections_created'], $counts['collections_skipped'] ) );
		WP_CLI::log( sprintf( '  Settings:          %d set',                  $counts['settings_set'] ) );

		if ( $dry_run ) {
			WP_CLI::success( 'Dry run complete — no data was written.' );
		} else {
			WP_CLI::success( 'Migration complete.' );
		}
	}

	/**
	 * Block all outgoing email for the lifetime of this command.
	 *
	 * wp_insert_user() fires the user_register action, which third-party
	 * plugins (welcome-email plugins, etc.) commonly hook to send notifications.
	 * pre_wp_mail intercepts any mail that still slips through.
	 */
	private function suppress_email_hooks() {
		remove_all_actions( 'user_register' );
		remove_all_actions( 'password_reset' );

		// pre_wp_mail: returning non-null short-circuits wp_mail() entirely.
		add_filter( 'pre_wp_mail', '__return_true' );

		WP_CLI::log( 'Email suppression active — no emails will be sent during this run.' );
	}
}

WP_CLI::add_command( 'kcfa migrate', new Ontrack_CLI_Migrate() );
