<?php
/**
 * Ontrack admin menu and Settings submenu.
 *
 * Registers the top-level "Ontrack" menu and places the integration
 * Settings page under it. Custom post types (Audio Collections, Video Collections)
 * are registered with show_in_menu => 'ontrack' so they appear here too.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the Ontrack top-level menu and Settings submenu.
 */
function ontrack_admin_menu() {
	$menu_slug = 'ontrack';

	add_menu_page(
		__( 'Ontrack', 'ontrack' ),
		__( 'Ontrack', 'ontrack' ),
		'manage_options',
		$menu_slug,
		'ontrack_menu_callback',
		'dashicons-media-interactive',
		30
	);

	// Remove the duplicate first submenu item (same slug as parent).
	remove_submenu_page( $menu_slug, $menu_slug );

	add_submenu_page(
		$menu_slug,
		__( 'Integration Settings', 'ontrack' ),
		__( 'Settings', 'ontrack' ),
		'manage_options',
		'ontrack-settings',
		'ontrack_settings_page_render'
	);
}
add_action( 'admin_menu', 'ontrack_admin_menu', 9 );

/**
 * Callback for the Ontrack top-level menu (landing when no submenu selected).
 */
function ontrack_menu_callback() {
	$audio_url = admin_url( 'edit.php?post_type=audio_collection' );
	$video_url = admin_url( 'edit.php?post_type=video_collection' );
	$settings_url = admin_url( 'admin.php?page=ontrack-settings' );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Ontrack', 'ontrack' ); ?></h1>
		<p><?php esc_html_e( 'Manage audio and video collections and integration settings.', 'ontrack' ); ?></p>
		<ul style="list-style: disc; margin-left: 2em;">
			<li><a href="<?php echo esc_url( $audio_url ); ?>"><?php esc_html_e( 'Audio Collections', 'ontrack' ); ?></a></li>
			<li><a href="<?php echo esc_url( $video_url ); ?>"><?php esc_html_e( 'Video Collections', 'ontrack' ); ?></a></li>
			<li><a href="<?php echo esc_url( $settings_url ); ?>"><?php esc_html_e( 'Settings', 'ontrack' ); ?></a></li>
		</ul>
	</div>
	<?php
}
