<?php
/**
 * Front-end asset enqueuing for Ontrack media players and members area.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue the baseline player stylesheet when the active theme does not supply
 * its own (detected by the absence of the ontrack-style handle).
 */
function ontrack_enqueue_baseline_css() {
	if ( ! wp_style_is( 'ontrack-style', 'registered' ) ) {
		wp_enqueue_style(
			'ontrack-players-default',
			ONTRACK_ASSETS_URL . 'css/players-default.css',
			array(),
			ONTRACK_VERSION
		);
	}
}
add_action( 'wp_enqueue_scripts', 'ontrack_enqueue_baseline_css' );

/**
 * Enqueue audio player, video player, and members area scripts.
 */
function ontrack_enqueue_media_scripts() {
	$js_url = ONTRACK_ASSETS_URL . 'js/';
	$ver    = ONTRACK_VERSION;

	if ( is_singular( 'audio_collection' ) ) {
		wp_enqueue_script( 'ontrack-audio-player', $js_url . 'audio-player.js', array(), $ver, true );
		wp_localize_script(
			'ontrack-audio-player',
			'ontrackAudioPlayer',
			array(
				'restUrl' => rest_url( 'klac/v1' ),
			)
		);
	}

	if ( is_singular( 'video_collection' ) ) {
		wp_enqueue_script( 'ontrack-video-player', $js_url . 'video-player.js', array(), $ver, true );
		wp_localize_script(
			'ontrack-video-player',
			'ontrackVideoPlayer',
			array(
				'restUrl' => rest_url( 'klac/v1' ),
			)
		);
	}

	if ( is_page_template( 'template-members-area.php' ) ) {
		wp_enqueue_script( 'ontrack-members-area', $js_url . 'members-area.js', array(), $ver, true );
		$pid  = get_queried_object_id();
		$mode = get_post_meta( $pid, '_ontrack_members_countdown_mode', true ) ?: 'weekly';
		$time = get_post_meta( $pid, '_ontrack_members_countdown_time', true ) ?: '09:00';
		$rest = get_post_meta( $pid, '_ontrack_members_countdown_rest', true );
		list( $h, $m ) = array_map( 'intval', explode( ':', $time . ':0' ) );
		wp_localize_script(
			'ontrack-members-area',
			'ontrackMembersArea',
			array(
				'countdown' => array(
					'mode'   => $mode,
					'day'    => (int) get_post_meta( $pid, '_ontrack_members_countdown_day', true ),
					'hour'   => $h,
					'minute' => $m,
					'rest'   => '' !== $rest ? (int) $rest : 3,
					'date'   => get_post_meta( $pid, '_ontrack_members_countdown_date', true ),
				),
			)
		);
	}
}
add_action( 'wp_enqueue_scripts', 'ontrack_enqueue_media_scripts' );
