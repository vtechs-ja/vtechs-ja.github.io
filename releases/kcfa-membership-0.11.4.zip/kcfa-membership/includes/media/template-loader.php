<?php
/**
 * Template loader: injects plugin fallback templates when the active theme
 * does not provide a CPT-specific single template for audio_collection or
 * video_collection. Theme templates always take precedence.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Swap in the plugin's fallback template only when the theme has no CPT template.
 *
 * @param string $template Resolved template path.
 * @return string
 */
function ontrack_template_loader( $template ) {
	if ( is_singular( 'audio_collection' ) &&
		! locate_template( array( 'single-audio_collection.php' ) ) ) {
		return ONTRACK_PATH . 'templates/single-audio_collection.php';
	}

	if ( is_singular( 'video_collection' ) &&
		! locate_template( array( 'single-video_collection.php' ) ) ) {
		return ONTRACK_PATH . 'templates/single-video_collection.php';
	}

	return $template;
}
add_filter( 'template_include', 'ontrack_template_loader' );
