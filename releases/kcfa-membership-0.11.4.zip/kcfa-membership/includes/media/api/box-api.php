<?php
/**
 * Box.com API helpers for listing folder contents and getting file download URLs.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Supported audio file extensions (lowercase). */
define( 'ONTRACK_BOX_AUDIO_EXTENSIONS', array( 'mp3', 'm4a', 'aac', 'ogg', 'oga', 'wav', 'flac', 'webm' ) );

/**
 * Return a valid Box API access token, generating one via JWT if needed.
 *
 * Credentials are read from Ontrack → Settings (stored in the klac_ontrack_integrations option).
 * The token is cached in a transient for 55 minutes (Box issues 60-minute tokens).
 *
 * @return string|WP_Error Access token string or WP_Error on failure.
 */
function ontrack_box_get_access_token() {
	$cached = get_transient( 'ontrack_box_access_token' );
	if ( $cached ) {
		return $cached;
	}

	$opts          = get_option( 'ontrack_integrations', array() );
	$client_id     = isset( $opts['box_client_id'] )       ? $opts['box_client_id']       : '';
	$client_secret = isset( $opts['box_client_secret'] )   ? $opts['box_client_secret']   : '';
	$private_key   = isset( $opts['box_jwt_private_key'] ) ? $opts['box_jwt_private_key'] : '';
	$key_id        = isset( $opts['box_jwt_kid'] )         ? $opts['box_jwt_kid']         : '';
	$passphrase    = isset( $opts['box_jwt_passphrase'] )  ? $opts['box_jwt_passphrase']  : '';
	$enterprise_id = isset( $opts['box_enterprise_id'] )   ? $opts['box_enterprise_id']   : '';

	if ( ! $client_id || ! $client_secret || ! $private_key || ! $key_id || ! $enterprise_id ) {
		return new WP_Error( 'ontrack_box_config', __( 'Box credentials are not fully configured. Check Ontrack → Settings.', 'ontrack' ) );
	}

	// Build the JWT assertion.
	$header  = ontrack_box_jwt_base64url( (string) wp_json_encode( array( 'alg' => 'RS256', 'typ' => 'JWT', 'kid' => $key_id ) ) );
	$claims  = ontrack_box_jwt_base64url( (string) wp_json_encode( array(
		'iss'          => $client_id,
		'sub'          => $enterprise_id,
		'box_sub_type' => 'enterprise',
		'aud'          => 'https://api.box.com/oauth2/token',
		'jti'          => bin2hex( random_bytes( 16 ) ),
		'exp'          => time() + 45,
	) ) );
	$signing_input = $header . '.' . $claims;

	$pkey = openssl_pkey_get_private( $private_key, $passphrase );
	if ( ! $pkey ) {
		return new WP_Error( 'ontrack_box_jwt', __( 'Failed to load Box private key. Check the JWT Private Key and Passphrase in Ontrack → Settings.', 'ontrack' ) );
	}

	$signature = '';
	if ( ! openssl_sign( $signing_input, $signature, $pkey, OPENSSL_ALGO_SHA256 ) ) {
		return new WP_Error( 'ontrack_box_jwt', __( 'Failed to sign Box JWT assertion.', 'ontrack' ) );
	}

	$jwt = $signing_input . '.' . ontrack_box_jwt_base64url( $signature );

	// Exchange the JWT assertion for an access token.
	$response = wp_remote_post(
		'https://api.box.com/oauth2/token',
		array(
			'body'    => array(
				'grant_type'    => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
				'client_id'     => $client_id,
				'client_secret' => $client_secret,
				'assertion'     => $jwt,
			),
			'timeout' => 15,
		)
	);

	$code = wp_remote_retrieve_response_code( $response );
	$body = json_decode( wp_remote_retrieve_body( $response ), true );

	if ( $code !== 200 ) {
		$detail = isset( $body['error_description'] ) ? $body['error_description'] : wp_remote_retrieve_body( $response );
		return new WP_Error( 'ontrack_box_jwt', sprintf( __( 'Box token exchange failed: %s', 'ontrack' ), $detail ) );
	}

	$token = isset( $body['access_token'] ) ? $body['access_token'] : '';
	if ( ! $token ) {
		return new WP_Error( 'ontrack_box_jwt', __( 'Box token exchange returned no access_token.', 'ontrack' ) );
	}

	// Cache for 55 minutes — Box tokens last 60, 5-minute buffer avoids using an about-to-expire token.
	set_transient( 'ontrack_box_access_token', $token, 55 * MINUTE_IN_SECONDS );

	return $token;
}

/**
 * Base64url-encode a string (RFC 4648 §5, no padding).
 *
 * @param string $data Raw bytes.
 * @return string Base64url-encoded string.
 */
function ontrack_box_jwt_base64url( $data ) {
	return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' );
}

/**
 * List files in a Box folder and return audio files only.
 *
 * @param string $folder_id   Box folder ID (numeric string).
 * @param string $access_token Box API access token.
 * @return array List of items with keys: id, name, extension. WP_Error on failure.
 */
function ontrack_box_list_audio_in_folder( $folder_id, $access_token ) {
	$folder_id = trim( $folder_id );
	if ( empty( $folder_id ) || empty( $access_token ) ) {
		return new WP_Error( 'ontrack_box_config', __( 'Box folder ID and access token are required.', 'ontrack' ) );
	}

	$url = 'https://api.box.com/2.0/folders/' . rawurlencode( $folder_id ) . '/items?limit=1000&fields=id,name,type';
	$response = wp_remote_get(
		$url,
		array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $access_token,
				'Content-Type'   => 'application/json',
			),
			'timeout' => 15,
		)
	);

	$code = wp_remote_retrieve_response_code( $response );
	$body = wp_remote_retrieve_body( $response );
	$data = json_decode( $body, true );

	if ( $code !== 200 ) {
		$message = isset( $data['message'] ) ? $data['message'] : $body;
		return new WP_Error( 'ontrack_box_api', sprintf( __( 'Box API error: %s', 'ontrack' ), $message ) );
	}

	$entries = isset( $data['entries'] ) ? $data['entries'] : array();
	$audio_extensions = ONTRACK_BOX_AUDIO_EXTENSIONS;
	$audio = array();

	foreach ( $entries as $entry ) {
		if ( isset( $entry['type'] ) && $entry['type'] !== 'file' ) {
			continue;
		}
		$name = isset( $entry['name'] ) ? $entry['name'] : '';
		$ext  = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
		if ( in_array( $ext, $audio_extensions, true ) ) {
			$audio[] = array(
				'id'        => isset( $entry['id'] ) ? (string) $entry['id'] : '',
				'name'      => $name,
				'extension' => $ext,
			);
		}
	}

	// Sort by name.
	usort( $audio, function ( $a, $b ) {
		return strcasecmp( $a['name'], $b['name'] );
	} );

	return $audio;
}

/**
 * Get a temporary download URL for a Box file.
 *
 * @param string $file_id      Box file ID.
 * @param string $access_token Box API access token.
 * @return string|WP_Error Download URL or error.
 */
function ontrack_box_get_download_url( $file_id, $access_token ) {
	$file_id = trim( $file_id );
	if ( empty( $file_id ) || empty( $access_token ) ) {
		return new WP_Error( 'ontrack_box_config', __( 'File ID and access token are required.', 'ontrack' ) );
	}

	$url = 'https://api.box.com/2.0/files/' . rawurlencode( $file_id ) . '?fields=download_url';
	$response = wp_remote_get(
		$url,
		array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $access_token,
				'Content-Type'   => 'application/json',
			),
			'timeout' => 15,
		)
	);

	$code = wp_remote_retrieve_response_code( $response );
	$body = wp_remote_retrieve_body( $response );
	$data = json_decode( $body, true );

	if ( $code !== 200 ) {
		$message = isset( $data['message'] ) ? $data['message'] : $body;
		return new WP_Error( 'ontrack_box_api', sprintf( __( 'Box API error: %s', 'ontrack' ), $message ) );
	}

	return isset( $data['download_url'] ) ? $data['download_url'] : new WP_Error( 'ontrack_box_api', __( 'No download URL in response.', 'ontrack' ) );
}
