<?php
/**
 * Bunny.net Stream API: list videos in a collection.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Bunny Stream video status: finished / ready to play. */
define( 'ONTRACK_BUNNY_VIDEO_STATUS_FINISHED', 4 );

/**
 * List videos in a Stream library filtered by collection GUID.
 *
 * @param int    $library_id       Video library ID from settings.
 * @param string $collection_guid  Collection GUID from the post meta.
 * @param string $api_key          Stream API AccessKey.
 * @return array List of items: guid, title, status. WP_Error on failure.
 */
function ontrack_bunny_list_videos_in_collection( $library_id, $collection_guid, $api_key ) {
	$library_id       = absint( $library_id );
	$collection_guid  = trim( (string) $collection_guid );
	$api_key          = trim( (string) $api_key );
	if ( ! $library_id || $collection_guid === '' || $api_key === '' ) {
		return new WP_Error( 'ontrack_bunny_config', __( 'Bunny library ID, collection GUID, and API key are required.', 'ontrack' ) );
	}

	$url = 'https://video.bunnycdn.com/library/' . $library_id . '/videos';
	$url = add_query_arg(
		array(
			'page'          => 1,
			'itemsPerPage'  => 100,
			'collection'    => $collection_guid,
			'orderBy'       => 'date',
		),
		$url
	);

	$response = wp_remote_get(
		$url,
		array(
			'headers' => array(
				'AccessKey'    => $api_key,
				'Content-Type' => 'application/json',
				'Accept'       => 'application/json',
			),
			'timeout' => 20,
		)
	);

	$code = wp_remote_retrieve_response_code( $response );
	$body = wp_remote_retrieve_body( $response );
	$data = json_decode( $body, true );

	if ( $code !== 200 || ! is_array( $data ) ) {
		$message = is_array( $data ) && isset( $data['message'] ) ? $data['message'] : $body;
		return new WP_Error( 'ontrack_bunny_api', sprintf( __( 'Bunny Stream error: %s', 'ontrack' ), $message ) );
	}

	$items = isset( $data['items'] ) && is_array( $data['items'] ) ? $data['items'] : array();
	$out   = array();
	foreach ( $items as $item ) {
		if ( empty( $item['guid'] ) || empty( $item['title'] ) ) {
			continue;
		}
		$status = isset( $item['status'] ) ? (int) $item['status'] : 0;
		if ( $status !== ONTRACK_BUNNY_VIDEO_STATUS_FINISHED ) {
			continue;
		}
		$out[] = array(
			'guid'               => (string) $item['guid'],
			'title'              => (string) $item['title'],
			'thumbnail_filename' => ! empty( $item['thumbnailFileName'] ) ? (string) $item['thumbnailFileName'] : 'thumbnail.jpg',
		);
	}

	usort(
		$out,
		function ( $a, $b ) {
			return strcasecmp( $a['title'], $b['title'] );
		}
	);

	return $out;
}
