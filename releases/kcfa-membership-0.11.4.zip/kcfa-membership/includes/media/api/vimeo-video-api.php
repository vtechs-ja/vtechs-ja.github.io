<?php
/**
 * Vimeo API: list videos in a showcase (album).
 *
 * The API uses /albums/ for showcases.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * List videos in a Vimeo showcase (album).
 *
 * @param string $showcase_id   Numeric album/showcase ID.
 * @param string $access_token  Vimeo Bearer token.
 * @return array List of items: video_id, name, embed_url (optional thumb). WP_Error on failure.
 */
function ontrack_vimeo_list_showcase_videos( $showcase_id, $access_token ) {
	$showcase_id   = trim( (string) $showcase_id );
	$access_token = trim( (string) $access_token );
	if ( $showcase_id === '' || $access_token === '' ) {
		return new WP_Error( 'ontrack_vimeo_config', __( 'Vimeo showcase ID and access token are required.', 'ontrack' ) );
	}

	$tracks = array();
	$page   = 1;

	while ( true ) {
		$url = 'https://api.vimeo.com/albums/' . rawurlencode( $showcase_id ) . '/videos';
		$url = add_query_arg(
			array(
				'per_page' => 100,
				'page'     => $page,
			),
			$url
		);

		$response = wp_remote_get(
			$url,
			array(
				'headers' => array(
					'Authorization' => 'Bearer ' . $access_token,
					'Accept'        => 'application/vnd.vimeo.*+json;version=3.4',
				),
				'timeout' => 20,
			)
		);

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( $code !== 200 || ! is_array( $data ) ) {
			$message = is_array( $data ) && isset( $data['error'] ) ? $data['error'] : $body;
			if ( empty( $tracks ) ) {
				return new WP_Error( 'ontrack_vimeo_api', sprintf( __( 'Vimeo API error: %s', 'ontrack' ), $message ) );
			}
			break;
		}

		$page_items = isset( $data['data'] ) && is_array( $data['data'] ) ? $data['data'] : array();
		foreach ( $page_items as $vid ) {
			if ( empty( $vid['uri'] ) || empty( $vid['name'] ) ) {
				continue;
			}
			if ( ! preg_match( '#/videos/(\d+)#', $vid['uri'], $m ) ) {
				continue;
			}
			$video_id = $m[1];
			$thumb    = '';
			if ( ! empty( $vid['pictures']['sizes'] ) && is_array( $vid['pictures']['sizes'] ) ) {
				$sizes = $vid['pictures']['sizes'];
				$last  = end( $sizes );
				if ( is_array( $last ) && ! empty( $last['link'] ) ) {
					$thumb = $last['link'];
				}
			}
			$tracks[] = array(
				'video_id'  => $video_id,
				'name'      => $vid['name'],
				'embed_url' => 'https://player.vimeo.com/video/' . $video_id,
				'thumbnail' => $thumb,
			);
		}

		$next = isset( $data['paging']['next'] ) ? $data['paging']['next'] : null;
		if ( ! $next || count( $page_items ) < 1 ) {
			break;
		}
		++$page;
		if ( $page > 50 ) {
			break;
		}
	}

	usort(
		$tracks,
		function ( $a, $b ) {
			return strcasecmp( $a['name'], $b['name'] );
		}
	);

	return $tracks;
}
