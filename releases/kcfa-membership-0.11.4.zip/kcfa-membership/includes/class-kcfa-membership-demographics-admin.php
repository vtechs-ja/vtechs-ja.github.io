<?php
/**
 * User profile: demographics (Phase 2).
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Demographics fields on user/profile screens.
 */
class Ontrack_Demographics_Admin {

	const NONCE_ACTION = 'ontrack_save_demographics';
	const NONCE_FIELD  = 'ontrack_demographics_nonce';

	/**
	 * Register hooks.
	 */
	public function register() {
		add_action( 'show_user_profile', array( $this, 'render_fields' ) );
		add_action( 'edit_user_profile', array( $this, 'render_fields' ) );
		add_action( 'user_profile_update_errors', array( $this, 'validate_on_submit' ), 10, 3 );
		add_action( 'personal_options_update', array( $this, 'save_profile' ) );
		add_action( 'edit_user_profile_update', array( $this, 'save_profile' ) );
	}

	/**
	 * Add validation errors before profile save completes.
	 *
	 * @param WP_Error $errors  Errors.
	 * @param bool     $update  Whether updating existing user.
	 * @param WP_User  $user    User object.
	 */
	public function validate_on_submit( $errors, $update, $user ) {
		if ( ! is_wp_error( $errors ) || ! $user instanceof WP_User ) {
			return;
		}

		if ( ! isset( $_POST[ self::NONCE_FIELD ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE_FIELD ] ) ), self::NONCE_ACTION ) ) {
			return;
		}

		if ( ! ontrack_current_user_can_edit_demographics_for_user( $user->ID ) ) {
			$errors->add( 'ontrack_demographics_permission', __( 'You are not allowed to update these demographic fields.', 'ontrack' ) );
			return;
		}

		$dob_raw = isset( $_POST['kcfa_date_of_birth'] ) ? sanitize_text_field( wp_unslash( $_POST['kcfa_date_of_birth'] ) ) : '';

		if ( '' !== $dob_raw && ! ontrack_is_valid_date_of_birth_string( $dob_raw ) ) {
			$errors->add( 'kcfa_date_of_birth', __( 'Please enter a valid date of birth (YYYY-MM-DD), not in the future.', 'ontrack' ) );
		}
	}

	/**
	 * Output demographics section.
	 *
	 * @param WP_User $user User being edited.
	 */
	public function render_fields( $user ) {
		if ( ! $user instanceof WP_User ) {
			return;
		}

		if ( ! ontrack_current_user_can_edit_demographics_for_user( $user->ID ) ) {
			return;
		}

		$dob     = get_user_meta( $user->ID, ontrack_meta_key_date_of_birth(), true );
		$dob     = is_string( $dob ) ? $dob : '';
		$gender  = ontrack_get_user_gender( $user->ID );
		$city    = ontrack_get_user_city( $user->ID );
		$country = ontrack_get_user_country( $user->ID );

		wp_nonce_field( self::NONCE_ACTION, self::NONCE_FIELD );
		?>
		<h2 id="ontrack-demographics-heading"><?php esc_html_e( 'Demographics', 'ontrack' ); ?></h2>
		<p class="description" id="ontrack-demographics-desc">
			<?php esc_html_e( 'Used for group mismatch checks in a later phase. All fields optional unless your organization requires them.', 'ontrack' ); ?>
		</p>
		<table class="form-table" role="presentation" aria-labelledby="ontrack-demographics-heading" aria-describedby="ontrack-demographics-desc">
			<tr>
				<th scope="row"><label for="kcfa_date_of_birth"><?php esc_html_e( 'Date of birth', 'ontrack' ); ?></label></th>
				<td>
					<input type="date" name="kcfa_date_of_birth" id="kcfa_date_of_birth" class="regular-text" value="<?php echo esc_attr( $dob ); ?>" autocomplete="bday" />
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Gender', 'ontrack' ); ?></th>
				<td>
					<fieldset>
						<legend class="screen-reader-text"><span><?php esc_html_e( 'Gender', 'ontrack' ); ?></span></legend>
						<?php
						$choices = ontrack_gender_choices();
						foreach ( $choices as $slug => $label ) :
							$input_id = 'kcfa_gender_' . ( '' === $slug ? 'unspecified' : $slug );
							?>
							<label style="margin-right: 1.25em;">
								<input type="radio" name="kcfa_gender" id="<?php echo esc_attr( $input_id ); ?>" value="<?php echo esc_attr( $slug ); ?>" <?php checked( $gender, $slug ); ?> />
								<?php echo esc_html( $label ); ?>
							</label>
						<?php endforeach; ?>
					</fieldset>
					<p class="description"><?php esc_html_e( 'Male or female only.', 'ontrack' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="kcfa_city"><?php esc_html_e( 'City', 'ontrack' ); ?></label></th>
				<td>
					<input type="text" name="kcfa_city" id="kcfa_city" class="regular-text" value="<?php echo esc_attr( $city ); ?>" maxlength="120" autocomplete="address-level2" />
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="kcfa_country"><?php esc_html_e( 'Country', 'ontrack' ); ?></label></th>
				<td>
					<input type="text" name="kcfa_country" id="kcfa_country" class="regular-text" value="<?php echo esc_attr( $country ); ?>" maxlength="120" autocomplete="country-name" />
				</td>
			</tr>
		</table>
		<?php
	}

	/**
	 * Save demographics when nonce and caps pass.
	 *
	 * @param int $user_id User ID.
	 */
	public function save_profile( $user_id ) {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 ) {
			return;
		}

		if ( ! isset( $_POST[ self::NONCE_FIELD ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE_FIELD ] ) ), self::NONCE_ACTION ) ) {
			return;
		}

		if ( ! ontrack_current_user_can_edit_demographics_for_user( $user_id ) ) {
			return;
		}

		$dob_raw = isset( $_POST['kcfa_date_of_birth'] ) ? sanitize_text_field( wp_unslash( $_POST['kcfa_date_of_birth'] ) ) : '';
		$dob     = ontrack_sanitize_date_of_birth( $dob_raw );

		$gender = ontrack_sanitize_gender( isset( $_POST['kcfa_gender'] ) ? wp_unslash( $_POST['kcfa_gender'] ) : '' );
		$city   = ontrack_sanitize_location_field( isset( $_POST['kcfa_city'] ) ? wp_unslash( $_POST['kcfa_city'] ) : '', 120 );
		$country = ontrack_sanitize_location_field( isset( $_POST['kcfa_country'] ) ? wp_unslash( $_POST['kcfa_country'] ) : '', 120 );

		if ( '' === $dob ) {
			delete_user_meta( $user_id, ontrack_meta_key_date_of_birth() );
		} else {
			update_user_meta( $user_id, ontrack_meta_key_date_of_birth(), $dob );
		}

		if ( '' === $gender ) {
			delete_user_meta( $user_id, ontrack_meta_key_gender() );
		} else {
			update_user_meta( $user_id, ontrack_meta_key_gender(), $gender );
		}

		if ( '' === $city ) {
			delete_user_meta( $user_id, ontrack_meta_key_city() );
		} else {
			update_user_meta( $user_id, ontrack_meta_key_city(), $city );
		}

		if ( '' === $country ) {
			delete_user_meta( $user_id, ontrack_meta_key_country() );
		} else {
			update_user_meta( $user_id, ontrack_meta_key_country(), $country );
		}

		// Remove legacy meta from earlier plugin versions.
		delete_user_meta( $user_id, 'kcfa_gender_detail' );
	}
}
