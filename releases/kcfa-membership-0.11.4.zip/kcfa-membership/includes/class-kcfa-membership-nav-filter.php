<?php
/**
 * Members-only nav menu filtering.
 *
 * Removes nav items with the CSS class 'members-only' for visitors who are
 * not logged-in full members (any klac role).
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ontrack_Nav_Filter {

	public static function init() {
		add_filter( 'wp_nav_menu_objects', array( __CLASS__, 'filter_members_only_items' ), 10, 2 );
	}

	/**
	 * Remove nav items with CSS class 'members-only' for non-members, and
	 * remove group-restricted items for members not in an allowed group.
	 *
	 * @param WP_Post[] $items Nav menu items.
	 * @param stdClass  $args  Nav menu args.
	 * @return WP_Post[]
	 */
	public static function filter_members_only_items( $items, $args ) {
		if ( is_admin() ) {
			return $items;
		}

		$is_member = self::current_user_is_member();
		$user_id   = get_current_user_id();

		return array_values( array_filter( $items, function ( $item ) use ( $is_member, $user_id ) {
			// Hide members-only items from non-members.
			if ( ! $is_member && in_array( 'members-only', (array) $item->classes, true ) ) {
				return false;
			}

			// Hide group-restricted items when the user lacks group access.
			if ( $item->object_id && function_exists( 'ontrack_user_has_group_access' ) ) {
				$allowed_ids = array_map( 'intval', array_filter( (array) get_post_meta( (int) $item->object_id, '_ontrack_tab_allowed_group_ids', true ) ) );
				if ( ! empty( $allowed_ids ) ) {
					if ( ! $user_id ) {
						return false;
					}
					$has_access = false;
					foreach ( $allowed_ids as $gid ) {
						if ( ontrack_user_has_group_access( $user_id, $gid ) ) {
							$has_access = true;
							break;
						}
					}
					if ( ! $has_access ) {
						return false;
					}
				}
			}

			return true;
		} ) );
	}

	private static function current_user_is_member() {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		if ( function_exists( 'ontrack_user_is_full_member' ) ) {
			return ontrack_user_is_full_member();
		}
		// Fallback: check for any klac role.
		$user         = wp_get_current_user();
		$member_roles = array( 'klac_member', 'klac_leader', 'klac_community_leader', 'klac_admin' );
		return (bool) array_intersect( $member_roles, (array) $user->roles );
	}
}
