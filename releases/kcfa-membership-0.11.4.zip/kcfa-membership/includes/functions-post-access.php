<?php
/**
 * Group-based access control and feed ordering for standard posts.
 *
 * Extends _klac_allowed_group_ids (used by CPTs) to the post type.
 * Adds _klac_pinned for mobile feed ordering (pinned posts sort first).
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register post meta for group restriction and feed pinning.
 */
function ontrack_register_post_access_meta() {
	$auth = static function () {
		return current_user_can( 'edit_posts' );
	};

	register_post_meta(
		'post',
		'_ontrack_allowed_group_ids',
		array(
			'type'          => 'array',
			'single'        => true,
			'auth_callback' => $auth,
			'show_in_rest'  => false,
		)
	);

	register_post_meta(
		'post',
		'_ontrack_pinned',
		array(
			'type'          => 'boolean',
			'single'        => true,
			'default'       => false,
			'auth_callback' => $auth,
			'show_in_rest'  => false,
		)
	);
}
add_action( 'init', 'ontrack_register_post_access_meta', 11 );

/**
 * Return post IDs that should be excluded from feeds/queries for the given user.
 *
 * Used by both the rest_post_query filter and the tab composite endpoint so the
 * exclusion logic lives in one place.
 *
 * @param int $user_id 0 for unauthenticated.
 * @return int[]
 */
function ontrack_get_post_excluded_ids_for_user( $user_id ) {
	if ( $user_id > 0 && current_user_can( 'edit_posts' ) ) {
		return array();
	}

	if ( $user_id > 0 && ontrack_user_is_full_member( $user_id ) ) {
		return ontrack_get_group_excluded_ids_for_user( $user_id, 'post' );
	}

	return get_posts( array(
		'post_type'      => 'post',
		'posts_per_page' => -1,
		'fields'         => 'ids',
		'no_found_rows'  => true,
		'meta_query'     => array(
			array(
				'key'     => '_ontrack_allowed_group_ids',
				'compare' => 'EXISTS',
			),
		),
	) );
}

/**
 * Filter WP REST API post queries to exclude posts the current user cannot access.
 *
 * Full members: excludes posts whose group allowlist doesn't include any of the user's groups.
 * Non-members / unauthenticated: excludes all group-restricted posts.
 * Editors and above: no restriction.
 * Only active when REST enforcement is enabled.
 *
 * @param array           $args    WP_Query args.
 * @param WP_REST_Request $request REST request.
 * @return array
 */
function ontrack_rest_post_query( array $args, WP_REST_Request $request ) {
	if ( ! ontrack_is_rest_enforcement_enabled() ) {
		return $args;
	}

	$user_id  = get_current_user_id();
	$excluded = ontrack_get_post_excluded_ids_for_user( $user_id );

	if ( ! empty( $excluded ) ) {
		$not_in               = isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array();
		$args['post__not_in'] = array_unique( array_merge( $not_in, array_map( 'intval', $excluded ) ) );
	}

	return $args;
}
add_filter( 'rest_post_query', 'ontrack_rest_post_query', 10, 2 );
