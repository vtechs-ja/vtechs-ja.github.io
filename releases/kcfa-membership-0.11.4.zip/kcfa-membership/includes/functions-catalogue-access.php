<?php
/**
 * Audio / Video collection visibility: meta, archive query hints, capability checks.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Post meta: catalogue access tier for Ontrack collections.
 *
 * @return string
 */
function ontrack_catalogue_access_meta_key() {
	return 'ontrack_catalogue_access';
}

/**
 * Post types that participate in catalogue gating (theme-registered CPTs).
 *
 * @return string[]
 */
function ontrack_get_catalogue_post_types() {
	$types = array( 'audio_collection', 'video_collection' );
	/**
	 * Filter catalogue post types that use kcfa_catalogue_access meta.
	 *
	 * @param string[] $types Post type slugs.
	 */
	return apply_filters( 'ontrack_catalogue_post_types', $types );
}

/**
 * Allowed access level slugs => admin labels.
 *
 * @return array<string, string>
 */
function ontrack_catalogue_access_level_labels() {
	return array(
		'public'      => __( 'Public — anyone', 'ontrack' ),
		'visitor'     => __( 'Logged-in visitors — not full members', 'ontrack' ),
		'full_member' => __( 'Full members only', 'ontrack' ),
	);
}

/**
 * Valid slugs only.
 *
 * @return string[]
 */
function ontrack_catalogue_access_level_slugs() {
	return array_keys( ontrack_catalogue_access_level_labels() );
}

/**
 * Sanitize stored access level.
 *
 * @param mixed $value Raw.
 * @return string
 */
function ontrack_sanitize_catalogue_access_level( $value ) {
	$value = is_string( $value ) ? sanitize_key( $value ) : '';
	if ( in_array( $value, ontrack_catalogue_access_level_slugs(), true ) ) {
		return $value;
	}
	return 'full_member';
}

/**
 * Whether Settings → KCFA Membership has catalogue enforcement enabled.
 *
 * @return bool
 */
function ontrack_is_catalogue_enforcement_enabled() {
	$opts = ontrack_get_options();
	return ! empty( $opts['catalogue_enforcement_enabled'] );
}

/**
 * Resolved access level for a collection post (missing/invalid → full_member).
 *
 * @param int $post_id Post ID.
 * @return string public|visitor|full_member
 */
function ontrack_get_collection_access_level( $post_id ) {
	$post_id = (int) $post_id;
	if ( $post_id <= 0 ) {
		return 'full_member';
	}
	$raw = get_post_meta( $post_id, ontrack_catalogue_access_meta_key(), true );
	return ontrack_sanitize_catalogue_access_level( $raw );
}

/**
 * Whether a user may view this collection on the front end when enforcement is on.
 *
 * When enforcement is off, always true (filter still runs).
 *
 * @param int      $post_id Post ID.
 * @param int|null $user_id User ID or null for current user.
 * @return bool
 */
function ontrack_user_can_view_collection( $post_id, $user_id = null ) {
	$post_id = (int) $post_id;
	if ( $post_id <= 0 ) {
		$can = false;
		return (bool) apply_filters( 'ontrack_user_can_view_collection', $can, $post_id, $user_id );
	}

	if ( ! ontrack_is_catalogue_enforcement_enabled() ) {
		return (bool) apply_filters( 'ontrack_user_can_view_collection', true, $post_id, $user_id );
	}

	if ( is_user_logged_in() && current_user_can( 'edit_post', $post_id ) ) {
		return (bool) apply_filters( 'ontrack_user_can_view_collection', true, $post_id, $user_id );
	}

	if ( null === $user_id ) {
		$user_id = get_current_user_id();
	} else {
		$user_id = (int) $user_id;
	}

	$level = ontrack_get_collection_access_level( $post_id );

	if ( $user_id <= 0 ) {
		$can = ( 'public' === $level );
	} elseif ( ontrack_user_is_full_member( $user_id ) ) {
		$allowed_groups = ontrack_get_collection_allowed_group_ids( $post_id );
		if ( ! empty( $allowed_groups ) ) {
			$user_groups = ontrack_get_user_effective_group_ids( $user_id );
			$can         = (bool) array_intersect( $allowed_groups, $user_groups );
		} else {
			$can = true;
		}
	} else {
		$can = ( 'public' === $level || 'visitor' === $level );
	}

	return (bool) apply_filters( 'ontrack_user_can_view_collection', $can, $post_id, $user_id );
}

/**
 * Current visitor may view collection.
 *
 * @param int $post_id Post ID.
 * @return bool
 */
function ontrack_current_user_can_view_collection( $post_id ) {
	return ontrack_user_can_view_collection( $post_id, null );
}

/**
 * meta_query fragment for main archive query, or null when no extra restriction.
 *
 * @param int|null $user_id User ID or null for current user.
 * @return array<string, mixed>|null
 */
function ontrack_get_catalogue_archive_meta_query( $user_id = null ) {
	if ( ! ontrack_is_catalogue_enforcement_enabled() ) {
		return null;
	}
	if ( null === $user_id ) {
		$user_id = get_current_user_id();
	} else {
		$user_id = (int) $user_id;
	}

	$key = ontrack_catalogue_access_meta_key();

	if ( $user_id > 0 && ontrack_user_is_full_member( $user_id ) ) {
		return null;
	}

	if ( $user_id > 0 ) {
		return array(
			'relation' => 'OR',
			array(
				'key'     => $key,
				'value'   => 'public',
				'compare' => '=',
			),
			array(
				'key'     => $key,
				'value'   => 'visitor',
				'compare' => '=',
			),
		);
	}

	return array(
		array(
			'key'     => $key,
			'value'   => 'public',
			'compare' => '=',
		),
	);
}

/**
 * Allowed group IDs for a collection (empty = no group restriction).
 *
 * @param int $post_id Post ID.
 * @return int[]
 */
function ontrack_get_collection_allowed_group_ids( $post_id ) {
	$ids = get_post_meta( (int) $post_id, '_ontrack_allowed_group_ids', true );
	if ( ! is_array( $ids ) ) {
		return array();
	}
	return array_values( array_filter( array_map( 'intval', $ids ) ) );
}

/**
 * Collection IDs of a given post type that the user cannot access due to group restrictions.
 *
 * @param int    $user_id   User ID.
 * @param string $post_type Post type slug.
 * @return int[]
 */
function ontrack_get_group_excluded_ids_for_user( $user_id, $post_type ) {
	$restricted = get_posts( array(
		'post_type'      => $post_type,
		'posts_per_page' => -1,
		'fields'         => 'ids',
		'no_found_rows'  => true,
		'meta_query'     => array(
			array(
				'key'     => '_ontrack_allowed_group_ids',
				'compare' => 'EXISTS',
			),
		),
	) );

	if ( empty( $restricted ) ) {
		return array();
	}

	$user_group_ids = ontrack_get_user_effective_group_ids( (int) $user_id );
	$excluded       = array();

	foreach ( $restricted as $cid ) {
		$allowed = ontrack_get_collection_allowed_group_ids( $cid );
		if ( empty( $allowed ) ) {
			continue;
		}
		if ( ! array_intersect( $allowed, $user_group_ids ) ) {
			$excluded[] = (int) $cid;
		}
	}

	return $excluded;
}

/**
 * Register post meta after theme registers CPTs.
 */
function ontrack_register_catalogue_access_post_meta() {
	$auth = static function () {
		return current_user_can( 'edit_posts' );
	};
	foreach ( ontrack_get_catalogue_post_types() as $pt ) {
		if ( ! post_type_exists( $pt ) ) {
			continue;
		}
		register_post_meta(
			$pt,
			ontrack_catalogue_access_meta_key(),
			array(
				'type'              => 'string',
				'single'            => true,
				'sanitize_callback' => 'ontrack_sanitize_catalogue_access_level',
				'auth_callback'     => $auth,
				'show_in_rest'      => true,
				'default'           => 'full_member',
			)
		);
	}
}
add_action( 'init', 'ontrack_register_catalogue_access_post_meta', 11 );

/**
 * Meta box for collection edit screens.
 */
function ontrack_catalogue_access_add_meta_box() {
	foreach ( ontrack_get_catalogue_post_types() as $pt ) {
		if ( post_type_exists( $pt ) ) {
			add_meta_box(
				'kcfa_catalogue_access',
				__( 'Catalogue access', 'ontrack' ),
				'ontrack_catalogue_access_meta_box_callback',
				$pt,
				'side',
				'default'
			);
		}
	}
}

/**
 * @param WP_Post $post Post.
 */
function ontrack_catalogue_access_meta_box_callback( $post ) {
	wp_nonce_field( 'kcfa_catalogue_access_save', 'kcfa_catalogue_access_nonce' );
	$current        = ontrack_get_collection_access_level( $post->ID );
	$name           = ontrack_catalogue_access_meta_key();
	$allowed_groups = ontrack_get_collection_allowed_group_ids( $post->ID );
	$all_groups     = get_posts( array(
		'post_type'      => ontrack_group_post_type(),
		'posts_per_page' => -1,
		'orderby'        => 'title',
		'order'          => 'ASC',
		'post_status'    => 'publish',
		'no_found_rows'  => true,
	) );

	echo '<p><label for="kcfa_catalogue_access_select" class="screen-reader-text">' . esc_html__( 'Access level', 'ontrack' ) . '</label>';
	echo '<select name="' . esc_attr( $name ) . '" id="kcfa_catalogue_access_select" style="max-width:100%;">';
	foreach ( ontrack_catalogue_access_level_labels() as $slug => $label ) {
		printf(
			'<option value="%s"%s>%s</option>',
			esc_attr( $slug ),
			selected( $current, $slug, false ),
			esc_html( $label )
		);
	}
	echo '</select></p>';
	echo '<p class="description">';
	esc_html_e( 'Used when catalogue enforcement is enabled in KCFA Membership settings. Collections without a saved value behave as full-member-only.', 'ontrack' );
	echo '</p>';

	if ( ! empty( $all_groups ) ) {
		$show = ( 'full_member' === $current );
		echo '<div id="ontrack-group-restrict-wrap" style="' . ( $show ? '' : 'display:none;' ) . 'margin-top:1em;border-top:1px solid #ddd;padding-top:0.75em;">';
		echo '<p style="margin:0 0 0.25em;"><strong>' . esc_html__( 'Restrict to groups (optional)', 'ontrack' ) . '</strong></p>';
		echo '<p class="description" style="margin-bottom:0.5em;">' . esc_html__( 'Leave all unchecked to allow any full member. Check groups to limit access to only those members.', 'ontrack' ) . '</p>';
		foreach ( $all_groups as $group ) {
			printf(
				'<label style="display:block;margin-bottom:0.2em;"><input type="checkbox" name="ontrack_allowed_group_ids[]" value="%d"%s /> %s</label>',
				(int) $group->ID,
				checked( in_array( (int) $group->ID, $allowed_groups, true ), true, false ),
				esc_html( $group->post_title )
			);
		}
		echo '</div>';
		?>
		<script>
		(function () {
			var sel  = document.getElementById( 'kcfa_catalogue_access_select' );
			var wrap = document.getElementById( 'ontrack-group-restrict-wrap' );
			if ( sel && wrap ) {
				sel.addEventListener( 'change', function () {
					wrap.style.display = sel.value === 'full_member' ? '' : 'none';
				} );
			}
		} )();
		</script>
		<?php
	}
}

/**
 * @param int $post_id Post ID.
 */
function ontrack_catalogue_access_save_post( $post_id ) {
	if ( ! isset( $_POST['kcfa_catalogue_access_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kcfa_catalogue_access_nonce'] ) ), 'kcfa_catalogue_access_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$pt = get_post_type( $post_id );
	if ( ! in_array( $pt, ontrack_get_catalogue_post_types(), true ) ) {
		return;
	}
	$key = ontrack_catalogue_access_meta_key();
	if ( ! isset( $_POST[ $key ] ) ) {
		return;
	}
	$val = ontrack_sanitize_catalogue_access_level( wp_unslash( $_POST[ $key ] ) );
	update_post_meta( $post_id, $key, $val );

	// Save group restrictions (only meaningful for full_member tier).
	if ( 'full_member' === $val && isset( $_POST['ontrack_allowed_group_ids'] ) && is_array( $_POST['ontrack_allowed_group_ids'] ) ) {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$group_ids = array_values( array_filter( array_map( 'intval', wp_unslash( $_POST['ontrack_allowed_group_ids'] ) ) ) );
		update_post_meta( $post_id, '_ontrack_allowed_group_ids', $group_ids );
	} else {
		delete_post_meta( $post_id, '_ontrack_allowed_group_ids' );
	}
}

/**
 * Admin hooks for meta box.
 */
function ontrack_catalogue_access_admin_boot() {
	if ( ! is_admin() ) {
		return;
	}
	add_action( 'add_meta_boxes', 'ontrack_catalogue_access_add_meta_box' );
	add_action( 'save_post', 'ontrack_catalogue_access_save_post', 10, 1 );
}
add_action( 'plugins_loaded', 'ontrack_catalogue_access_admin_boot', 20 );

/**
 * Limit archive listing to collections the current user may see.
 *
 * @param WP_Query $query Query.
 */
function ontrack_catalogue_access_pre_get_posts( $query ) {
	if ( ! $query->is_main_query() || is_admin() ) {
		return;
	}
	if ( ! $query->is_post_type_archive() ) {
		return;
	}
	$pt        = $query->get( 'post_type' );
	$catalogue = ontrack_get_catalogue_post_types();
	$in_scope  = is_array( $pt )
		? (bool) array_intersect( $pt, $catalogue )
		: in_array( $pt, $catalogue, true );
	if ( ! $in_scope || ! ontrack_is_catalogue_enforcement_enabled() ) {
		return;
	}

	$user_id   = get_current_user_id();
	$post_type = is_array( $pt ) ? reset( $pt ) : $pt;

	if ( $user_id > 0 && ontrack_user_is_full_member( $user_id ) ) {
		// Full members: only group restrictions apply.
		$excluded = ontrack_get_group_excluded_ids_for_user( $user_id, $post_type );
		if ( ! empty( $excluded ) ) {
			$not_in = (array) $query->get( 'post__not_in' );
			$query->set( 'post__not_in', array_unique( array_merge( $not_in, $excluded ) ) );
		}
		return;
	}

	// Non-members and visitors: apply tier-based meta query.
	$mq = ontrack_get_catalogue_archive_meta_query( $user_id ?: null );
	if ( null === $mq ) {
		return;
	}
	$existing = $query->get( 'meta_query' );
	if ( ! empty( $existing ) && is_array( $existing ) ) {
		$query->set( 'meta_query', array( 'relation' => 'AND', $existing, $mq ) );
	} else {
		$query->set( 'meta_query', $mq );
	}
}
add_action( 'pre_get_posts', 'ontrack_catalogue_access_pre_get_posts', 10, 1 );

/**
 * Block singular collection pages when the viewer lacks access.
 */
function ontrack_catalogue_access_template_redirect() {
	if ( ! ontrack_is_catalogue_enforcement_enabled() ) {
		return;
	}
	if ( is_feed() || wp_doing_ajax() || wp_is_json_request() ) {
		return;
	}
	if ( is_preview() ) {
		$preview_id = (int) get_query_var( 'preview_id' );
		if ( $preview_id && current_user_can( 'edit_post', $preview_id ) ) {
			return;
		}
		$qid = get_queried_object_id();
		if ( $qid && current_user_can( 'edit_post', $qid ) ) {
			return;
		}
	}
	if ( ! is_singular( ontrack_get_catalogue_post_types() ) ) {
		return;
	}
	$post = get_queried_object();
	if ( ! $post instanceof WP_Post ) {
		return;
	}
	if ( ontrack_current_user_can_view_collection( (int) $post->ID ) ) {
		return;
	}
	if ( ! is_user_logged_in() ) {
		auth_redirect();
	}
	global $wp_query;
	$wp_query->set_404();
	status_header( 404 );
	nocache_headers();
}
add_action( 'template_redirect', 'ontrack_catalogue_access_template_redirect', 5 );
