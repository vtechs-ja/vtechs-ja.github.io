<?php
/**
 * The front page template file
 *
 * @package Ontrack
 */

get_header();
?>

	<?php
	// Display banner slider on homepage (outside main container for full width)
	if ( is_front_page() ) {
		get_template_part( 'template-parts/banner-slider' );
	}
	?>

	<main id="primary" class="site-main">

		<?php

		if ( have_posts() ) :

			/* Start the Loop */
			while ( have_posts() ) :
				the_post();

				get_template_part( 'template-parts/content', get_post_type() );

			endwhile;

			the_posts_navigation();

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>

	</main><!-- #main -->

	<?php get_template_part( 'template-parts/home-focus-areas' ); ?>

<?php
get_sidebar();
get_footer();

