<?php
/**
 * Template for displaying a single Video Collection.
 *
 * @package Ontrack
 */

get_header();
?>

	<main id="primary" class="site-main">

		<?php
		while ( have_posts() ) :
			the_post();
			get_template_part( 'template-parts/content', 'video_collection' );
		endwhile;
		?>

	</main><!-- #main -->

<?php
get_sidebar();
get_footer();
