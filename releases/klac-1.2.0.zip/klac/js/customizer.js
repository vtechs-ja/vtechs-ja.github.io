/* global wp, jQuery */
/**
 * File customizer.js.
 *
 * Theme Customizer enhancements for a better user experience.
 *
 * Contains handlers to make Theme Customizer preview reload changes asynchronously.
 */

( function( $ ) {
	// Site title and description.
	wp.customize( 'blogname', function( value ) {
		value.bind( function( to ) {
			$( '.site-title a' ).text( to );
		} );
	} );
	wp.customize( 'blogdescription', function( value ) {
		value.bind( function( to ) {
			$( '.site-description' ).text( to );
		} );
	} );

	// Header text color.
	wp.customize( 'header_textcolor', function( value ) {
		value.bind( function( to ) {
			if ( 'blank' === to ) {
				$( '.site-title, .site-description' ).css( {
					clip: 'rect(1px, 1px, 1px, 1px)',
					position: 'absolute',
				} );
			} else {
				$( '.site-title, .site-description' ).css( {
					clip: 'auto',
					position: 'relative',
				} );
				$( '.site-title a, .site-description' ).css( {
					color: '#' + to,
				} );
			}
		} );
	} );

	// Background color.
	wp.customize( 'background_color', function( value ) {
		value.bind( function( to ) {
			$( 'body' ).css( {
				'background-color': '#' + to,
			} );
		} );
	} );

	// Primary color.
	wp.customize( 'klac_primary_color', function( value ) {
		value.bind( function( to ) {
			$( 'a, .entry-content a, .main-navigation a:hover, .main-navigation a:focus, .footer-navigation a:hover, .footer-navigation a:focus' ).css( {
				color: to,
			} );
		} );
	} );

	// Secondary color.
	wp.customize( 'klac_secondary_color', function( value ) {
		value.bind( function( to ) {
			$( '.main-navigation .current-menu-item > a, .main-navigation .current_page_item > a' ).css( {
				color: to,
			} );
		} );
	} );

	// Accent color.
	wp.customize( 'klac_accent_color', function( value ) {
		value.bind( function( to ) {
			$( 'button, input[type="button"], input[type="submit"]' ).css( {
				'background-color': to,
				'border-color': to,
			} );
		} );
	} );

	// Text color.
	wp.customize( 'klac_text_color', function( value ) {
		value.bind( function( to ) {
			$( 'body, .entry-title, .entry-content, .main-navigation a, .site-info .copyright, .footer-navigation a, .menu-toggle span' ).css( {
				color: to,
			} );
			$( '.menu-toggle span' ).css( {
				'background-color': to,
			} );
		} );
	} );

	// Header background.
	wp.customize( 'klac_header_background', function( value ) {
		value.bind( function( to ) {
			$( '.site-header' ).css( {
				'background-color': to,
			} );
		} );
	} );

	// Footer background.
	wp.customize( 'klac_footer_background', function( value ) {
		value.bind( function( to ) {
			$( '.site-footer' ).css( {
				'background-color': to,
			} );
		} );
	} );

	// Typography - Site Title
	wp.customize( 'klac_site_title_font', function( value ) {
		value.bind( function( to ) {
			var fontFamily = getFontFamily( to );
			$( '.site-title, .site-title a' ).css( {
				'font-family': fontFamily,
			} );
		} );
	} );
	wp.customize( 'klac_site_title_size', function( value ) {
		value.bind( function( to ) {
			var size = isNaN( to ) ? to : to + 'rem';
			$( '.site-title, .site-title a' ).css( {
				'font-size': size,
			} );
		} );
	} );

	// Typography - Menu
	wp.customize( 'klac_menu_font', function( value ) {
		value.bind( function( to ) {
			var fontFamily = getFontFamily( to );
			$( '.main-navigation a, .footer-navigation a' ).css( {
				'font-family': fontFamily,
			} );
		} );
	} );
	wp.customize( 'klac_menu_size', function( value ) {
		value.bind( function( to ) {
			var size = isNaN( to ) ? to : to + 'rem';
			$( '.main-navigation a, .footer-navigation a' ).css( {
				'font-size': size,
			} );
		} );
	} );

	// Typography - Body
	wp.customize( 'klac_body_font', function( value ) {
		value.bind( function( to ) {
			var fontFamily = getFontFamily( to );
			$( 'body, .entry-content, .entry-content p' ).css( {
				'font-family': fontFamily,
			} );
		} );
	} );
	wp.customize( 'klac_body_size', function( value ) {
		value.bind( function( to ) {
			var size = isNaN( to ) ? to : to + 'rem';
			$( 'body, .entry-content, .entry-content p' ).css( {
				'font-size': size,
			} );
		} );
	} );

	// Typography - Headings
	var headings = [
		{ setting: 'klac_h1_font', sizeSetting: 'klac_h1_size', selector: 'h1, .entry-title, .entry-content h1' },
		{ setting: 'klac_h2_font', sizeSetting: 'klac_h2_size', selector: 'h2, .entry-content h2' },
		{ setting: 'klac_h3_font', sizeSetting: 'klac_h3_size', selector: 'h3, .entry-content h3' },
		{ setting: 'klac_h4_font', sizeSetting: 'klac_h4_size', selector: 'h4, .entry-content h4' },
		{ setting: 'klac_h5_font', sizeSetting: 'klac_h5_size', selector: 'h5, .entry-content h5' },
		{ setting: 'klac_h6_font', sizeSetting: 'klac_h6_size', selector: 'h6, .entry-content h6' },
	];

	headings.forEach( function( heading ) {
		wp.customize( heading.setting, function( value ) {
			value.bind( function( to ) {
				var fontFamily = getFontFamily( to );
				$( heading.selector ).css( {
					'font-family': fontFamily,
				} );
			} );
		} );
		wp.customize( heading.sizeSetting, function( value ) {
			value.bind( function( to ) {
				var size = isNaN( to ) ? to : to + 'rem';
				$( heading.selector ).css( {
					'font-size': size,
				} );
			} );
		} );
	} );

	// Helper function to get font family CSS
	function getFontFamily( font ) {
		if ( 'system' === font ) {
			return '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif';
		}
		var googleFonts = [
			'Roboto', 'Open Sans', 'Lato', 'Montserrat', 'Poppins',
			'Playfair Display', 'Merriweather', 'Source Sans Pro',
			'Raleway', 'Oswald', 'Lora', 'PT Sans', 'Ubuntu'
		];
		if ( googleFonts.indexOf( font ) !== -1 ) {
			return '"' + font + '", sans-serif';
		}
		return font + ', sans-serif';
	}
}( jQuery ) );
