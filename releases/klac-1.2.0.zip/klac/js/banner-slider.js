/**
 * Banner Slider functionality
 */
(function() {
	'use strict';

	const bannerSlider = document.querySelector('.banner-slider');
	if (!bannerSlider) {
		return;
	}

	const slides = bannerSlider.querySelectorAll('.banner-slide');
	const indicators = bannerSlider.querySelectorAll('.banner-indicator');
	const prevButton = bannerSlider.querySelector('.banner-prev');
	const nextButton = bannerSlider.querySelector('.banner-next');
	const autoplay = bannerSlider.getAttribute('data-autoplay') === 'true';
	const duration = parseInt(bannerSlider.getAttribute('data-duration'), 10) || 5000;

	let currentSlide = 0;
	let autoplayInterval;

	// Function to show a specific slide
	function showSlide(index) {
		// Remove active class from all slides and indicators
		slides.forEach(slide => slide.classList.remove('active'));
		indicators.forEach(indicator => indicator.classList.remove('active'));

		// Add active class to current slide and indicator
		if (slides[index]) {
			slides[index].classList.add('active');
		}
		if (indicators[index]) {
			indicators[index].classList.add('active');
		}

		currentSlide = index;
	}

	// Function to go to next slide
	function nextSlide() {
		const next = (currentSlide + 1) % slides.length;
		showSlide(next);
		resetAutoplay();
	}

	// Function to go to previous slide
	function prevSlide() {
		const prev = (currentSlide - 1 + slides.length) % slides.length;
		showSlide(prev);
		resetAutoplay();
	}

	// Function to start autoplay
	function startAutoplay() {
		if (autoplay && slides.length > 1) {
			autoplayInterval = setInterval(nextSlide, duration);
		}
	}

	// Function to reset autoplay
	function resetAutoplay() {
		clearInterval(autoplayInterval);
		startAutoplay();
	}

	// Event listeners
	if (nextButton) {
		nextButton.addEventListener('click', nextSlide);
	}

	if (prevButton) {
		prevButton.addEventListener('click', prevSlide);
	}

	// Indicator clicks
	indicators.forEach((indicator, index) => {
		indicator.addEventListener('click', () => {
			showSlide(index);
			resetAutoplay();
		});
	});

	// Pause on hover
	bannerSlider.addEventListener('mouseenter', () => {
		clearInterval(autoplayInterval);
	});

	bannerSlider.addEventListener('mouseleave', () => {
		startAutoplay();
	});

	// Keyboard navigation
	document.addEventListener('keydown', (e) => {
		if (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA') {
			return;
		}
		if (e.key === 'ArrowLeft') {
			prevSlide();
		} else if (e.key === 'ArrowRight') {
			nextSlide();
		}
	});

	// Start autoplay
	startAutoplay();
})();



