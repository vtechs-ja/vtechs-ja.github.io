<?php
/**
 * Template Name: Members Section
 *
 * Used for child pages within the Members Area (e.g. Audio, Video).
 * Applies the same access checks as the Members Area template and renders
 * the shared sub-navigation above the page content.
 *
 * @package Ontrack
 */

// Redirect anonymous visitors to the login page (redirects back after login).
if ( ! is_user_logged_in() ) {
	auth_redirect();
}

$current_user = wp_get_current_user();
$is_member    = function_exists( 'ontrack_user_is_full_member' )
	? ontrack_user_is_full_member( $current_user->ID )
	: (bool) array_intersect(
		array( 'klac_member', 'klac_leader', 'klac_community_leader', 'klac_admin' ),
		(array) $current_user->roles
	);

get_header();

if ( ! $is_member ) {
	?>
	<main id="primary" class="site-main">
		<div class="ontrack-members-area">
			<?php get_template_part( 'template-parts/members-subnav' ); ?>
			<div class="ontrack-access-denied">
				<h1 class="ontrack-access-denied__heading"><?php esc_html_e( 'Members Only', 'ontrack' ); ?></h1>
				<p><?php esc_html_e( 'Your account does not currently have member access.', 'ontrack' ); ?></p>
				<p>
					<?php
					printf(
						/* translators: %s: admin email address */
						esc_html__( 'If you believe you should have access, please contact %s.', 'ontrack' ),
						'<a href="mailto:' . esc_attr( get_option( 'admin_email' ) ) . '">'
						. esc_html( get_option( 'admin_email' ) ) . '</a>'
					);
					?>
				</p>
				<a href="<?php echo esc_url( wp_logout_url( get_permalink() ) ); ?>" class="button">
					<?php esc_html_e( 'Log out', 'ontrack' ); ?>
				</a>
			</div>
		</div>
	</main>
	<?php
	get_footer();
	exit;
}
?>

	<main id="primary" class="site-main">

		<div class="ontrack-members-area">

			<?php get_template_part( 'template-parts/members-subnav' ); ?>

			<div class="ontrack-members-section-content">

				<?php while ( have_posts() ) : the_post(); ?>

					<header class="ontrack-members-section-content__header">
						<h1 class="ontrack-members-section-content__title"><?php the_title(); ?></h1>
					</header>

					<?php if ( get_the_content() ) : ?>
					<div class="entry-content">
						<?php the_content(); ?>
					</div>
					<?php endif; ?>

				<?php endwhile; ?>

			</div><!-- .ontrack-members-section-content -->

		</div><!-- .ontrack-members-area -->

	</main><!-- #primary -->

<?php
get_sidebar();
get_footer();
