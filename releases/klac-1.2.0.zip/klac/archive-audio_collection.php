<?php
/**
 * Archive template for Audio Collections.
 *
 * Displays a card grid — title, thumbnail, description, and a link to the
 * single collection page where the player loads. Does not embed the player
 * here to avoid loading every playlist simultaneously.
 *
 * @package Ontrack
 */

get_header();
?>

	<main id="primary" class="site-main">

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<?php the_archive_title( '<h1 class="page-title">', '</h1>' ); ?>
			</header>

			<div class="ontrack-collection-grid">

				<?php while ( have_posts() ) : the_post(); ?>

					<article id="post-<?php the_ID(); ?>" <?php post_class( 'ontrack-collection-card' ); ?>>

						<a class="ontrack-collection-card__thumbnail" href="<?php the_permalink(); ?>">
							<?php if ( has_post_thumbnail() ) : ?>
								<?php the_post_thumbnail( 'medium' ); ?>
							<?php else : ?>
								<div class="ontrack-collection-card__thumbnail-placeholder"></div>
							<?php endif; ?>
							<div class="ontrack-collection-card__overlay">
								<span class="ontrack-collection-card__badge"><?php esc_html_e( 'Audio', 'ontrack' ); ?></span>
								<h2 class="ontrack-collection-card__title"><?php the_title(); ?></h2>
							</div>
						</a>

						<div class="ontrack-collection-card__body">
							<?php if ( has_excerpt() || get_the_content() ) : ?>
								<div class="ontrack-collection-card__summary">
									<?php the_excerpt(); ?>
								</div>
							<?php endif; ?>

							<a class="ontrack-collection-card__cta button" href="<?php the_permalink(); ?>">
								<?php esc_html_e( 'Listen', 'ontrack' ); ?>
							</a>
						</div>

					</article>

				<?php endwhile; ?>

			</div><!-- .ontrack-collection-grid -->

			<?php the_posts_navigation(); ?>

		<?php else : ?>

			<?php get_template_part( 'template-parts/content', 'none' ); ?>

		<?php endif; ?>

	</main><!-- #main -->

<?php
get_sidebar();
get_footer();
