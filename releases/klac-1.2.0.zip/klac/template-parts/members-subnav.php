<?php
/**
 * Members Area sub-navigation.
 *
 * Uses the 'ontrack-members-nav' menu location if a menu is assigned there.
 * Falls back to auto-generating nav from child pages of the Members Area page.
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Find the root Members Area page (the one using this template).
$members_root_pages = get_pages( array(
	'meta_key'   => '_wp_page_template',
	'meta_value' => 'template-members-area.php',
	'number'     => 1,
) );
$members_root_id = ! empty( $members_root_pages ) ? (int) $members_root_pages[0]->ID : 0;

if ( has_nav_menu( 'ontrack-members-nav' ) ) {
	echo '<nav class="ontrack-members-subnav" aria-label="' . esc_attr__( 'Members navigation', 'ontrack' ) . '">';
	wp_nav_menu( array(
		'theme_location' => 'ontrack-members-nav',
		'container'      => false,
		'menu_class'     => 'ontrack-members-subnav__list',
		'depth'          => 1,
		'fallback_cb'    => false,
	) );
	echo '</nav>';
} elseif ( $members_root_id ) {
	// Auto-generate from the root page + its child pages.
	$children = get_pages( array(
		'parent'      => $members_root_id,
		'sort_column' => 'menu_order',
		'sort_order'  => 'ASC',
		'post_status' => 'publish',
	) );
	$current_id = (int) get_the_ID();
	?>
	<nav class="ontrack-members-subnav" aria-label="<?php esc_attr_e( 'Members navigation', 'ontrack' ); ?>">
		<ul class="ontrack-members-subnav__list">
			<li class="ontrack-members-subnav__item<?php echo $current_id === $members_root_id ? ' is-active' : ''; ?>">
				<a class="ontrack-members-subnav__link" href="<?php echo esc_url( get_permalink( $members_root_id ) ); ?>">
					<?php echo esc_html( get_the_title( $members_root_id ) ); ?>
				</a>
			</li>
			<?php foreach ( $children as $child ) : ?>
				<li class="ontrack-members-subnav__item<?php echo $current_id === (int) $child->ID ? ' is-active' : ''; ?>">
					<a class="ontrack-members-subnav__link" href="<?php echo esc_url( get_permalink( $child ) ); ?>">
						<?php echo esc_html( $child->post_title ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</nav>
	<?php
}
