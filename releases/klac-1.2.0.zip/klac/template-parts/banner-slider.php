<?php
/**
 * Template part for displaying banner slider
 *
 * @package Ontrack
 */

$banners = ontrack_get_banners();

if ( empty( $banners ) || ! get_theme_mod( 'klac_banner_enable', true ) ) {
	return;
}

$banner_height = get_theme_mod( 'klac_banner_height', 500 );
$autoplay = get_theme_mod( 'klac_banner_autoplay', true );
$duration = get_theme_mod( 'klac_banner_duration', 5000 );
?>

<section class="banner-slider" data-autoplay="<?php echo esc_attr( $autoplay ? 'true' : 'false' ); ?>" data-duration="<?php echo esc_attr( $duration ); ?>" style="height: <?php echo esc_attr( $banner_height ); ?>px;">
	<div class="banner-slides">
		<?php foreach ( $banners as $index => $banner ) : 
			$image = get_the_post_thumbnail_url( $banner->ID, 'full' );
			$link = get_post_meta( $banner->ID, '_klac_banner_link', true );
			$button_text = get_post_meta( $banner->ID, '_klac_banner_button_text', true );
			$overlay = get_post_meta( $banner->ID, '_klac_banner_overlay', true );
			$is_active = 0 === $index ? 'active' : '';
		?>
			<div class="banner-slide <?php echo esc_attr( $is_active ); ?>" style="background-image: url('<?php echo esc_url( $image ); ?>');">
				<?php if ( $overlay ) : ?>
					<div class="banner-overlay"></div>
				<?php endif; ?>
				<?php if ( ! empty( $banner->post_content ) || ( ! empty( $link ) && ! empty( $button_text ) ) ) : ?>
					<div class="banner-content">
						<div class="banner-text">
							<?php if ( ! empty( $banner->post_content ) ) : ?>
								<div class="banner-description">
									<?php echo wp_kses_post( wpautop( $banner->post_content ) ); ?>
								</div>
							<?php endif; ?>
							<?php if ( ! empty( $link ) && ! empty( $button_text ) ) : ?>
								<a href="<?php echo esc_url( $link ); ?>" class="banner-button"><?php echo esc_html( $button_text ); ?></a>
							<?php endif; ?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>
	</div>
	
	<?php if ( count( $banners ) > 1 ) : ?>
		<div class="banner-controls">
			<button class="banner-prev" aria-label="<?php esc_attr_e( 'Previous slide', 'ontrack' ); ?>">‹</button>
			<button class="banner-next" aria-label="<?php esc_attr_e( 'Next slide', 'ontrack' ); ?>">›</button>
		</div>
		<div class="banner-indicators">
			<?php foreach ( $banners as $index => $banner ) : ?>
				<button class="banner-indicator <?php echo 0 === $index ? 'active' : ''; ?>" data-slide="<?php echo esc_attr( $index ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Go to slide %d', 'ontrack' ), $index + 1 ) ); ?>"></button>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</section>

