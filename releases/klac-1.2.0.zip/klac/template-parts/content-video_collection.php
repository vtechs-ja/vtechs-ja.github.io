<?php
/**
 * Template part for a single Video Collection (post + embed player).
 *
 * @package Ontrack
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<div class="ontrack-video-collection-header">
		<header class="entry-header">
			<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
		</header>
		<?php if ( get_the_content() ) : ?>
			<div class="entry-content">
				<?php the_content(); ?>
			</div>
		<?php endif; ?>
	</div>

	<div id="ontrack-video-player-wrap" class="ontrack-video-player-wrap" data-collection-id="<?php echo esc_attr( (string) get_the_ID() ); ?>">
		<div class="ontrack-video-player-loading" aria-live="polite">
			<span class="ontrack-audio-loading-dot"></span>
			<?php esc_html_e( 'Loading playlist…', 'ontrack' ); ?>
		</div>
		<div class="ontrack-video-player-main" hidden>
			<div class="ontrack-video-embed-wrap">
				<iframe class="ontrack-video-iframe" title="" allow="accelerometer; gyroscope; autoplay; encrypted-media; picture-in-picture;" allowfullscreen loading="lazy"></iframe>
			</div>
			<p class="ontrack-video-now-playing" aria-live="polite"></p>
			<p class="ontrack-playlist-label" aria-hidden="true"><?php esc_html_e( 'Up Next', 'ontrack' ); ?></p>
			<ol class="ontrack-video-playlist" aria-label="<?php esc_attr_e( 'Playlist', 'ontrack' ); ?>"></ol>
		</div>
		<div class="ontrack-video-player-error" hidden aria-live="assertive"></div>
	</div>
</article>
