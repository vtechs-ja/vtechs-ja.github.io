<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package Ontrack
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function ontrack_body_classes( $classes ) {
	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Adds a class of no-sidebar when there is no sidebar present.
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	}

	return $classes;
}
add_filter( 'body_class', 'ontrack_body_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function ontrack_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'ontrack_pingback_header' );

/**
 * Output custom color CSS based on theme customizer settings.
 */
function ontrack_custom_colors_css() {
	// Get WordPress default colors
	$header_text_color = get_theme_mod( 'header_textcolor', '404040' );
	$background_color  = get_theme_mod( 'background_color', 'ffffff' );
	
	// Get custom theme colors
	$primary_color      = get_theme_mod( 'klac_primary_color', '#4169e1' );
	$secondary_color    = get_theme_mod( 'klac_secondary_color', '#800080' );
	$accent_color       = get_theme_mod( 'klac_accent_color', '#ff8c00' );
	$text_color         = get_theme_mod( 'klac_text_color', '#404040' );
	$header_background  = get_theme_mod( 'klac_header_background', '#ffffff' );
	$footer_background  = get_theme_mod( 'klac_footer_background', '#f5f5f5' );

	// Convert header_textcolor to hex format if needed
	if ( 'blank' !== $header_text_color && ! empty( $header_text_color ) ) {
		$header_text_color = '#' . ltrim( $header_text_color, '#' );
	} else {
		$header_text_color = '#' . $text_color;
	}
	
	// Convert background_color to hex format
	$background_color = '#' . ltrim( $background_color, '#' );

	?>
	<style type="text/css" id="ontrack-custom-colors">
		/* Background Color (WordPress default) */
		body {
			background-color: <?php echo esc_attr( $background_color ); ?>;
		}

		/* Header Text Color (WordPress default) */
		<?php if ( 'blank' !== get_theme_mod( 'header_textcolor', '404040' ) ) : ?>
		.site-title a,
		.site-description {
			color: <?php echo esc_attr( $header_text_color ); ?>;
		}
		<?php endif; ?>

		/* Primary Color - Links and Interactive Elements */
		a,
		.entry-content a,
		.main-navigation a:hover,
		.main-navigation a:focus,
		.footer-navigation a:hover,
		.footer-navigation a:focus {
			color: <?php echo esc_attr( $primary_color ); ?>;
		}
		
		a:visited {
			color: <?php echo esc_attr( $primary_color ); ?>;
			opacity: 0.8;
		}

		/* Secondary Color - Active States */
		.main-navigation .current-menu-item > a,
		.main-navigation .current_page_item > a {
			color: <?php echo esc_attr( $secondary_color ); ?>;
		}

		/* Accent Color - Buttons */
		button,
		input[type="button"],
		input[type="submit"],
		.banner-button {
			background-color: <?php echo esc_attr( $accent_color ); ?>;
			border-color: <?php echo esc_attr( $accent_color ); ?>;
			color: #fff;
		}

		button:hover,
		input[type="button"]:hover,
		input[type="submit"]:hover,
		button:focus,
		input[type="button"]:focus,
		input[type="submit"]:focus {
			background-color: <?php echo esc_attr( $accent_color ); ?>;
			border-color: <?php echo esc_attr( $accent_color ); ?>;
			opacity: 0.9;
		}

		/* Text Color */
		body,
		.entry-title,
		.entry-content,
		.main-navigation a,
		.site-info .copyright,
		.footer-navigation a {
			color: <?php echo esc_attr( $text_color ); ?>;
		}

		/* Header Background */
		.site-header {
			background-color: <?php echo esc_attr( $header_background ); ?>;
		}

		/* Footer Background */
		.site-footer {
			background-color: <?php echo esc_attr( $footer_background ); ?>;
		}

		/* Footer Text */
		.site-footer,
		.site-footer .copyright,
		.site-footer a {
			color: <?php echo esc_attr( $text_color ); ?>;
		}

		/* Menu Toggle Color */
		.menu-toggle span {
			background-color: <?php echo esc_attr( $text_color ); ?>;
		}
	</style>
	<?php
}
add_action( 'wp_head', 'ontrack_custom_colors_css' );

/**
 * Output custom typography CSS based on theme customizer settings.
 */
function ontrack_custom_typography_css() {
	// Get font settings
	$site_title_font = get_theme_mod( 'klac_site_title_font', 'system' );
	$site_title_size = get_theme_mod( 'klac_site_title_size', '1.25' );
	$menu_font = get_theme_mod( 'klac_menu_font', 'system' );
	$menu_size = get_theme_mod( 'klac_menu_size', '1' );
	$body_font = get_theme_mod( 'klac_body_font', 'system' );
	$body_size = get_theme_mod( 'klac_body_size', '1' );
	$h1_font = get_theme_mod( 'klac_h1_font', 'system' );
	$h1_size = get_theme_mod( 'klac_h1_size', '2.5' );
	$h2_font = get_theme_mod( 'klac_h2_font', 'system' );
	$h2_size = get_theme_mod( 'klac_h2_size', '2' );
	$h3_font = get_theme_mod( 'klac_h3_font', 'system' );
	$h3_size = get_theme_mod( 'klac_h3_size', '1.5' );
	$h4_font = get_theme_mod( 'klac_h4_font', 'system' );
	$h4_size = get_theme_mod( 'klac_h4_size', '1.25' );
	$h5_font = get_theme_mod( 'klac_h5_font', 'system' );
	$h5_size = get_theme_mod( 'klac_h5_size', '1.1' );
	$h6_font = get_theme_mod( 'klac_h6_font', 'system' );
	$h6_size = get_theme_mod( 'klac_h6_size', '1' );

	// Sanitize font sizes
	$site_title_size = is_numeric( $site_title_size ) ? $site_title_size . 'rem' : $site_title_size;
	$menu_size = is_numeric( $menu_size ) ? $menu_size . 'rem' : $menu_size;
	$body_size = is_numeric( $body_size ) ? $body_size . 'rem' : $body_size;
	$h1_size = is_numeric( $h1_size ) ? $h1_size . 'rem' : $h1_size;
	$h2_size = is_numeric( $h2_size ) ? $h2_size . 'rem' : $h2_size;
	$h3_size = is_numeric( $h3_size ) ? $h3_size . 'rem' : $h3_size;
	$h4_size = is_numeric( $h4_size ) ? $h4_size . 'rem' : $h4_size;
	$h5_size = is_numeric( $h5_size ) ? $h5_size . 'rem' : $h5_size;
	$h6_size = is_numeric( $h6_size ) ? $h6_size . 'rem' : $h6_size;

	?>
	<style type="text/css" id="ontrack-custom-typography">
		/* Site Title */
		.site-title,
		.site-title a {
			font-family: <?php echo esc_attr( ontrack_get_font_family( $site_title_font ) ); ?>;
			font-size: <?php echo esc_attr( $site_title_size ); ?>;
		}

		/* Menu */
		.main-navigation a,
		.footer-navigation a {
			font-family: <?php echo esc_attr( ontrack_get_font_family( $menu_font ) ); ?>;
			font-size: <?php echo esc_attr( $menu_size ); ?>;
		}

		/* Body Text */
		body,
		.entry-content,
		.entry-content p {
			font-family: <?php echo esc_attr( ontrack_get_font_family( $body_font ) ); ?>;
			font-size: <?php echo esc_attr( $body_size ); ?>;
		}

		/* Headings */
		h1,
		.entry-title,
		.entry-content h1 {
			font-family: <?php echo esc_attr( ontrack_get_font_family( $h1_font ) ); ?>;
			font-size: <?php echo esc_attr( $h1_size ); ?>;
		}

		h2,
		.entry-content h2 {
			font-family: <?php echo esc_attr( ontrack_get_font_family( $h2_font ) ); ?>;
			font-size: <?php echo esc_attr( $h2_size ); ?>;
		}

		h3,
		.entry-content h3 {
			font-family: <?php echo esc_attr( ontrack_get_font_family( $h3_font ) ); ?>;
			font-size: <?php echo esc_attr( $h3_size ); ?>;
		}

		h4,
		.entry-content h4 {
			font-family: <?php echo esc_attr( ontrack_get_font_family( $h4_font ) ); ?>;
			font-size: <?php echo esc_attr( $h4_size ); ?>;
		}

		h5,
		.entry-content h5 {
			font-family: <?php echo esc_attr( ontrack_get_font_family( $h5_font ) ); ?>;
			font-size: <?php echo esc_attr( $h5_size ); ?>;
		}

		h6,
		.entry-content h6 {
			font-family: <?php echo esc_attr( ontrack_get_font_family( $h6_font ) ); ?>;
			font-size: <?php echo esc_attr( $h6_size ); ?>;
		}
	</style>
	<?php
}
add_action( 'wp_head', 'ontrack_custom_typography_css' );
