<?php
/**
 * Banner functionality
 *
 * @package Ontrack
 */

/**
 * Register Banner Custom Post Type
 */
function ontrack_register_banner_post_type() {
	$labels = array(
		'name'                  => _x( 'Banners', 'Post Type General Name', 'ontrack' ),
		'singular_name'         => _x( 'Banner', 'Post Type Singular Name', 'ontrack' ),
		'menu_name'             => __( 'Banners', 'ontrack' ),
		'name_admin_bar'        => __( 'Banner', 'ontrack' ),
		'archives'              => __( 'Banner Archives', 'ontrack' ),
		'attributes'            => __( 'Banner Attributes', 'ontrack' ),
		'parent_item_colon'     => __( 'Parent Banner:', 'ontrack' ),
		'all_items'             => __( 'All Banners', 'ontrack' ),
		'add_new_item'          => __( 'Add New Banner', 'ontrack' ),
		'add_new'               => __( 'Add New', 'ontrack' ),
		'new_item'              => __( 'New Banner', 'ontrack' ),
		'edit_item'             => __( 'Edit Banner', 'ontrack' ),
		'update_item'           => __( 'Update Banner', 'ontrack' ),
		'view_item'             => __( 'View Banner', 'ontrack' ),
		'view_items'            => __( 'View Banners', 'ontrack' ),
		'search_items'          => __( 'Search Banner', 'ontrack' ),
		'not_found'             => __( 'Not found', 'ontrack' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'ontrack' ),
		'featured_image'        => __( 'Banner Image', 'ontrack' ),
		'set_featured_image'    => __( 'Set banner image', 'ontrack' ),
		'remove_featured_image' => __( 'Remove banner image', 'ontrack' ),
		'use_featured_image'    => __( 'Use as banner image', 'ontrack' ),
		'insert_into_item'      => __( 'Insert into banner', 'ontrack' ),
		'uploaded_to_this_item' => __( 'Uploaded to this banner', 'ontrack' ),
		'items_list'            => __( 'Banners list', 'ontrack' ),
		'items_list_navigation' => __( 'Banners list navigation', 'ontrack' ),
		'filter_items_list'     => __( 'Filter banners list', 'ontrack' ),
	);

	$args = array(
		'label'                 => __( 'Banner', 'ontrack' ),
		'description'           => __( 'Homepage rotating banners', 'ontrack' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
		'hierarchical'          => false,
		'public'                => false,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 20,
		'menu_icon'             => 'dashicons-images-alt2',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => false,
		'can_export'            => true,
		'has_archive'           => false,
		'exclude_from_search'   => true,
		'publicly_queryable'    => false,
		'capability_type'       => 'post',
		'show_in_rest'          => true,
	);

	register_post_type( 'klac_banner', $args );
}
add_action( 'init', 'ontrack_register_banner_post_type', 0 );

/**
 * Add meta boxes for banner settings
 */
function ontrack_add_banner_meta_boxes() {
	add_meta_box(
		'klac_banner_settings',
		__( 'Banner Settings', 'ontrack' ),
		'ontrack_banner_settings_callback',
		'klac_banner',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'ontrack_add_banner_meta_boxes' );

/**
 * Banner settings meta box callback
 */
function ontrack_banner_settings_callback( $post ) {
	wp_nonce_field( 'klac_banner_settings', 'klac_banner_settings_nonce' );

	$banner_link = get_post_meta( $post->ID, '_klac_banner_link', true );
	$banner_button_text = get_post_meta( $post->ID, '_klac_banner_button_text', true );
	$banner_overlay = get_post_meta( $post->ID, '_klac_banner_overlay', true );
	?>
	<table class="form-table">
		<tr>
			<th><label for="klac_banner_link"><?php esc_html_e( 'Banner Link URL', 'ontrack' ); ?></label></th>
			<td>
				<input type="url" id="klac_banner_link" name="klac_banner_link" value="<?php echo esc_attr( $banner_link ); ?>" class="regular-text" />
				<p class="description"><?php esc_html_e( 'Optional: URL to link the banner to (leave blank for no link)', 'ontrack' ); ?></p>
			</td>
		</tr>
		<tr>
			<th><label for="klac_banner_button_text"><?php esc_html_e( 'Button Text', 'ontrack' ); ?></label></th>
			<td>
				<input type="text" id="klac_banner_button_text" name="klac_banner_button_text" value="<?php echo esc_attr( $banner_button_text ); ?>" class="regular-text" />
				<p class="description"><?php esc_html_e( 'Optional: Text for the call-to-action button (e.g., "Learn More", "Get Started")', 'ontrack' ); ?></p>
			</td>
		</tr>
		<tr>
			<th><label for="klac_banner_overlay"><?php esc_html_e( 'Dark Overlay', 'ontrack' ); ?></label></th>
			<td>
				<input type="checkbox" id="klac_banner_overlay" name="klac_banner_overlay" value="1" <?php checked( $banner_overlay, '1' ); ?> />
				<label for="klac_banner_overlay"><?php esc_html_e( 'Add dark overlay for better text readability', 'ontrack' ); ?></label>
			</td>
		</tr>
	</table>
	<?php
}

/**
 * Save banner meta data
 */
function ontrack_save_banner_meta( $post_id ) {
	// Check nonce
	if ( ! isset( $_POST['klac_banner_settings_nonce'] ) || ! wp_verify_nonce( $_POST['klac_banner_settings_nonce'], 'klac_banner_settings' ) ) {
		return;
	}

	// Check autosave
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	// Check permissions
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	// Save meta fields
	if ( isset( $_POST['klac_banner_link'] ) ) {
		update_post_meta( $post_id, '_klac_banner_link', esc_url_raw( $_POST['klac_banner_link'] ) );
	}

	if ( isset( $_POST['klac_banner_button_text'] ) ) {
		update_post_meta( $post_id, '_klac_banner_button_text', sanitize_text_field( $_POST['klac_banner_button_text'] ) );
	}

	$overlay = isset( $_POST['klac_banner_overlay'] ) ? '1' : '0';
	update_post_meta( $post_id, '_klac_banner_overlay', $overlay );
}
add_action( 'save_post_klac_banner', 'ontrack_save_banner_meta' );

/**
 * Get active banners
 */
function ontrack_get_banners() {
	$args = array(
		'post_type'      => 'klac_banner',
		'posts_per_page' => -1,
		'post_status'    => 'publish',
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
		'meta_query'     => array(
			array(
				'key'     => '_thumbnail_id',
				'compare' => 'EXISTS',
			),
		),
	);

	return get_posts( $args );
}



