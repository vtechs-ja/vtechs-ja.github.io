<?php
/**
 * Page Layout functionality
 *
 * @package Ontrack
 */

/**
 * Add meta box for page layout options
 */
function ontrack_add_page_layout_meta_box() {
	add_meta_box(
		'ontrack_page_layout',
		__( 'Page Layout', 'ontrack' ),
		'ontrack_page_layout_callback',
		array( 'page', 'post' ),
		'side',
		'default'
	);
}
add_action( 'add_meta_boxes', 'ontrack_add_page_layout_meta_box' );

/**
 * Page layout meta box callback
 */
function ontrack_page_layout_callback( $post ) {
	wp_nonce_field( 'ontrack_page_layout', 'ontrack_page_layout_nonce' );

	$full_page_layout = get_post_meta( $post->ID, '_klac_full_page_layout', true );
	?>
	<p>
		<label>
			<input type="checkbox" name="ontrack_full_page_layout" value="1" <?php checked( $full_page_layout, '1' ); ?> />
			<?php esc_html_e( 'Full Page Layout', 'ontrack' ); ?>
		</label>
	</p>
	<p class="description">
		<?php esc_html_e( 'Enable this to hide the header and footer, showing only the page content in a full-page layout.', 'ontrack' ); ?>
	</p>
	<?php
}

/**
 * Save page layout meta data
 */
function ontrack_save_page_layout_meta( $post_id ) {
	// Check nonce
	if ( ! isset( $_POST['ontrack_page_layout_nonce'] ) || ! wp_verify_nonce( $_POST['ontrack_page_layout_nonce'], 'ontrack_page_layout' ) ) {
		return;
	}

	// Check autosave
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	// Check permissions
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	// Save meta field
	$full_page_layout = isset( $_POST['ontrack_full_page_layout'] ) ? '1' : '0';
	update_post_meta( $post_id, '_klac_full_page_layout', $full_page_layout );
}
add_action( 'save_post', 'ontrack_save_page_layout_meta' );

/**
 * Add body class for full page layout
 */
function ontrack_add_full_page_layout_class( $classes ) {
	if ( is_singular() ) {
		$post_id = get_queried_object_id();
		$full_page_layout = get_post_meta( $post_id, '_klac_full_page_layout', true );
		
		if ( '1' === $full_page_layout ) {
			$classes[] = 'ontrack-full-page-layout';
		}
	}
	
	return $classes;
}
add_filter( 'body_class', 'ontrack_add_full_page_layout_class' );



