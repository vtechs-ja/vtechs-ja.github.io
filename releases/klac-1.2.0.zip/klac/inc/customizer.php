<?php
/**
 * Ontrack Theme Customizer
 *
 * @package Ontrack
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function ontrack_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
	$wp_customize->get_setting( 'background_color' )->transport = 'postMessage';

	// Get or create the Colors section
	$colors_section = $wp_customize->get_section( 'colors' );
	if ( ! $colors_section ) {
		$wp_customize->add_section(
			'colors',
			array(
				'title'    => __( 'Colors', 'ontrack' ),
				'priority' => 30,
			)
		);
	}

	// Primary Color (Main brand color, used for links and accents)
	$wp_customize->add_setting(
		'klac_primary_color',
		array(
			'default'           => '#4169e1',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'klac_primary_color',
			array(
				'label'    => __( 'Primary Color', 'ontrack' ),
				'description' => __( 'Used for links, buttons, and primary accents', 'ontrack' ),
				'section'  => 'colors',
			)
		)
	);

	// Secondary Color (Secondary brand color)
	$wp_customize->add_setting(
		'klac_secondary_color',
		array(
			'default'           => '#800080',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'klac_secondary_color',
			array(
				'label'    => __( 'Secondary Color', 'ontrack' ),
				'description' => __( 'Used for active menu items and secondary accents', 'ontrack' ),
				'section'  => 'colors',
			)
		)
	);

	// Accent Color (Highlight color)
	$wp_customize->add_setting(
		'klac_accent_color',
		array(
			'default'           => '#ff8c00',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'klac_accent_color',
			array(
				'label'    => __( 'Accent Color', 'ontrack' ),
				'description' => __( 'Used for highlights and call-to-action elements', 'ontrack' ),
				'section'  => 'colors',
			)
		)
	);

	// Note: Background Color is handled by WordPress default "Background Color" setting above

	// Text Color
	$wp_customize->add_setting(
		'klac_text_color',
		array(
			'default'           => '#404040',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'klac_text_color',
			array(
				'label'    => __( 'Text Color', 'ontrack' ),
				'description' => __( 'Main text color for content, footer, and navigation', 'ontrack' ),
				'section'  => 'colors',
			)
		)
	);
	
	// Note: Header Text Color is handled by WordPress default "Header Text Color" setting above

	// Header Background Color
	$wp_customize->add_setting(
		'klac_header_background',
		array(
			'default'           => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'klac_header_background',
			array(
				'label'    => __( 'Header Background', 'ontrack' ),
				'description' => __( 'Background color for the header area. Header text color is controlled by "Header Text Color" above.', 'ontrack' ),
				'section'  => 'colors',
			)
		)
	);

	// Footer Background Color
	$wp_customize->add_setting(
		'klac_footer_background',
		array(
			'default'           => '#f5f5f5',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'klac_footer_background',
			array(
				'label'    => __( 'Footer Background', 'ontrack' ),
				'description' => __( 'Background color for the footer area', 'ontrack' ),
				'section'  => 'colors',
			)
		)
	);

	// Add Typography Section
	$wp_customize->add_section(
		'klac_typography',
		array(
			'title'    => __( 'Typography', 'ontrack' ),
			'priority' => 35,
		)
	);

	// Get available fonts
	$ontrack_fonts = ontrack_get_font_choices();

	// Site Title Font Family
	$wp_customize->add_setting(
		'klac_site_title_font',
		array(
			'default'           => 'system',
			'sanitize_callback' => 'ontrack_sanitize_font_choice',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_site_title_font',
		array(
			'label'    => __( 'Site Title Font', 'ontrack' ),
			'section'  => 'klac_typography',
			'type'     => 'select',
			'choices'  => $ontrack_fonts,
		)
	);

	// Site Title Font Size
	$wp_customize->add_setting(
		'klac_site_title_size',
		array(
			'default'           => '1.25',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_site_title_size',
		array(
			'label'       => __( 'Site Title Font Size (rem)', 'ontrack' ),
			'section'     => 'klac_typography',
			'type'        => 'text',
			'description' => __( 'Enter size in rem units (e.g., 1.25, 1.5, 2)', 'ontrack' ),
		)
	);

	// Menu Font Family
	$wp_customize->add_setting(
		'klac_menu_font',
		array(
			'default'           => 'system',
			'sanitize_callback' => 'ontrack_sanitize_font_choice',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_menu_font',
		array(
			'label'    => __( 'Menu Font', 'ontrack' ),
			'section'  => 'klac_typography',
			'type'     => 'select',
			'choices'  => $ontrack_fonts,
		)
	);

	// Menu Font Size
	$wp_customize->add_setting(
		'klac_menu_size',
		array(
			'default'           => '1',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_menu_size',
		array(
			'label'       => __( 'Menu Font Size (rem)', 'ontrack' ),
			'section'     => 'klac_typography',
			'type'        => 'text',
			'description' => __( 'Enter size in rem units (e.g., 1, 1.1, 1.2)', 'ontrack' ),
		)
	);

	// Body/Paragraph Font Family
	$wp_customize->add_setting(
		'klac_body_font',
		array(
			'default'           => 'system',
			'sanitize_callback' => 'ontrack_sanitize_font_choice',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_body_font',
		array(
			'label'    => __( 'Body Text Font', 'ontrack' ),
			'section'  => 'klac_typography',
			'type'     => 'select',
			'choices'  => $ontrack_fonts,
		)
	);

	// Body Font Size
	$wp_customize->add_setting(
		'klac_body_size',
		array(
			'default'           => '1',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_body_size',
		array(
			'label'       => __( 'Body Text Font Size (rem)', 'ontrack' ),
			'section'     => 'klac_typography',
			'type'        => 'text',
			'description' => __( 'Enter size in rem units (e.g., 1, 1.1, 1.2)', 'ontrack' ),
		)
	);

	// H1 Font Family
	$wp_customize->add_setting(
		'klac_h1_font',
		array(
			'default'           => 'system',
			'sanitize_callback' => 'ontrack_sanitize_font_choice',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_h1_font',
		array(
			'label'    => __( 'Heading 1 (H1) Font', 'ontrack' ),
			'section'  => 'klac_typography',
			'type'     => 'select',
			'choices'  => $ontrack_fonts,
		)
	);

	// H1 Font Size
	$wp_customize->add_setting(
		'klac_h1_size',
		array(
			'default'           => '2.5',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_h1_size',
		array(
			'label'       => __( 'H1 Font Size (rem)', 'ontrack' ),
			'section'     => 'klac_typography',
			'type'        => 'text',
			'description' => __( 'Enter size in rem units (e.g., 2.5, 3, 3.5)', 'ontrack' ),
		)
	);

	// H2 Font Family
	$wp_customize->add_setting(
		'klac_h2_font',
		array(
			'default'           => 'system',
			'sanitize_callback' => 'ontrack_sanitize_font_choice',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_h2_font',
		array(
			'label'    => __( 'Heading 2 (H2) Font', 'ontrack' ),
			'section'  => 'klac_typography',
			'type'     => 'select',
			'choices'  => $ontrack_fonts,
		)
	);

	// H2 Font Size
	$wp_customize->add_setting(
		'klac_h2_size',
		array(
			'default'           => '2',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_h2_size',
		array(
			'label'       => __( 'H2 Font Size (rem)', 'ontrack' ),
			'section'     => 'klac_typography',
			'type'        => 'text',
			'description' => __( 'Enter size in rem units (e.g., 2, 2.25, 2.5)', 'ontrack' ),
		)
	);

	// H3 Font Family
	$wp_customize->add_setting(
		'klac_h3_font',
		array(
			'default'           => 'system',
			'sanitize_callback' => 'ontrack_sanitize_font_choice',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_h3_font',
		array(
			'label'    => __( 'Heading 3 (H3) Font', 'ontrack' ),
			'section'  => 'klac_typography',
			'type'     => 'select',
			'choices'  => $ontrack_fonts,
		)
	);

	// H3 Font Size
	$wp_customize->add_setting(
		'klac_h3_size',
		array(
			'default'           => '1.5',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_h3_size',
		array(
			'label'       => __( 'H3 Font Size (rem)', 'ontrack' ),
			'section'     => 'klac_typography',
			'type'        => 'text',
			'description' => __( 'Enter size in rem units (e.g., 1.5, 1.75, 2)', 'ontrack' ),
		)
	);

	// H4 Font Family
	$wp_customize->add_setting(
		'klac_h4_font',
		array(
			'default'           => 'system',
			'sanitize_callback' => 'ontrack_sanitize_font_choice',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_h4_font',
		array(
			'label'    => __( 'Heading 4 (H4) Font', 'ontrack' ),
			'section'  => 'klac_typography',
			'type'     => 'select',
			'choices'  => $ontrack_fonts,
		)
	);

	// H4 Font Size
	$wp_customize->add_setting(
		'klac_h4_size',
		array(
			'default'           => '1.25',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_h4_size',
		array(
			'label'       => __( 'H4 Font Size (rem)', 'ontrack' ),
			'section'     => 'klac_typography',
			'type'        => 'text',
			'description' => __( 'Enter size in rem units (e.g., 1.25, 1.5)', 'ontrack' ),
		)
	);

	// H5 Font Family
	$wp_customize->add_setting(
		'klac_h5_font',
		array(
			'default'           => 'system',
			'sanitize_callback' => 'ontrack_sanitize_font_choice',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_h5_font',
		array(
			'label'    => __( 'Heading 5 (H5) Font', 'ontrack' ),
			'section'  => 'klac_typography',
			'type'     => 'select',
			'choices'  => $ontrack_fonts,
		)
	);

	// H5 Font Size
	$wp_customize->add_setting(
		'klac_h5_size',
		array(
			'default'           => '1.1',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_h5_size',
		array(
			'label'       => __( 'H5 Font Size (rem)', 'ontrack' ),
			'section'     => 'klac_typography',
			'type'        => 'text',
			'description' => __( 'Enter size in rem units (e.g., 1.1, 1.2)', 'ontrack' ),
		)
	);

	// H6 Font Family
	$wp_customize->add_setting(
		'klac_h6_font',
		array(
			'default'           => 'system',
			'sanitize_callback' => 'ontrack_sanitize_font_choice',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_h6_font',
		array(
			'label'    => __( 'Heading 6 (H6) Font', 'ontrack' ),
			'section'  => 'klac_typography',
			'type'     => 'select',
			'choices'  => $ontrack_fonts,
		)
	);

	// H6 Font Size
	$wp_customize->add_setting(
		'klac_h6_size',
		array(
			'default'           => '1',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_h6_size',
		array(
			'label'       => __( 'H6 Font Size (rem)', 'ontrack' ),
			'section'     => 'klac_typography',
			'type'        => 'text',
			'description' => __( 'Enter size in rem units (e.g., 1, 1.1)', 'ontrack' ),
		)
	);

	// Add Banner Section
	$wp_customize->add_section(
		'klac_banners',
		array(
			'title'    => __( 'Homepage Banner', 'ontrack' ),
			'priority' => 25,
		)
	);

	// Enable Banner
	$wp_customize->add_setting(
		'klac_banner_enable',
		array(
			'default'           => true,
			'sanitize_callback' => 'wp_validate_boolean',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'klac_banner_enable',
		array(
			'label'       => __( 'Enable Homepage Banner', 'ontrack' ),
			'description' => __( 'Display rotating banner slider on homepage', 'ontrack' ),
			'section'     => 'klac_banners',
			'type'        => 'checkbox',
		)
	);

	// Banner Height
	$wp_customize->add_setting(
		'klac_banner_height',
		array(
			'default'           => '500',
			'sanitize_callback' => 'absint',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'klac_banner_height',
		array(
			'label'       => __( 'Banner Height (px)', 'ontrack' ),
			'description' => __( 'Height of the banner slider in pixels', 'ontrack' ),
			'section'     => 'klac_banners',
			'type'        => 'number',
			'input_attrs' => array(
				'min'  => 300,
				'max'  => 800,
				'step' => 50,
			),
		)
	);

	// Auto-play
	$wp_customize->add_setting(
		'klac_banner_autoplay',
		array(
			'default'           => true,
			'sanitize_callback' => 'wp_validate_boolean',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'klac_banner_autoplay',
		array(
			'label'       => __( 'Auto-play Slideshow', 'ontrack' ),
			'description' => __( 'Automatically rotate through banners', 'ontrack' ),
			'section'     => 'klac_banners',
			'type'        => 'checkbox',
		)
	);

	// Slide Duration
	$wp_customize->add_setting(
		'klac_banner_duration',
		array(
			'default'           => '5000',
			'sanitize_callback' => 'absint',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'klac_banner_duration',
		array(
			'label'       => __( 'Slide Duration (ms)', 'ontrack' ),
			'description' => __( 'Time each slide is displayed in milliseconds (e.g., 5000 = 5 seconds)', 'ontrack' ),
			'section'     => 'klac_banners',
			'type'        => 'number',
			'input_attrs' => array(
				'min'  => 2000,
				'max'  => 10000,
				'step' => 500,
			),
		)
	);

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial(
			'blogname',
			array(
				'selector'        => '.site-title a',
				'render_callback' => 'ontrack_customize_partial_blogname',
			)
		);
		$wp_customize->selective_refresh->add_partial(
			'blogdescription',
			array(
				'selector'        => '.site-description',
				'render_callback' => 'ontrack_customize_partial_blogdescription',
			)
		);
	}
}
add_action( 'customize_register', 'ontrack_customize_register' );

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function ontrack_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function ontrack_customize_partial_blogdescription() {
	bloginfo( 'description' );
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function ontrack_customize_preview_js() {
	wp_enqueue_script( 'ontrack-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), _S_VERSION, true );
}
add_action( 'customize_preview_init', 'ontrack_customize_preview_js' );

/**
 * Get font choices for the customizer.
 *
 * @return array Font choices.
 */
function ontrack_get_font_choices() {
	return array(
		'system' => __( 'System Default', 'ontrack' ),
		'Arial' => 'Arial',
		'Helvetica' => 'Helvetica',
		'Georgia' => 'Georgia',
		'Times New Roman' => 'Times New Roman',
		'Courier New' => 'Courier New',
		'Verdana' => 'Verdana',
		'Roboto' => 'Roboto',
		'Open Sans' => 'Open Sans',
		'Lato' => 'Lato',
		'Montserrat' => 'Montserrat',
		'Poppins' => 'Poppins',
		'Playfair Display' => 'Playfair Display',
		'Merriweather' => 'Merriweather',
		'Source Sans Pro' => 'Source Sans Pro',
		'Raleway' => 'Raleway',
		'Oswald' => 'Oswald',
		'Lora' => 'Lora',
		'PT Sans' => 'PT Sans',
		'Ubuntu' => 'Ubuntu',
	);
}

/**
 * Sanitize font choice.
 *
 * @param string $value Font choice value.
 * @return string Sanitized font choice.
 */
function ontrack_sanitize_font_choice( $value ) {
	$fonts = ontrack_get_font_choices();
	if ( array_key_exists( $value, $fonts ) ) {
		return $value;
	}
	return 'system';
}

/**
 * Get font family CSS value.
 *
 * @param string $font Font name.
 * @return string Font family CSS value.
 */
function ontrack_get_font_family( $font ) {
	if ( 'system' === $font ) {
		return '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif';
	}
	
	// Google Fonts that need to be loaded
	$google_fonts = array(
		'Roboto',
		'Open Sans',
		'Lato',
		'Montserrat',
		'Poppins',
		'Playfair Display',
		'Merriweather',
		'Source Sans Pro',
		'Raleway',
		'Oswald',
		'Lora',
		'PT Sans',
		'Ubuntu',
	);
	
	if ( in_array( $font, $google_fonts, true ) ) {
		return '"' . $font . '", sans-serif';
	}
	
	return $font . ', sans-serif';
}
