<?php
/**
 * Template Name: Members Area
 *
 * Welcome page for logged-in members. Shows personalised greeting, optional
 * looping animation video, optional Sunday-9am countdown, and cards linking
 * to all published audio and video collections.
 *
 * @package Ontrack
 */

// Redirect anonymous visitors.
if ( ! is_user_logged_in() ) {
	auth_redirect();
}

// Redirect non-members to homepage.
$current_user = wp_get_current_user();
$is_member    = function_exists( 'ontrack_user_is_full_member' )
	? ontrack_user_is_full_member( $current_user->ID )
	: (bool) array_intersect(
		array( 'klac_member', 'klac_leader', 'klac_community_leader', 'klac_admin' ),
		(array) $current_user->roles
	);

get_header();

if ( ! $is_member ) {
	?>
	<main id="primary" class="site-main">
		<div class="ontrack-members-area">
			<?php get_template_part( 'template-parts/members-subnav' ); ?>
			<div class="ontrack-access-denied">
				<h1 class="ontrack-access-denied__heading"><?php esc_html_e( 'Members Only', 'ontrack' ); ?></h1>
				<p><?php esc_html_e( 'Your account does not currently have member access.', 'ontrack' ); ?></p>
				<p>
					<?php
					printf(
						/* translators: %s: admin email address */
						esc_html__( 'If you believe you should have access, please contact %s.', 'ontrack' ),
						'<a href="mailto:' . esc_attr( get_option( 'admin_email' ) ) . '">'
						. esc_html( get_option( 'admin_email' ) ) . '</a>'
					);
					?>
				</p>
				<a href="<?php echo esc_url( wp_logout_url( get_permalink() ) ); ?>" class="button">
					<?php esc_html_e( 'Log out', 'ontrack' ); ?>
				</a>
			</div>
		</div>
	</main>
	<?php
	get_footer();
	exit;
}

$post_id        = get_the_ID();
$show_animation = (bool) get_post_meta( $post_id, '_ontrack_members_show_animation', true );
$animation_id   = (int) get_post_meta( $post_id, '_ontrack_members_animation_id', true );
$animation_url  = $animation_id ? wp_get_attachment_url( $animation_id ) : '';
$show_countdown = (bool) get_post_meta( $post_id, '_ontrack_members_show_countdown', true );

$audio_query_args = array(
	'post_type'      => 'audio_collection',
	'posts_per_page' => -1,
	'post_status'    => 'publish',
	'orderby'        => 'title',
	'order'          => 'ASC',
	'no_found_rows'  => true,
);

$video_query_args = array(
	'post_type'      => 'video_collection',
	'posts_per_page' => -1,
	'post_status'    => 'publish',
	'orderby'        => 'title',
	'order'          => 'ASC',
	'no_found_rows'  => true,
);

if ( function_exists( 'ontrack_is_catalogue_enforcement_enabled' ) && ontrack_is_catalogue_enforcement_enabled() ) {
	$_uid            = get_current_user_id();
	$_is_full_member = function_exists( 'ontrack_user_is_full_member' ) && ontrack_user_is_full_member( $_uid );

	if ( ! $_is_full_member ) {
		$_mq = function_exists( 'ontrack_get_catalogue_archive_meta_query' )
			? ontrack_get_catalogue_archive_meta_query( $_uid )
			: null;
		if ( $_mq ) {
			$audio_query_args['meta_query'] = $_mq;
			$video_query_args['meta_query'] = $_mq;
		}
	} else {
		if ( function_exists( 'ontrack_get_group_excluded_ids_for_user' ) ) {
			$_excl_audio = ontrack_get_group_excluded_ids_for_user( $_uid, 'audio_collection' );
			$_excl_video = ontrack_get_group_excluded_ids_for_user( $_uid, 'video_collection' );
			if ( ! empty( $_excl_audio ) ) {
				$audio_query_args['post__not_in'] = $_excl_audio;
			}
			if ( ! empty( $_excl_video ) ) {
				$video_query_args['post__not_in'] = $_excl_video;
			}
		}
	}
}

$audio_query = new WP_Query( $audio_query_args );
$video_query = new WP_Query( $video_query_args );
?>

	<main id="primary" class="site-main">

		<div class="ontrack-members-area">

			<?php get_template_part( 'template-parts/members-subnav' ); ?>

			<?php if ( $show_animation && $animation_url ) : ?>
			<div class="ontrack-members-animation" aria-hidden="true">
				<video class="ontrack-members-animation__video" autoplay muted loop playsinline>
					<source src="<?php echo esc_url( $animation_url ); ?>" type="video/mp4" />
				</video>
			</div>
			<?php endif; ?>

			<div class="ontrack-members-welcome">

				<h1 class="ontrack-members-welcome__heading">
					<?php
					$first_name = $current_user->first_name ?: $current_user->display_name;
					/* translators: %s: member first name */
					echo esc_html( sprintf( __( 'Welcome, %s', 'ontrack' ), $first_name ) );
					?>
				</h1>

				<?php if ( $show_countdown ) : ?>
				<div class="ontrack-countdown" id="ontrack-countdown" aria-live="polite">
					<p class="ontrack-countdown__label"><?php esc_html_e( 'Next Sunday Download', 'ontrack' ); ?></p>
					<div class="ontrack-countdown__grid" id="ontrack-countdown-grid">
						<div class="ontrack-countdown__unit">
							<span class="ontrack-countdown__value" id="ontrack-countdown-days">--</span>
							<span class="ontrack-countdown__unit-label"><?php esc_html_e( 'Days', 'ontrack' ); ?></span>
						</div>
						<div class="ontrack-countdown__unit">
							<span class="ontrack-countdown__value" id="ontrack-countdown-hours">--</span>
							<span class="ontrack-countdown__unit-label"><?php esc_html_e( 'Hours', 'ontrack' ); ?></span>
						</div>
						<div class="ontrack-countdown__unit">
							<span class="ontrack-countdown__value" id="ontrack-countdown-minutes">--</span>
							<span class="ontrack-countdown__unit-label"><?php esc_html_e( 'Minutes', 'ontrack' ); ?></span>
						</div>
						<div class="ontrack-countdown__unit">
							<span class="ontrack-countdown__value" id="ontrack-countdown-seconds">--</span>
							<span class="ontrack-countdown__unit-label"><?php esc_html_e( 'Seconds', 'ontrack' ); ?></span>
						</div>
					</div>
					<p class="ontrack-countdown__inprogress" id="ontrack-countdown-inprogress" hidden>
						<?php esc_html_e( 'Sunday Download in Progress\u2026', 'ontrack' ); ?>
					</p>
				</div>
				<?php endif; ?>

				<?php if ( get_the_content() ) : ?>
				<div class="ontrack-members-welcome__content entry-content">
					<?php the_content(); ?>
				</div>
				<?php endif; ?>

			</div><!-- .ontrack-members-welcome -->

			<div class="ontrack-members-collections">

				<?php if ( $audio_query->have_posts() ) : ?>
				<section class="ontrack-members-section">
					<h2 class="ontrack-members-section__title"><?php esc_html_e( 'Audio Collections', 'ontrack' ); ?></h2>
					<div class="ontrack-collection-grid">
						<?php while ( $audio_query->have_posts() ) : $audio_query->the_post(); ?>
							<article <?php post_class( 'ontrack-collection-card' ); ?>>
								<?php if ( has_post_thumbnail() ) : ?>
									<a class="ontrack-collection-card__thumbnail" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
										<?php the_post_thumbnail( 'medium' ); ?>
									</a>
								<?php endif; ?>
								<div class="ontrack-collection-card__body">
									<h3 class="ontrack-collection-card__title">
										<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
									</h3>
									<?php if ( has_excerpt() ) : ?>
										<div class="ontrack-collection-card__summary"><?php the_excerpt(); ?></div>
									<?php endif; ?>
									<a class="ontrack-collection-card__cta button" href="<?php the_permalink(); ?>">
										<?php esc_html_e( 'Listen', 'ontrack' ); ?>
									</a>
								</div>
							</article>
						<?php endwhile; wp_reset_postdata(); ?>
					</div>
					<p class="ontrack-members-section__archive-link">
						<a href="<?php echo esc_url( get_post_type_archive_link( 'audio_collection' ) ); ?>">
							<?php esc_html_e( 'Browse all audio collections &rarr;', 'ontrack' ); ?>
						</a>
					</p>
				</section>
				<?php endif; ?>

				<?php if ( $video_query->have_posts() ) : ?>
				<section class="ontrack-members-section">
					<h2 class="ontrack-members-section__title"><?php esc_html_e( 'Video Collections', 'ontrack' ); ?></h2>
					<div class="ontrack-collection-grid">
						<?php while ( $video_query->have_posts() ) : $video_query->the_post(); ?>
							<article <?php post_class( 'ontrack-collection-card' ); ?>>
								<?php if ( has_post_thumbnail() ) : ?>
									<a class="ontrack-collection-card__thumbnail" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
										<?php the_post_thumbnail( 'medium' ); ?>
									</a>
								<?php endif; ?>
								<div class="ontrack-collection-card__body">
									<h3 class="ontrack-collection-card__title">
										<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
									</h3>
									<?php if ( has_excerpt() ) : ?>
										<div class="ontrack-collection-card__summary"><?php the_excerpt(); ?></div>
									<?php endif; ?>
									<a class="ontrack-collection-card__cta button" href="<?php the_permalink(); ?>">
										<?php esc_html_e( 'Watch', 'ontrack' ); ?>
									</a>
								</div>
							</article>
						<?php endwhile; wp_reset_postdata(); ?>
					</div>
					<p class="ontrack-members-section__archive-link">
						<a href="<?php echo esc_url( get_post_type_archive_link( 'video_collection' ) ); ?>">
							<?php esc_html_e( 'Browse all video collections &rarr;', 'ontrack' ); ?>
						</a>
					</p>
				</section>
				<?php endif; ?>

			</div><!-- .ontrack-members-collections -->

		</div><!-- .ontrack-members-area -->

	</main><!-- #primary -->

<?php
get_sidebar();
get_footer();
