<?php
/**
 * Ontrack functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Ontrack
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function ontrack_setup() {
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on Ontrack, use a find and replace
		* to change 'ontrack' to the name of your theme in all the template files.
		*/
	load_theme_textdomain( 'ontrack', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support( 'title-tag' );

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus(
		array(
			'menu-1'           => esc_html__( 'Primary', 'ontrack' ),
			'footer-menu'      => esc_html__( 'Footer Menu', 'ontrack' ),
			'ontrack-members-nav' => esc_html__( 'Members Area Navigation', 'ontrack' ),
		)
	);

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'ontrack_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action( 'after_setup_theme', 'ontrack_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function ontrack_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'ontrack_content_width', 640 );
}
add_action( 'after_setup_theme', 'ontrack_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function ontrack_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'ontrack' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'ontrack' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'ontrack_widgets_init' );

/**
 * Enqueue Google Fonts based on customizer settings.
 */
function ontrack_enqueue_google_fonts() {
	$fonts_to_load = array();
	
	// Get all font settings
	$font_settings = array(
		'klac_site_title_font',
		'klac_menu_font',
		'klac_body_font',
		'klac_h1_font',
		'klac_h2_font',
		'klac_h3_font',
		'klac_h4_font',
		'klac_h5_font',
		'klac_h6_font',
	);
	
	$google_fonts = array(
		'Roboto',
		'Open Sans',
		'Lato',
		'Montserrat',
		'Poppins',
		'Playfair Display',
		'Merriweather',
		'Source Sans Pro',
		'Raleway',
		'Oswald',
		'Lora',
		'PT Sans',
		'Ubuntu',
	);
	
	foreach ( $font_settings as $setting ) {
		$font = get_theme_mod( $setting, 'system' );
		if ( 'system' !== $font && in_array( $font, $google_fonts, true ) ) {
			$fonts_to_load[] = $font;
		}
	}
	
	// Remove duplicates
	$fonts_to_load = array_unique( $fonts_to_load );
	
	if ( ! empty( $fonts_to_load ) ) {
		$font_families = array();
		foreach ( $fonts_to_load as $font ) {
			$font_families[] = str_replace( ' ', '+', $font ) . ':400,600,700';
		}
		$fonts_url = add_query_arg(
			array(
				'family' => implode( '|', $font_families ),
				'subset' => 'latin',
			),
			'https://fonts.googleapis.com/css'
		);
		wp_enqueue_style( 'ontrack-google-fonts', $fonts_url, array(), null );
	}
}
add_action( 'wp_enqueue_scripts', 'ontrack_enqueue_google_fonts' );

/**
 * Enqueue scripts and styles.
 */
function ontrack_scripts() {
	wp_enqueue_style( 'ontrack-style', get_stylesheet_uri(), array(), _S_VERSION );
	wp_style_add_data( 'ontrack-style', 'rtl', 'replace' );

	wp_enqueue_script( 'ontrack-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true );

	// Enqueue banner slider script on homepage
	if ( is_front_page() && get_theme_mod( 'klac_banner_enable', true ) ) {
		wp_enqueue_script( 'ontrack-banner-slider', get_template_directory_uri() . '/js/banner-slider.js', array(), _S_VERSION, true );
	}

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	// Audio/video player and members area scripts are enqueued by the Ontrack plugin.
}
add_action( 'wp_enqueue_scripts', 'ontrack_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Banner functionality.
 */
require get_template_directory() . '/inc/banners.php';

/**
 * Page layout functionality.
 */
require get_template_directory() . '/inc/page-layout.php';