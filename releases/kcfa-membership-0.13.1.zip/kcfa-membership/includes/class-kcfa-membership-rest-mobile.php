<?php
/**
 * Mobile-specific REST endpoints.
 *
 * Namespace: klac/v1
 * Routes:
 *   GET /navigation          — klac-members-nav menu as tab config
 *   GET /tab/{page_id}       — composite tab content (page + sub-pages + collections + posts)
 *   GET /collections         — access-filtered collection list by type
 *
 * @package Ontrack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and handles mobile content REST routes.
 */
class Ontrack_REST_Mobile {

	const ROUTE_NAMESPACE = 'klac/v1';

	/**
	 * Register all routes on rest_api_init.
	 */
	public function register_routes() {
		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/navigation',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'handle_navigation' ),
				'permission_callback' => array( $this, 'require_authenticated' ),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/tab/(?P<page_id>\d+)',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'handle_tab' ),
				'permission_callback' => array( $this, 'require_authenticated' ),
				'args'                => array(
					'page_id' => array(
						'required'          => true,
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/collections',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'handle_collections' ),
				'permission_callback' => array( $this, 'require_authenticated' ),
				'args'                => array(
					'type' => array(
						'required'          => true,
						'type'              => 'string',
						'enum'              => array( 'audio', 'video' ),
						'sanitize_callback' => 'sanitize_key',
					),
				),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/events',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'handle_events' ),
				'permission_callback' => array( $this, 'require_member' ),
				'args'                => array(
					'limit' => array(
						'type'              => 'integer',
						'default'           => 10,
						'minimum'           => 1,
						'maximum'           => 50,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/events/(?P<id>\d+)',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'handle_event' ),
				'permission_callback' => array( $this, 'require_member' ),
				'args'                => array(
					'id' => array(
						'required'          => true,
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
					),
				),
			)
		);
	}

	// -------------------------------------------------------------------------
	// Handlers
	// -------------------------------------------------------------------------

	/**
	 * GET /navigation — return klac-members-nav items grouped by CSS class.
	 *
	 * Items tagged `people-group` → community section cards on the home screen.
	 * Items tagged `resources`    → resources tab list + quick access CTAs.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function handle_navigation( WP_REST_Request $request ) {
		$menu_items = wp_get_nav_menu_items( 'klac-members-nav' );
		if ( ! $menu_items ) {
			return new WP_REST_Response( array( 'community' => array(), 'resources' => array() ), 200 );
		}

		$community = array();
		$resources = array();
		$uid       = get_current_user_id();

		foreach ( $menu_items as $item ) {
			if ( '0' !== (string) $item->menu_item_parent ) {
				continue;
			}

			$classes = (array) $item->classes;
			$is_community = in_array( 'people-group', $classes, true );
			$is_resource  = in_array( 'resources', $classes, true );

			if ( ! $is_community && ! $is_resource ) {
				continue;
			}

			$page_id = (int) $item->object_id;
			if ( ! $page_id ) {
				continue;
			}

			// Group visibility: skip if the current user is not in any allowed group.
			$allowed_group_ids = array_map( 'intval', array_filter( (array) get_post_meta( $page_id, '_ontrack_tab_allowed_group_ids', true ) ) );
			if ( ! empty( $allowed_group_ids ) ) {
				$has_access = false;
				foreach ( $allowed_group_ids as $gid ) {
					if ( ontrack_user_has_group_access( $uid, $gid ) ) {
						$has_access = true;
						break;
					}
				}
				if ( ! $has_access ) {
					continue;
				}
			}

			$entry = array(
				'page_id'            => $page_id,
				'label'              => $item->title,
				'icon'               => trim( $item->attr_title ),
				'order'              => (int) $item->menu_order,
				'featured_image_url' => get_the_post_thumbnail_url( $page_id, 'medium' ) ?: null,
			);

			if ( $is_community ) {
				$community[] = $entry;
			}
			if ( $is_resource ) {
				$resources[] = $entry;
			}
		}

		$sort = fn( $a, $b ) => $a['order'] <=> $b['order'];
		usort( $community, $sort );
		usort( $resources, $sort );

		return new WP_REST_Response( array( 'community' => $community, 'resources' => $resources ), 200 );
	}

	/**
	 * GET /tab/{page_id} — composite content for one mobile tab.
	 *
	 * Content sections:
	 *   page       — rendered page content
	 *   sub_pages  — published child pages
	 *   collections — access-filtered CPTs per tab config
	 *   posts      — group-filtered, category/tag-driven, pinned-first
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_tab( WP_REST_Request $request ) {
		$page_id = (int) $request->get_param( 'page_id' );

		$page = get_post( $page_id );
		if ( ! $page || 'page' !== $page->post_type || 'publish' !== $page->post_status ) {
			return new WP_Error( 'not_found', __( 'Page not found.', 'ontrack' ), array( 'status' => 404 ) );
		}

		if ( ! $this->page_is_accessible_tab( $page_id ) ) {
			return new WP_Error( 'not_found', __( 'Page not found.', 'ontrack' ), array( 'status' => 404 ) );
		}

		$user_id        = get_current_user_id();
		$rendered       = apply_filters( 'the_content', $page->post_content );
		$stripped       = trim( wp_strip_all_tags( $page->post_content ) );

		// Page section.
		$page_data = array(
			'id'          => $page_id,
			'title'       => $page->post_title,
			'content'     => $rendered,
			'has_content' => '' !== $stripped,
		);

		// Sub-pages.
		$sub_page_posts = get_posts( array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'post_parent'    => $page_id,
			'orderby'        => 'menu_order title',
			'order'          => 'ASC',
			'posts_per_page' => -1,
			'no_found_rows'  => true,
		) );

		$sub_pages = array();
		foreach ( $sub_page_posts as $sub ) {
			$sub_pages[] = array(
				'id'            => $sub->ID,
				'title'         => $sub->post_title,
				'excerpt'       => wp_strip_all_tags( get_the_excerpt( $sub ) ),
				'thumbnail_url' => (string) ( get_the_post_thumbnail_url( $sub->ID, 'medium' ) ?: '' ),
				'page_id'       => $sub->ID,
			);
		}

		// Collections.
		$collection_type = get_post_meta( $page_id, '_ontrack_tab_collection_type', true ) ?: 'none';
		$collections     = array();
		if ( 'none' !== $collection_type ) {
			if ( 'audio' === $collection_type || 'both' === $collection_type ) {
				$collections = array_merge( $collections, $this->get_accessible_collections( 'audio_collection', 'audio', $user_id ) );
			}
			if ( 'video' === $collection_type || 'both' === $collection_type ) {
				$collections = array_merge( $collections, $this->get_accessible_collections( 'video_collection', 'video', $user_id ) );
			}
		}

		// Posts.
		$posts = $this->build_post_list( $page_id, $user_id );

		return new WP_REST_Response(
			array(
				'page'        => $page_data,
				'sub_pages'   => $sub_pages,
				'collections' => $collections,
				'posts'       => $posts,
			),
			200
		);
	}

	/**
	 * GET /events — upcoming events sorted by date, full members only.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function handle_events( WP_REST_Request $request ) {
		$limit = (int) $request->get_param( 'limit' );

		$query = new WP_Query( array(
			'post_type'      => 'ontrack_event',
			'post_status'    => 'publish',
			'posts_per_page' => $limit,
			'no_found_rows'  => true,
			'meta_query'     => array(
				'event_date_clause' => array(
					'key'     => '_event_datetime',
					'value'   => current_time( 'Y-m-d H:i:s' ),
					'compare' => '>=',
					'type'    => 'DATETIME',
				),
			),
			'orderby' => array( 'event_date_clause' => 'ASC' ),
		) );

		$events = array();
		foreach ( $query->posts as $post ) {
			$events[] = $this->format_event( $post, false );
		}

		return new WP_REST_Response( array( 'events' => $events ), 200 );
	}

	/**
	 * GET /events/{id} — single event with full content.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_event( WP_REST_Request $request ) {
		$id   = (int) $request->get_param( 'id' );
		$post = get_post( $id );

		if ( ! $post || 'ontrack_event' !== $post->post_type || 'publish' !== $post->post_status ) {
			return new WP_Error( 'not_found', __( 'Event not found.', 'ontrack' ), array( 'status' => 404 ) );
		}

		return new WP_REST_Response( $this->format_event( $post, true ), 200 );
	}

	/**
	 * GET /collections — access-filtered collection list.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function handle_collections( WP_REST_Request $request ) {
		$type      = $request->get_param( 'type' );
		$post_type = 'audio' === $type ? 'audio_collection' : 'video_collection';
		$user_id   = get_current_user_id();

		return new WP_REST_Response(
			$this->get_accessible_collections( $post_type, $type, $user_id ),
			200
		);
	}

	// -------------------------------------------------------------------------
	// Permission callbacks
	// -------------------------------------------------------------------------

	/**
	 * Require a valid Bearer JWT.
	 *
	 * @return bool|WP_Error
	 */
	public function require_authenticated() {
		if ( ! get_current_user_id() ) {
			return new WP_Error( 'rest_unauthorized', __( 'Authentication required.', 'ontrack' ), array( 'status' => 401 ) );
		}
		return true;
	}

	/**
	 * Require a valid Bearer JWT and an active membership.
	 *
	 * @return bool|WP_Error
	 */
	public function require_member() {
		$user_id = get_current_user_id();
		if ( ! $user_id ) {
			return new WP_Error( 'rest_unauthorized', __( 'Authentication required.', 'ontrack' ), array( 'status' => 401 ) );
		}
		if ( ! user_can( $user_id, KCFA_CAP_EDIT_OWN_PROFILE ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Membership required.', 'ontrack' ), array( 'status' => 403 ) );
		}
		return true;
	}

	// -------------------------------------------------------------------------
	// Internal helpers
	// -------------------------------------------------------------------------

	/**
	 * Return page IDs accessible via the tab endpoint:
	 * top-level klac-members-nav items + their direct child pages
	 * + pages tagged people-group or resources in klac-members-nav.
	 *
	 * @return int[]
	 */
	private function get_accessible_tab_page_ids() {
		$ids = array();

		// Pages wired up in plugin settings.
		$opts         = get_option( ontrack_options_key(), array() );
		// Settings-based page IDs removed — pages are now configured via klac-members-nav.

		// Top-level klac-members-nav items.
		$menu_items = wp_get_nav_menu_items( 'klac-members-nav' );
		if ( ! $menu_items ) {
			return array_values( array_unique( $ids ) );
		}

		$top_level_ids = array();
		foreach ( $menu_items as $item ) {
			if ( '0' === (string) $item->menu_item_parent && $item->object_id ) {
				$top_level_ids[] = (int) $item->object_id;
			}
		}

		$ids = array_merge( $ids, $top_level_ids );

		if ( ! empty( $top_level_ids ) ) {
			$child_ids = get_posts( array(
				'post_type'       => 'page',
				'post_status'     => 'publish',
				'posts_per_page'  => -1,
				'fields'          => 'ids',
				'no_found_rows'   => true,
				'post_parent__in' => $top_level_ids,
			) );
			$ids = array_merge( $ids, array_map( 'intval', $child_ids ) );
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Whether a page ID may be accessed via the tab endpoint.
	 *
	 * @param int $page_id Page post ID.
	 * @return bool
	 */
	private function page_is_accessible_tab( $page_id ) {
		return in_array( (int) $page_id, $this->get_accessible_tab_page_ids(), true );
	}

	/**
	 * Build the post list for a tab, applying group exclusion and pinning order.
	 *
	 * @param int $page_id Tab page post ID (used to read tab settings meta).
	 * @param int $user_id Current user ID.
	 * @return array[]
	 */
	private function build_post_list( $page_id, $user_id ) {
		$category_id = (int) get_post_meta( $page_id, '_ontrack_tab_post_category_id', true );
		$tag_id      = (int) get_post_meta( $page_id, '_ontrack_tab_post_tag_id', true );
		$limit       = (int) get_post_meta( $page_id, '_ontrack_tab_post_limit', true ) ?: 10;

		if ( ! $category_id && ! $tag_id ) {
			return array();
		}

		$query_args = array(
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'posts_per_page' => $limit,
			'no_found_rows'  => true,
			// Pinned posts first, then newest.
			'meta_query'     => array(
				'relation'          => 'OR',
				'pinned_clause'     => array(
					'key'     => '_ontrack_pinned',
					'value'   => '1',
					'compare' => '=',
				),
				'not_pinned_clause' => array(
					'key'     => '_ontrack_pinned',
					'compare' => 'NOT EXISTS',
				),
			),
			'orderby'        => array(
				'pinned_clause' => 'DESC',
				'date'          => 'DESC',
			),
		);

		if ( $category_id ) {
			$query_args['cat'] = $category_id;
		} else {
			$query_args['tag_id'] = $tag_id;
		}

		$excluded = function_exists( 'ontrack_get_post_excluded_ids_for_user' )
			? ontrack_get_post_excluded_ids_for_user( $user_id )
			: array();

		if ( ! empty( $excluded ) ) {
			$query_args['post__not_in'] = array_map( 'intval', $excluded );
		}

		$query = new WP_Query( $query_args );
		$posts = array();

		foreach ( $query->posts as $post ) {
			$posts[] = array(
				'id'            => $post->ID,
				'title'         => $post->post_title,
				'excerpt'       => wp_strip_all_tags( get_the_excerpt( $post ) ),
				'date'          => get_the_date( 'c', $post ),
				'thumbnail_url' => (string) ( get_the_post_thumbnail_url( $post->ID, 'medium' ) ?: '' ),
			);
		}

		return $posts;
	}

	/**
	 * Return access-filtered collection items of the given CPT and mobile type label.
	 *
	 * @param string $post_type CPT slug (audio_collection or video_collection).
	 * @param string $type      Mobile type label (audio or video).
	 * @param int    $user_id   Current user ID.
	 * @return array[]
	 */
	private function get_accessible_collections( $post_type, $type, $user_id ) {
		$posts = get_posts( array(
			'post_type'      => $post_type,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'orderby'        => 'menu_order title',
			'order'          => 'ASC',
			'no_found_rows'  => true,
		) );

		$collections = array();
		foreach ( $posts as $post ) {
			if ( function_exists( 'ontrack_user_can_view_collection' ) &&
				! ontrack_user_can_view_collection( $post->ID, $user_id ) ) {
				continue;
			}
			$collections[] = $this->format_collection( $post, $type );
		}

		return $collections;
	}

	/**
	 * Format an event post as a REST payload.
	 *
	 * @param WP_Post $post            Event post.
	 * @param bool    $include_content Whether to include rendered content (detail view only).
	 * @return array
	 */
	private function format_event( WP_Post $post, $include_content ) {
		$data = array(
			'id'             => $post->ID,
			'title'          => $post->post_title,
			'event_datetime' => (string) get_post_meta( $post->ID, '_event_datetime', true ),
			'location'       => (string) get_post_meta( $post->ID, '_event_location', true ),
			'stream_url'     => (string) get_post_meta( $post->ID, '_event_stream_url', true ),
			'thumbnail_url'  => (string) ( get_the_post_thumbnail_url( $post->ID, 'large' ) ?: '' ),
			'excerpt'        => wp_strip_all_tags( get_the_excerpt( $post ) ),
		);

		if ( $include_content ) {
			$data['content'] = apply_filters( 'the_content', $post->post_content );
		}

		return $data;
	}

	/**
	 * Format a collection post as a mobile card payload.
	 *
	 * @param WP_Post $post Collection post.
	 * @param string  $type audio|video.
	 * @return array
	 */
	private function format_collection( WP_Post $post, $type ) {
		$thumbnail_url = (string) ( get_the_post_thumbnail_url( $post->ID, 'medium' ) ?: '' );
		$source        = 'audio' === $type
			? 'box'
			: ( get_post_meta( $post->ID, '_ontrack_video_provider', true ) ?: 'bunny' );

		$track_count = null;
		if ( 'audio' === $type && function_exists( 'ontrack_audio_metadata_table' ) ) {
			global $wpdb;
			$table       = ontrack_audio_metadata_table();
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$track_count = (int) $wpdb->get_var(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					"SELECT COUNT(*) FROM {$table} WHERE collection_id = %d",
					$post->ID
				)
			);
		}

		return array(
			'id'            => $post->ID,
			'title'         => $post->post_title,
			'description'   => $post->post_excerpt,
			'type'          => $type,
			'source'        => $source,
			'thumbnail_url' => $thumbnail_url,
			'track_count'   => $track_count,
		);
	}
}
